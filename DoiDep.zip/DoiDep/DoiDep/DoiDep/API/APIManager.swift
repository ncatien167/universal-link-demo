//
//  APIManager.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 15/07/2022.
//

import Foundation

enum APIManager {
    
    // Authenticate
    case login
    
    // Common Api
    case province
    case store
    case category
    case topSales
    case productPromos
    case banner
    case forYou
    case byCategory(Int)
    case productDetail(Int)
    case getAddress(Int)
    case setAddress
    case district(Int)
    case ward(Int)
    case setDefaultAddress(Int, Int)
    case editVAT
    case voucher
    case order
    case yourOrdered(Int)
    case deleteOrder(String)
    case searchProduce(String, String)
    case deleteAddress(Int, Int)
    case signUp
    case verifyCustomerOtp
    case resetPassword(String)
    case resetPasswordComplete
    case bookingHotelsSearch
    case bookingHotels
    case bookingPayment
    case bookingGets
    case bookingSearch
    case bookingDelete
    case banner7
    case loginFromOPS
//    "login": "/Authenticate/Login",
//        "signUp": "/customer/create",
//        "verifyCustomerOtp": "/customer/verify",
//        "province": "/area/province",
//        "district": "/area/district?provinceID=",
//        "ward": "/area/ward?districtID=",
//        "news": "/news/gets",
//        "store": "/store/gets",
//        "getAddress": "/customer/address?userID=",
//        "setAddress": "/customer/address",
//        "deleteAddress": "/customer/address?userID=",
//        "setDefaultAddress": "/customer/address/default?userID=",
//        "resetPassword": "/customer/resetPassword?phone=",
//        "resetPasswordComplete": "/customer/resetPassword/complete",
//        "banner": "/banner/gets?position=",
//        "searchProduce": "/product/search?p=",
//        "voucher": "/voucher/list",
//        "detailItem": "/product/detail?id=",
//        "changePassword": "/customer/changepass",
//        "order": "/order/create",
//        "productLove": "/product/love?productID=",
//        "productHits": "/product/hits?productID=",
//        "yourOrdered": "/order/gets?userID=",
//        "listFavorite": "/product/love?userID=",
//        "listViewed": "/product/hits?userID=",
//        "getAllProduce": "/product/gets",
//        "category": "/product/category",
//        "deleteOrder": "/order/cancel?code=",
//        "topSales": "/product/topsales",
//        "productPromos": "/product/promo",
//        "version": "/config/version/",
//        "avatar":"/customer/avatar",
//        "editProfile":"/customer/info",
//        "editVAT":"/customer/vat",
//        "changeMethod":"/order/method",
//        "payNow":"/order/paynow",
//        "forYou":"/product/foryou",
//        "byCategory":"/product/bycategory?cat="
    
}

extension APIManager {
    
//pilot: 'https://api.doidep.com',
//    uat: 'https://api-uat.doidep.com',
    var baseURL: String {
        switch Config.buildType {
        case BuildType.NAB:
            return "https://api-uat.doidep.com"
        case BuildType.PROD:
            return "https://api.doidep.com"
        }
    }
    
    //MARK: - URL
    
    var url: String {
        
        var path = ""
        
        switch self {
            
        case .login: path = "/Authenticate/Login"
        case .province: path = "/area/province"
        case .store: path = "/store/gets"
        case .category: path = "/product/nab/category"
        case .topSales: path = "/product/nab/gets"
        case .productPromos: path = "/product/nab/promo"
        case .banner: path = "/banner/gets?position=6"
        case .forYou: path = "/product/nab/foryou"
        case .byCategory(let category): path = "/product/nab/bycategory?cat=\(category)"
        case .productDetail(let ID): path = "/product/detail?id=\(ID)"
        case .getAddress(let ID): path = "/customer/address?userID=\(ID)"
        case .setAddress: path = "/customer/address"
        case .district(let ID): path = "/area/distr ict?provinceID=\(ID)"
        case .ward(let ID): path = "/area/ward?districtID=\(ID)"
        case .setDefaultAddress(let ID, let addressID): path = "/customer/address/default?userID=\(ID)&addressID=\(addressID)"
        case .editVAT: path = "/customer/vat"
        case .voucher: path = "/voucher/list"
        case .order: path = "/order/create"
        case .yourOrdered(let ID): path = "/order/gets?userID=\(ID)"
        case .deleteOrder(let ID): path = "/order/cancel?code=\(ID)"
        case .searchProduce(let query, let page): path = "/product/nab/search?key=\(query)&page=\(page)"
        case .deleteAddress(let userID, let addressID): path = "/customer/address?userID=\(userID)&addressID=\(addressID)"
        case .signUp: path = "/customer/create"
        case .verifyCustomerOtp: path = "/customer/verify"
        case .resetPassword(let phone): path = "/customer/resetPassword?phone=\(phone)"
        case .resetPasswordComplete: path = "/customer/resetPassword/complete"
        case .bookingHotelsSearch: path = "/booking/hotels/search"
        case .bookingHotels: path = "/booking/hotels"
        case .bookingPayment: path = "/booking/hotels/create"
        case .bookingGets: path = "/booking/gets"
        case .bookingSearch: path = "/booking/hotels/create"
        case .bookingDelete: path = "/booking/hotels/delete"
        case .banner7: path = "/banner/gets?position=7"
        case .loginFromOPS: path = "/authenticate/loginFromOPS"
        }

        return baseURL + path
    }
    
    //MARK: - METHOD
    
    var method: HTTPMethod {
        switch self {
        case .deleteAddress:
            return .delete
        case .setDefaultAddress, .editVAT, .resetPasswordComplete:
            return .put
        case .login, .setAddress, .order, .deleteOrder, .signUp, .verifyCustomerOtp, .resetPassword, .bookingHotelsSearch, .bookingPayment, .bookingDelete, .loginFromOPS:
            return .post
        case .province, .store, .category, .topSales, .productPromos, .banner, .forYou, .byCategory, .productDetail, .getAddress, .district, .ward, .voucher, .yourOrdered, .searchProduce, .bookingGets, .bookingHotels, .bookingSearch, .banner7:
            return .get
        }
    }
    
    //MARK: - HEADER
    
    var header: HTTPHeaders? {
        switch self {
        case .getAddress, .setAddress, .setDefaultAddress, .voucher, .yourOrdered, .deleteOrder, .searchProduce, .deleteAddress, .bookingGets:
            return [
                "UserName" : UserService.shared.getDataUser().getPhone() != "" ? UserService.shared.getDataUser().getPhone() : UserService.shared.getDataUser().getEmail(),
                Header.authorization: "Bearer " + UserService.shared.getDataUser().getToken(),
            ]
        case .order, .editVAT, .bookingDelete, .bookingPayment:
                return [
                    "UserName" : UserService.shared.getDataUser().getPhone() != "" ? UserService.shared.getDataUser().getPhone() : UserService.shared.getDataUser().getEmail(),
                    Header.authorization: "Bearer " + UserService.shared.getDataUser().getToken(),
                    Header.contentType: Header.contentTypeValue
                ]
        default:
            return nil
        }
    }
    
    //MARK: - ENCODING
    
    var encoding: ParameterEncoding {
        
        switch self.method {
        case .get:
            return URLEncoding.default
        default:
            return JSONEncoding.default
        }
    }
}

struct Header {
    
    static let authorization            = "Authorization"
    static let contentType              = "Content-Type"
    static let contentTypeValue         = "application/json"
    
}
