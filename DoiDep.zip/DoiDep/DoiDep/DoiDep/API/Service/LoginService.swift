//
//  LoginService.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 15/07/2022.
//

import Foundation

struct LoginService {
    static func requestLogin(with username: String, and password: String, completion: ((Bool?, String?) -> Void)? = nil) {
        let param: [String:Any] = ["Username": username,
                                   "Password": password]
        APIController.request(UserData.self, .login, params: param) { error, data in
            if let error = error {
                Logger.log(message: "request Login Fail with: \(error)", event: .error)
                completion?(false, "Tên đăng nhập hoặc mật khẩu không đúng")
                return
            }
            
            if let userData = data {
                if userData.isRequestErrorWith() {
                    completion?(false, userData.getMessage())
                    return
                }
                
                UserService.shared.setDataUser(with: userData)
                Logger.log(message: "request Login Succes with: \(userData)", event: .debug)
                completion?(true, nil)
                return
            }
        }
    }
    
    static func requestSignUp(with data: SignUpParam, completion: ((Bool?, ResponseOTP?) -> Void)? = nil) {
        Logger.log(message: "requestSignUp Data Param: \(data.convertObjectToDictionary)", event: .debug)
        APIController.request(ResponseOTP.self, .signUp, params: data.convertObjectToDictionary) { error, data in
            if let error = error {
                Logger.log(message: "requestSignUp Fail with: \(error)", event: .error)
                completion?(false, data)
                return
            }
            
            if let data = data {
                Logger.log(message: "requestSignUp Success with: \(data)", event: .debug)
                completion?(true, data)
                return
            }
        }
    }
    
    static func requestResetPassword(with phone: String, completion: ((Bool?, ResponseOTP?) -> Void)? = nil) {
        APIController.request(ResponseOTP.self, .resetPassword(phone), params: nil) { error, data in
            if let error = error {
                Logger.log(message: "requestResetPassword Fail with: \(error)", event: .error)
                completion?(false, data)
                return
            }
            
            if let data = data {
                Logger.log(message: "requestResetPassword Success with: \(data)", event: .debug)
                completion?(true, data)
                return
            }
        }
    }
    
    static func requestPasswordComplete(with params: [String:Any], completion: ((Bool?, String?) -> Void)? = nil) {
        Logger.log(message: "requestPasswordComplete with: \(params)", event: .debug)
        APIController.request(String.self, .resetPasswordComplete, params: params) { error, data in
            if let error = error {
                Logger.log(message: "requestPasswordComplete Fail with: \(error)", event: .error)
                completion?(false, "Đã có lỗi xảy ra. Vui lòng thực hiện lại")
                return
            }
            
            if let data = data {
                Logger.log(message: "requestPasswordComplete Success with: \(data)", event: .debug)
                completion?(true, data)
                return
            }
        }
    }
}
