//
//  OTPService.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 17/08/2022.
//

import Foundation
//const network = yield client.post(getUrl() + api.verifyCustomerOtp,{
//            RefKey: verifyCustomerOtpAction.refKey,
//            OTP: verifyCustomerOtpAction.otp
//        })

struct OTPService {
    static func requestVerify(with otp: String, and ref: String, completion: ((Bool?, String?) -> Void)? = nil) {
        let param: [String:Any] = ["OTP": otp,
                                   "RefKey": ref]
        APIController.request(String.self, .verifyCustomerOtp, params: param) { error, data in
            if let error = error {
                Logger.log(message: "requestVerify Fail with: \(error)", event: .error)
                completion?(false, data ?? "Đã có lỗi xảy ra. Quý khách vui lòng thử lại")
                return
            }
            
            completion?(true, data)
            Logger.log(message: "requestVerify Succes", event: .debug)
        }
    }
}
