//
//  AddressService.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 21/07/2022.
//

import Foundation

struct AddressService {
    
    static func getDistrictData(with ID: Int, completion: (([WardDistrictData]?) -> Void)? = nil) {
        APIController.request([WardDistrictData].self, .district(ID), params: nil) { error, data in
            if let error = error {
                Logger.log(message: "request getDistrictData Fail with: \(error)", event: .error)
                completion?([])
                return
            }
            
            if let wardDistrictDatas = data {
                Logger.log(message: "request getDistrictData Success with: \(wardDistrictDatas)", event: .debug)
                completion?(wardDistrictDatas)
                return
            }
            
            completion?([])
        }
    }
    
    static func getWardData(with ID: Int, completion: (([WardDistrictData]?) -> Void)? = nil) {
        APIController.request([WardDistrictData].self, .ward(ID), params: nil) { error, data in
            if let error = error {
                Logger.log(message: "request getWardData Fail with: \(error)", event: .error)
                completion?([])
                return
            }
            
            if let wardDistrictDatas = data {
                Logger.log(message: "request getWardData Success with: \(wardDistrictDatas)", event: .debug)
                completion?(wardDistrictDatas)
                return
            }
            
            completion?([])
        }
    }
    
    static func requestSetDefaultAddress(with addressID: Int, completion: ((Bool?) -> Void)? = nil) {
        APIController.request(String.self, .setDefaultAddress(UserService.shared.getDataUser().ID ?? -1, addressID), params: nil) { error, data in
            if let error = error {
                Logger.log(message: "request requestSetDefaultAddress Fail with: \(error)", event: .error)
                completion?(nil)
                return
            }
            
            if let data = data {
                Logger.log(message: "request requestSetDefaultAddress Success with: \(data)", event: .debug)
                completion?(true)
                return
            }
        }
    }
    
    static func requestCreateAddress(with addressParam: AddressParam, completion: ((Bool?) -> Void)? = nil) {
        let param: [String:Any] = addressParam.convertObjectToDictionary
        Logger.log(message: "request requestCreateAddress with Param: \(param)", event: .debug)
        APIController.request(String.self, .setAddress, params: param) { error, data in
            if let error = error {
                Logger.log(message: "request requestCreateAddress Fail with: \(error)", event: .error)
                completion?(false)
                return
            }
            
            if let data = data {
                Logger.log(message: "request requestCreateAddress Success with: \(data)", event: .debug)
                completion?(true)
                return
            }
        }
    }
    
    static func requestDeleteAddress(with addressID: Int, completion: ((Bool?) -> Void)? = nil) {
        APIController.request(String.self, .deleteAddress(UserService.shared.getDataUser().ID ?? -1, addressID), params: nil) { error, data in
            if let error = error {
                Logger.log(message: "request requestDeleteAddress Fail with: \(error)", event: .error)
                completion?(nil)
                return
            }
            
            if let data = data {
                Logger.log(message: "request requestDeleteAddress Success with: \(data)", event: .debug)
                completion?(true)
                return
            }
        }
    }
}

//UserID: dataUser.ID,
//        CustomerName: actions.customerName,
//        Phone: actions.phone,
//        Province: actions.address.city.ID,
//        District: actions.address.district.ID,
//        Ward: actions.address.ward.ID,
//        Address: actions.address.address,
//        AddressType: actions.isAddressType,
//        IsDefault: actions.isDefault,
//        Lat: 1.0,
//        Long: 1.0,
