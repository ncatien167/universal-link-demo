//
//  CommonService.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 16/07/2022.
//

import Foundation
import UIKit

class CommonService {
    static let shared = CommonService()
    
    private var stores: [StoreData]?
    private var productTopSales: [ProductData]?
    private var areaProvinces: [AreaProvinceData]?
    private var productCategories: [ProductCategory]?
    private var addresses: [AddressData]?
    private var banners: [BannerData]?
    
    private init() { }
    
    func removeCommonServiceData() {
        stores = nil
        productTopSales = nil
        areaProvinces = nil
        productCategories = nil
        addresses = nil
        banners = nil
    }
    
    // MARK: - Province
    func setAreaProvinces(with datas: [AreaProvinceData]) {
        self.areaProvinces = datas
    }
    
    func getAreaProvinces() -> [AreaProvinceData] {
        guard let areaProvinces = areaProvinces else {
            return []
        }
        
        return areaProvinces
    }
    
    func getProvinceData(with ID: Int) -> AreaProvinceData? {
        for province in self.getAreaProvinces() {
            if province.ID == ID {
                return province
            }
        }
        
        return nil
    }
    
    // MARK: - Store
    func setStores(with datas: [StoreData]) {
        self.stores = datas
    }
    
    func getStores() -> [StoreData] {
        guard let stores = stores else {
            return []
        }
        
        return stores
    }
    
    // MARK: - Product Category
    func setArrayProductCategories(with productCategories: [ProductCategory]) {
        self.productCategories = productCategories
        self.productCategories?.insert(ProductCategory(ID: -1, Name: "Phổ biến", isSelected: true), at: 0)
    }
    
    func getProductCategories() -> [ProductCategory] {
        guard let productCategories = self.productCategories else {
            return []
        }
        
        return productCategories
    }
    
    func changeSelectedProductCategory(with index: Int) {
        for indexCategories in 0..<(self.productCategories?.count ?? 0) {
            if indexCategories == index {
                self.productCategories?[index].isSelected = true
            } else {
                self.productCategories?[indexCategories].isSelected = false
            }
        }
    }
    
    // MARK: - Product Top Sales
    func setProductTopSales(with productTopSales: [ProductData]) {
        self.productTopSales = productTopSales
    }
    
    func getProductTopSales() -> [ProductData] {
        guard let productTopSales = self.productTopSales else {
            return []
        }
        
        return productTopSales
    }
    
    func getTopProducts() -> [ProductData] {
        guard let productTopSales = self.productTopSales else {
            return []
        }
        
        var products: [ProductData] = []
        if productTopSales.count >= 3 {
            products.append(productTopSales[0])
            products.append(productTopSales[1])
            products.append(productTopSales[3])
        }
        
        return products
    }
    // MARK: - Banner
    func setBanners(with banners: [BannerData]) {
        self.banners = banners
    }
    
    func getBanners() -> [BannerData] {
        guard let banners = self.banners else {
            return []
        }
        
        return banners
    }
    
    func setBanners7(with banners: [BannerData]) {
        self.banners = banners
    }
    
    func getBanners7() -> [BannerData] {
        guard let banners = self.banners else {
            return []
        }
        
        return banners
    }
    
    // MARK: - Address
    func setAddresses(with addresses: [AddressData]) {
        self.addresses = addresses
    }
    
    func getAddresses() -> [AddressData] {
        guard let addresses = self.addresses else {
            return []
        }
        
        return addresses
    }
    
    func updateAddressAfterDelete(with address: AddressData?) {
        guard let addresses = self.addresses, let address = address else {
            return
        }
        
        for i in 0..<addresses.count {
            if addresses[i].ID == address.ID {
                self.addresses?.remove(at: i)
                break
            }
        }
    }
    
    func defaultAddress() -> AddressData? {
        for addressData in self.getAddresses() {
            if (addressData.IsDefault ?? false) == true {
                return addressData
            }
        }
        
        return nil
    }
    
    func setDefaultAddress(with index: Int) {
        var addressesUpdated: [AddressData] = self.getAddresses()
        
        for i in 0..<self.getAddresses().count {
            if i == index {
                addressesUpdated[i].IsDefault = true
            } else {
                addressesUpdated[i].IsDefault = false
            }
        }
        
        self.addresses = addressesUpdated
    }
}
