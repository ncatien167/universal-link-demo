//
//  CommonApiService.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 16/07/2022.
//

import Foundation

struct CommonAPIService {
    
    static func getProvinceData(completion: ((Bool?) -> Void)? = nil) {
        APIController.request([AreaProvinceData].self, .province, params: nil) { error, data in
            if let error = error {
                Logger.log(message: "request getProvinceData Fail with: \(error)", event: .error)
                completion?(false)
                return
            }
            
            if let areaProvinces = data {
                CommonService.shared.setAreaProvinces(with: areaProvinces)
                Logger.log(message: "request getProvinceData Succes with: \(areaProvinces)", event: .debug)
                completion?(true)
                return
            }
            
            completion?(false)
        }
    }
    
    static func getStoreData(completion: ((Bool?) -> Void)? = nil) {
        APIController.request([StoreData].self, .store, params: nil) { error, data in
            if let error = error {
                Logger.log(message: "request getStoreData Fail with: \(error)", event: .error)
                completion?(false)
                return
            }
            
            if let stores = data {
                CommonService.shared.setStores(with: stores)
                Logger.log(message: "request getStoreData Succes with: \(stores)", event: .debug)
                completion?(true)
                return
            }
            
            completion?(false)
        }
    }
    
    static func getCategoryData(completion: ((Bool?) -> Void)? = nil) {
        APIController.request([ProductCategory].self, .category, params: nil) { error, data in
            if let error = error {
                Logger.log(message: "request getCategoryData Fail with: \(error)", event: .error)
                completion?(false)
                return
            }
            
            if let productCategories = data {
                CommonService.shared.setArrayProductCategories(with: productCategories)
                Logger.log(message: "request getCategoryData Succes with: \(productCategories)", event: .debug)
                completion?(true)
                return
            }
            
            completion?(false)
        }
    }
    
    static func getTopSalesData(completion: ((Bool?) -> Void)? = nil) {
        APIController.request([ProductData].self, .topSales, params: nil) { error, data in
            if let error = error {
                Logger.log(message: "request getTopSalesData Fail with: \(error)", event: .error)
                completion?(false)
                return
            }
            
            if let productTopSales = data {
                CommonService.shared.setProductTopSales(with: productTopSales)
                Logger.log(message: "request getTopSalesData Succes with: \(productTopSales)", event: .debug)
                completion?(true)
                return
            }
            
            completion?(false)
        }
    }
    
    static func getBannerData(completion: ((Bool?) -> Void)? = nil) {
        APIController.request([BannerData].self, .banner, params: nil) { error, data in
            if let error = error {
                Logger.log(message: "request getBannerData Fail with: \(error)", event: .error)
                completion?(false)
                return
            }
            
            if let banners = data {
                CommonService.shared.setBanners(with: banners)
                Logger.log(message: "request getBannerData Succes with: \(banners)", event: .debug)
                completion?(true)
                return
            }
            
            completion?(false)
        }
    }
    
    static func getBanner7Data(completion: ((Bool?) -> Void)? = nil) {
        APIController.request([BannerData].self, .banner7, params: nil) { error, data in
            if let error = error {
                Logger.log(message: "request getBannerData Fail with: \(error)", event: .error)
                completion?(false)
                return
            }
            
            if let banners = data {
                CommonService.shared.setBanners7(with: banners)
                Logger.log(message: "request getBannerData Succes with: \(banners)", event: .debug)
                completion?(true)
                return
            }
            
            completion?(false)
        }
    }
    
    static func getAddressData(completion: ((Bool?) -> Void)? = nil) {
        let UserID = UserService.shared.getDataUser().ID ?? -1
        APIController.request([AddressData].self, .getAddress(UserID), params: nil) { error, data in
            if let error = error {
                Logger.log(message: "request getAddressData Fail with: \(error)", event: .error)
                completion?(false)
                return
            }
            
            if let addresses = data {
                CommonService.shared.setAddresses(with: addresses)
                Logger.log(message: "request getAddressData Succes with: \(addresses)", event: .debug)
                completion?(true)
                return
            }
            
            completion?(false)
        }
    }
    
    static func getVoucher(completion: ((Bool?) -> Void)? = nil) {
        APIController.request([Voucher].self, .voucher, params: nil) { error, data in
            if let error = error {
                Logger.log(message: "request getVoucher Fail with: \(error)", event: .error)
                completion?(false)
                return
            }
            
            if let vouchers = data {
                VoucherService.shared.setDataVouchers(with: vouchers)
                Logger.log(message: "request getVoucher Succes with: \(vouchers)", event: .debug)
                completion?(true)
                return
            }
            
            completion?(false)
        }
    }
}
