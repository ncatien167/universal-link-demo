//
//  CommonButton.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 15/07/2022.
//

import Foundation
import UIKit

class CommonButton: UIButton {
    
    lazy var button: UIButton = {
        let button = UIButton()
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .medium)
        button.backgroundColor = .clear
        button.setTitleColor(.white, for: .normal)
        button.addTarget(self, action: #selector(didTapButton), for: .touchUpInside)
        return button
    }()
    
    lazy var backgroundButton: UIImageView = {
        let image = UIImageView(image: UIImage().getImage(with: "bg_button", and: Bundle(for: CommonButton.self))!)
        image.contentMode = .scaleAspectFill
        image.layer.masksToBounds = true
        return image
    }()
    
    lazy var rightIcon: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    // MARK: - PROPERTIES
    
    var didTap: (()->())?
    var titleButton = ""
    
    // MARK: - FLAGS
    
    var isLoading = false
    var isTrailingSuperView = false
    
    // MARK: - INIT
    
    convenience init(isTrailingSuperView: Bool) {
        self.init()
        self.isTrailingSuperView = isTrailingSuperView
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.awakeFromNib()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.awakeFromNib()
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.addSubviews(backgroundButton, button)
        self.button.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview()
        }
        self.backgroundButton.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview()
        }
    }
    
    func setup(title: String, _ cornerRadius: CGFloat = 10.heightRatio) {
        titleButton = title
        button.setTitle(title, for: .normal)
        self.layer.cornerRadius = cornerRadius
        self.layer.masksToBounds = true
    }
    
    func setup(title: String, cornerRadius: CGFloat = 10.heightRatio, fontSize: CGFloat) {
        titleButton = title
        button.setTitle(title, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: fontSize, weight: .light)
        self.layer.cornerRadius = cornerRadius
        self.layer.masksToBounds = true
    }
    
    func setup(title: String, icon: UIImage, _ cornerRadius: CGFloat = 10.heightRatio) {
        titleButton = title
        rightIcon.image = icon
        self.layer.cornerRadius = cornerRadius
        self.layer.masksToBounds = true
    }
    
    // MARK: - ACTION
    
    @objc func didTapButton() {
        didTap?()
    }
    
}
