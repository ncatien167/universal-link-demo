//
//  PopUpAddress.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 21/07/2022.
//

import UIKit

class PopUpAddress: UIViewController {
    
    lazy var stackContentView: UIStackView = {
        let stackView = UIStackView()
        stackView.distribution = .fill
        stackView.alignment = .center
        stackView.axis = .vertical
        stackView.spacing = 10.widthRatio
        return stackView
    }()
    
    lazy var contentAlertView: UIView = {
        let view = UIView()
        view.backgroundColor = Colors.white
        view.layer.cornerRadius = 15
        view.layer.masksToBounds = true
        return view
    }()
    
    private lazy var dimmedBackgroundView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = UIColor.black.withAlphaComponent(0.3)
        return view
    }()
    
    private lazy var titleLabel: CommonButton = {
        let button = CommonButton()
        button.setup(title: "Chọn địa chỉ", 10)
        return button
    }()
    
    lazy var buttonClose: UIButton = {
        let button = UIButton()
        button.setImage(UIImage().getImage(with: "ic_close", and: Bundle(for: PopUpAddress.self))!, for: .normal)
        button.addTarget(self, action: #selector(didCancel(_:)), for: .touchUpInside)
        return button
    }()
    
    lazy var buttonAddNewAddress: UIButton = {
        let button = UIButton()
        button.layer.masksToBounds = true
        button.layer.cornerRadius = 10.heightRatio
        button.backgroundColor = Colors.customGaryColor
        button.setTitle("Thêm địa chỉ mới", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        button.setImage(UIImage().getImage(with: "ic_plus", and: Bundle(for: PopUpAddress.self))!, for: .normal)
        button.setTitleColor(Colors.authenticateColor, for: .normal)
        button.titleEdgeInsets = UIEdgeInsets(top: 0, left: -30.widthRatio, bottom: 0, right: 0)
        button.imageEdgeInsets = UIEdgeInsets(top: 0, left: 150.widthRatio, bottom: 0, right: 0)
        button.addTarget(self, action: #selector(didGoToSelectAddress), for: .touchUpInside)
        return button
    }()
    
    lazy var buttonCancel: UIButton = {
        let button = UIButton()
        button.setTitle("HỦY", for: .normal)
        button.setTitleColor(Colors.normalTextColor, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        button.backgroundColor = .white
        button.layer.cornerRadius = 10.heightRatio
        button.layer.shadowColor = Colors.customGaryColor.cgColor
        button.layer.shadowOffset = CGSize(width: 1, height: 1)
        button.layer.shadowOpacity = 1.0
        button.layer.shadowRadius = 2
        button.addTarget(self, action: #selector(didCancel(_:)), for: .touchUpInside)
        return button
    }()
    
    lazy var buttonSave: UIButton = {
        let button = UIButton()
        button.setTitle("LƯU", for: .normal)
        button.setTitleColor(Colors.white, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        button.backgroundColor = Colors.mainColor
        button.layer.cornerRadius = 10.heightRatio
        button.addTarget(self, action: #selector(didOk(_:)), for: .touchUpInside)
        return button
    }()
    
    lazy var tableView: UITableView = {
        let tableView = UITableView()
        tableView.separatorColor = Colors.authenticateColor
        return tableView
    }()
    
    // MARK: - Properties
    private var addressProvider: DataProvider<AddressData> = DataProvider(data: [])
    private var addressDataSource: TableViewDataSource<AddressOrderCell, AddressData>!
    
    typealias completionSaveHandler = (Int?) -> ()
    typealias completionHandler = () -> ()
    private var titleString: String?
    private var messageString: String?
    private var okCommpletion: completionSaveHandler?
    private var cancelCommpletion: completionHandler?
    private var addNewAdressCommpletion: completionHandler?
    private var addressID: Int? = CommonService.shared.getAddresses().first?.ID
    var didSelectAddress: (()->())?

    convenience init(okAction: completionSaveHandler? = nil, cancelAction: completionHandler? = nil, addNewAdressCommpletion: completionHandler? = nil) {
        self.init()
        self.okCommpletion = okAction
        self.cancelCommpletion = cancelAction
        self.addNewAdressCommpletion = addNewAdressCommpletion
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // settup view
        
        initLayout()
        configTableView()
    }
    
    func initLayout() {
        self.view.addSubview(dimmedBackgroundView)
        self.view.addSubview(contentAlertView)
        self.contentAlertView.addSubviews(stackContentView, buttonClose, titleLabel)
        
        dimmedBackgroundView.snp.makeConstraints { (make) in
            make.trailing.leading.top.bottom.equalToSuperview()
        }
        
        contentAlertView.snp.makeConstraints { (make) in
            make.bottom.leading.trailing.equalToSuperview()
            make.height.equalTo(600.heightRatio)
        }
        
        buttonClose.snp.makeConstraints { make in
            make.width.height.equalTo(30.heightRatio)
            make.top.leading.equalToSuperview().inset(15.widthRatio)
        }
        
        titleLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().inset(15.widthRatio)
            make.centerX.equalToSuperview()
            make.width.equalTo(180.widthRatio)
            make.height.equalTo(30.heightRatio)
        }
        
        setupUpBottomButtons()
        
        stackContentView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(titleLabel.snp.bottom).offset(15.heightRatio)
            make.bottom.equalTo(buttonCancel.snp.top).offset(-15.heightRatio)
        }
        
        stackContentView.addArrangedSubview(tableView)
        stackContentView.addArrangedSubview(buttonAddNewAddress)
        tableView.setConstraintWidth(constant: 375.heightRatio)
        buttonAddNewAddress.setConstraintWidthAndHeight(widthConstant: 200.widthRatio, heightConstant: 30.heightRatio)
    }
    
    private func setupUpBottomButtons() {
        let stackView = UIStackView(arrangedSubviews: [buttonCancel, buttonSave])
        stackView.spacing = 30
        stackView.axis = .horizontal
        stackView.alignment = .center
        stackView.distribution = .fillEqually
        
        self.contentAlertView.addSubview(stackView)
        
        buttonCancel.setConstraintHeight(constant: 25.heightRatio)
        buttonSave.setConstraintHeight(constant: 25.heightRatio)
        
        stackView.snp.makeConstraints { make in
            make.bottom.leading.trailing.equalToSuperview().inset(30.widthRatio)
        }
    }
    
    private func configTableView() {
        addressProvider.data = CommonService.shared.getAddresses()
        tableView.delegate = self
        tableView.separatorStyle = .none
        tableView.alwaysBounceVertical = true
        tableView.register(cellClass: AddressOrderCell.self)
        addressDataSource = TableViewDataSource(dataProvider: addressProvider)
        
        addressDataSource.configureCell = { [weak self] cell, model, index in
            guard let _ = self else { return }
            cell.bindData(with: model)
            cell.selectionStyle = .none
        }
        
        tableView.dataSource = addressDataSource
        tableView.reloadData()
    }
    
    // MARK: show alert
    static func showAlert(didSelectAddress: completionHandler? = nil, okCompletion: completionSaveHandler? = nil, cancelCompletion: completionHandler? = nil) {
        let alert = PopUpAddress(okAction: okCompletion, cancelAction: cancelCompletion, addNewAdressCommpletion: didSelectAddress)
        DispatchQueue.main.async(execute: {
            guard let viewController = UIViewController.topMostViewController() else { return }
            presentPopover(alert, viewController: viewController)
        })
    }
    
    
    /// Handle event when tap OK button
    /// - Parameter sender: button OK
    @objc func didOk(_ sender: UIButton) {
        guard let completion = okCommpletion else {
            dismiss(animated: true, completion: nil)
            return
        }
        completion(addressID)
        dismiss(animated: true, completion: nil)
    }
    
    /// Handle event when tap Cancel button
    /// - Parameter sender: button Cancel
    @objc func didCancel(_ sender: UIButton) {
        guard let completion = cancelCommpletion else {
            dismiss(animated: true, completion: nil)
            return
        }
        dismiss(animated: true, completion: completion)
    }
    
    /// Display an alertDialog in the specified viewController.
    /// - Parameters:
    ///   - alert: alertDialog
    ///   - viewController: View to display alertDialog
    private static func presentPopover(_ alert: UIViewController, viewController: UIViewController) {
        alert.modalPresentationStyle = .overCurrentContext
        alert.modalTransitionStyle = .crossDissolve
        alert.definesPresentationContext = true
        viewController.present(alert, animated: true, completion: nil)
    }
    
    @objc private func didGoToSelectAddress() {
        addNewAdressCommpletion?()
        dismiss(animated: true, completion: nil)
    }
}

extension PopUpAddress: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        addressID = CommonService.shared.getAddresses()[indexPath.row].ID
        CommonService.shared.setDefaultAddress(with: indexPath.row)
        addressProvider.data = CommonService.shared.getAddresses()
        tableView.reloadData()
    }
}
