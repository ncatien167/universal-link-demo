//
//  CommonPopup.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 15/07/2022.
//

import UIKit

class CommonPopup: UIViewController {
    
    private lazy var messageLabel: UILabel = {
        let lbl = UILabel()
        lbl.numberOfLines = 0
        lbl.textAlignment = .center
        lbl.textColor = Colors.authenticateColor
        lbl.font = UIFont.systemFont(ofSize: 17)
        return lbl
    }()
    
    private lazy var cancelButton: UIButton = {
        let btn = UIButton()
        btn.layer.borderWidth = 0.5
        btn.layer.cornerRadius = 5
        btn.backgroundColor = Colors.white
        btn.setTitleColor(Colors.authenticateColor, for: .normal)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        btn.layer.borderColor = Colors.authenticateColor.cgColor
        btn.addTarget(self, action: #selector(didCancel(_:)), for: .touchUpInside)
        return btn
    }()
    
    private lazy var okButton: UIButton = {
        let btn = UIButton()
        btn.layer.cornerRadius = 5
        btn.setTitleColor(Colors.white, for: .normal)
        btn.backgroundColor = Colors.authenticateColor
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        btn.addTarget(self, action: #selector(didOk(_:)), for: .touchUpInside)
        return btn
    }()
    
    lazy var stackContentView: UIStackView = {
        let stackView = UIStackView()
        stackView.distribution = .fill
        stackView.alignment = .fill
        stackView.axis = .vertical
        stackView.spacing = 10.widthRatio
        return stackView
    }()
    
    lazy var contentAlertView: UIView = {
        let view = UIView()
        view.backgroundColor = Colors.white
        view.layer.cornerRadius = 15
        view.layer.masksToBounds = true
        return view
    }()
    
    private lazy var dimmedBackgroundView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = UIColor.black.withAlphaComponent(0.3)
        return view
    }()
    
    typealias completionHandler = () -> ()
    private var titleString: String?
    private var messageString: String?
    private var okCommpletion: completionHandler?
    private var cancelCommpletion: completionHandler?
    
    internal required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private init(message: String?, okAction: completionHandler? = nil, cancelAction: completionHandler? = nil, showCancelButton: Bool) {
        super.init(nibName: nil, bundle: nil)
        self.titleString = title
        self.messageString = message
        self.messageLabel.text = message
        self.okCommpletion = okAction
        self.okButton.setTitle("OK", for: .normal)
        self.cancelCommpletion = cancelAction
        if showCancelButton {
            cancelButton.isHidden = false
        } else {
            cancelButton.isHidden = true
        }
    }
    
    private init(titleOk: String?, titleCancel: String?, message: String?, okAction: completionHandler? = nil, cancelAction: completionHandler? = nil, showCancelButton: Bool) {
        super.init(nibName: nil, bundle: nil)
        self.titleString = title
        self.messageString = message
        self.messageLabel.text = message
        self.okCommpletion = okAction
        self.cancelCommpletion = cancelAction
        self.okButton.setTitle(titleOk, for: .normal)
        self.cancelButton.setTitle(titleCancel, for: .normal)
        if titleOk == nil || titleOk == "" {
            self.okButton.setTitle("ok_button", for: .normal)
        }
        
        if titleCancel == nil || titleCancel == "" {
            self.cancelButton.setTitle("cancel_button", for: .normal)
        }
        
        
        if showCancelButton {
            cancelButton.isHidden = false
        } else {
            cancelButton.isHidden = true
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // settup view
        
        initLayout()
    }
    
    func initLayout() {
        self.view.addSubview(dimmedBackgroundView)
        self.view.addSubview(contentAlertView)
        self.contentAlertView.addSubviews(stackContentView)
        
        dimmedBackgroundView.snp.makeConstraints { (make) in
            make.trailing.leading.top.bottom.equalToSuperview()
        }
        
        contentAlertView.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
            make.width.equalTo(300.widthRatioIphoneX)
            make.height.greaterThanOrEqualTo(100.heightRatio).priorityLow()
        }
        
        stackContentView.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview().inset(15.widthRatio)
        }
        
        let stackButton = UIStackView(arrangedSubviews: [cancelButton, okButton])
        stackButton.axis = .horizontal
        stackButton.alignment = .center
        stackButton.distribution = .fillEqually
        stackButton.spacing = 20.widthRatio
        
        stackContentView.addArrangedSubview(messageLabel)
        stackContentView.addArrangedSubview(stackButton)
    }
    
    // MARK: show alert
    static func showAlert(_ message: String,
                          okCompletion: completionHandler? = nil,
                          cancelCompletion: completionHandler? = nil) {
        let alert = CommonPopup(message: message,okAction: okCompletion, cancelAction: cancelCompletion, showCancelButton: true)
        DispatchQueue.main.async(execute: {
            guard let viewController = UIViewController.topMostViewController() else { return }
            presentPopover(alert, viewController: viewController)
        })
    }
    
    static func showAlertOnlyOk(_ message: String,
                                title: String? = nil,
                                okCompletion: completionHandler? = nil) {
        let alert = CommonPopup(message: message, okAction: okCompletion, showCancelButton: false)
        DispatchQueue.main.async(execute: {
            guard let viewController = UIViewController.topMostViewController() else { return }
            presentPopover(alert, viewController: viewController)
        })
    }
    
    /// Show alert with button ok and button confirm
    /// - Parameters:
    ///   - titleOk: title button ok
    ///   - titleCancel: title button cancel
    ///   - message: message String
    ///   - title: title String
    ///   - okCompletion: -
    ///   - cancelCompletion: -
    static func showAlertWith( titleOk: String,  titleCancel: String, _ message: String,
                               okCompletion: completionHandler? = nil,
                               cancelCompletion: completionHandler? = nil) {
        let alert = CommonPopup(titleOk: titleOk, titleCancel: titleCancel ,message: message, okAction: okCompletion, cancelAction: cancelCompletion, showCancelButton: true)
        DispatchQueue.main.async(execute: {
            guard let viewController = UIViewController.topMostViewController() else { return }
            presentPopover(alert, viewController: viewController)
        })
    }
    
    /// Handle event when tap OK button
    /// - Parameter sender: button OK
    @objc func didOk(_ sender: UIButton) {
        guard let completion = okCommpletion else {
            dismiss(animated: true, completion: nil)
            return
        }
        dismiss(animated: true, completion: completion)
    }
    
    /// Handle event when tap Cancel button
    /// - Parameter sender: button Cancel
    @objc func didCancel(_ sender: UIButton) {
        guard let completion = cancelCommpletion else {
            dismiss(animated: true, completion: nil)
            return
        }
        dismiss(animated: true, completion: completion)
    }
    
    /// Display an alertDialog in the specified viewController.
    /// - Parameters:
    ///   - alert: alertDialog
    ///   - viewController: View to display alertDialog
    private static func presentPopover(_ alert: UIViewController, viewController: UIViewController) {
        alert.modalPresentationStyle = .overCurrentContext
        alert.modalTransitionStyle = .crossDissolve
        alert.definesPresentationContext = true
        viewController.present(alert, animated: true, completion: nil)
    }
}
