//
//  Colors.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 15/07/2022.
//

import Foundation
import UIKit

struct Colors {
    
    static let white = UIColor.white
    static let black = UIColor.black
    static let mainColor = #colorLiteral(red: 0.1450980392, green: 0.1921568627, blue: 0.4784313725, alpha: 1)
    static let backgroundDialogColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 0.6)
    static let colorSilverGround = #colorLiteral(red: 0.9411764706, green: 0.9568627451, blue: 0.968627451, alpha: 1)
    static let normalTextColor = #colorLiteral(red: 0.3882352941, green: 0.3882352941, blue: 0.3882352941, alpha: 1)
    static let authenticateColor = #colorLiteral(red: 0.05098039216, green: 0.3019607843, blue: 0.568627451, alpha: 1)
    static let priceColor = #colorLiteral(red: 0.7764705882, green: 0.4196078431, blue: 0.1568627451, alpha: 1)
    static let customGaryColor = #colorLiteral(red: 0.8941176471, green: 0.9019607843, blue: 0.9058823529, alpha: 1)
    static let customGreenColor = #colorLiteral(red: 0.1411764706, green: 0.5529411765, blue: 0.2666666667, alpha: 1)
    static let tomato = #colorLiteral(red: 1, green: 0.3882352941, blue: 0.2784313725, alpha: 1)
    static let colorD7FAE0 = #colorLiteral(red: 0.8431372549, green: 0.9803921569, blue: 0.8784313725, alpha: 1)
    static let color00AB56 = #colorLiteral(red: 0, green: 0.6705882353, blue: 0.337254902, alpha: 1)
    
//    export default colors = {
//        mainColor:"#25317a",
//        backgroundDialogColor:"rgba(0, 0, 0, 0.6)",
//        colorSilverGround:"#F0F4F7",
//        normalTextColor:"#636363",
//        authenticateColor: "#0d4d91",
//        priceColor: "#c66b28",
//        customGaryColor: "#e4e6e7",
//        customGreenColor: "#248d44",
//    }
}
