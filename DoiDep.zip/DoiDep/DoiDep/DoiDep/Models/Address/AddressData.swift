//
//  AddressData.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 18/07/2022.
//

import Foundation

struct AddressData: Codable {
    var ID: Int?
    var UserID: Int?
    var CustomerName: String?
    var Phone: String?
    var Province: Int?
    var ProvinceName: String?
    var District: Int?
    var DistrictName: String?
    var Ward: Int?
    var WardName: String?
    var Address: String?
    var AddressType: Int?
    var IsDefault: Bool?
    var Lat: Double?
    var Long: Double?
}

struct AddressParam: Codable {
    var UserID: Int?
    var CustomerName: String?
    var Phone: String?
    var Province: Int?
    var District: Int?
    var Ward: Int?
    var Address: String?
    var AddressType: Int?
    var IsDefault: Int?
    var Lat: Double?
    var Long: Double?
}

struct WardDistrictData: Codable {
    var ID: Int?
    var Name: String?
    var Prefix: String?
    var ProvinceID: Int?
    var DistrictID: Int?
    var DistrictName: String?
    var WardName: String?
    
    func getName() -> String? {
        return "\(Prefix ?? "") \(Name ?? "")"
    }
}
