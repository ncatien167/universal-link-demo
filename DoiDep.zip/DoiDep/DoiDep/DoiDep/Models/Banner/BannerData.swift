//
//  BannerData.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 16/07/2022.
//

import Foundation

struct BannerData: Codable {
    var ID: Int?
    var PositionID: Int?
    var Name: String?
//    var Summary: Int? // Unkown type data
    var LinkTo: String?
    var ImageUrl: String?
    var Status: Int?
    var CreatedAt: String?
    var CreatedBy: Int?
    var ModifiedAt: String?
    var ModifiedBy: Int?
}
