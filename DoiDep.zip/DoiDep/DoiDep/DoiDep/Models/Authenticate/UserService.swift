//
//  UserService.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 15/07/2022.
//

import Foundation

class UserService {
    
    static let shared = UserService()
    
    var isLoggedIn: Bool = false
    private var userData: UserData?
    
    private init() { }
    
    func setDataUser(with data: UserData) {
        self.userData = data
        self.isLoggedIn = true
    }
    
    func getDataUser() -> UserData {
        guard let userData = self.userData else {
            return UserData()
        }

        return userData
    }

    func removeDataUserService() {
        userData = nil
        isLoggedIn = false
    }
}
