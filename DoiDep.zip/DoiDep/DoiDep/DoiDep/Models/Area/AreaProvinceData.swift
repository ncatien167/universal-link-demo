//
//  AreaProvinceData.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 16/07/2022.
//

import Foundation

struct AreaProvinceData: Codable {
    var ID: Int?
    var Name: String?
    var Code: String?
}
