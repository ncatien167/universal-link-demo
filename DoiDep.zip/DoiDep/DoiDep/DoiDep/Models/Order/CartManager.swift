//
//  CartManager.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 18/07/2022.
//

import Foundation

class CartManager {
    static let shared = CartManager()
    private var cartData: [CartData]? = []
    private var voucher: Voucher?
    private init() { }
    
    func addNewCart(with product: ProductData?, ProductID: Int?, GroupID: Int?, Quantity: Int?, Note: String?) {
        for index in 0..<self.getDataCart().count {
            if self.getDataCart()[index].ProductID == ProductID && self.getDataCart()[index].GroupID == GroupID {
                self.cartData?[index].Quantity! += Quantity ?? 0
                return
            }
        }
        
        let cartData = CartData(ID: product?.ID, CategoryID: product?.CategoryID, CategoryName: product?.CategoryName, Name: product?.Name, Alias: product?.Alias, Thumbnail: product?.Thumbnail, InStock: product?.InStock, PriceStatus: product?.PriceStatus, Status: product?.Status, IsLove: product?.IsLove, Description: product?.Description, OptionGroups: product?.OptionGroups, Prices: product?.Prices, ProductID: ProductID, GroupID: GroupID, SKU: product?.SKU, Quantity: Quantity, Note: Note)
        self.cartData?.append(cartData)
    }
    
    func deleteItemCart(with index: Int) {
        if self.getDataCart().count == 0 || self.getDataCart().count < index {
            return
        }
        self.cartData?.remove(at: index)
    }
    
    func getDataCart() -> [CartData] {
        return self.cartData ?? []
    }
    
    func removeCart() {
        cartData = []
    }
    
    func updateQuantity(with index: Int, quantity: Int) {
        if index < self.getDataCart().count {
            self.cartData?[index].Quantity = quantity
        }
    }
    
    func totalMoneyAllProduct() -> Double {
        var total: Double = 0
        for cart in self.getDataCart() {
            total += cart.totalPriceDouble()
        }
        return total
    }
    
    func totalQuantity() -> Int {
        var total = 0
        for cart in self.getDataCart() {
            total += (cart.Quantity ?? 0)
        }
        return total
    }
    
    func totalMoneyAllProductTypeString() -> String {
        return totalMoneyAllProduct().formatMoney
    }
    
    func setVoucher(with data: Voucher?) {
        self.voucher = data
    }
    
    func voucherData() -> Voucher? {
        return self.voucher
    }
}
struct CartData: Codable {
    var ID: Int?
    var CategoryID: Int?
    var CategoryName: String?
    var Name: String?
    var Alias: String?
    var Thumbnail: String?
    var InStock: Int?
    var PriceStatus: Int?
    var Status: Int?
    var IsLove: Bool?
    var Description: String?
    var OptionGroups: [OptionGroups]?
    var Prices: [Prices]?
    
    var ProductID: Int?
    var GroupID: Int?
    var SKU: String?
    var Quantity: Int?
    var Note: String?
    
    func totalPrice() -> String {
        guard let Prices = Prices else {
            return "0đ"
        }
        
        var priceProduct: Double = 0
        
        if OptionGroups?.count == 0 {
            priceProduct = (Prices.first?.Price ?? 0) * Double((Quantity ?? 0))
        } else {
            for price in Prices {
                if price.GroupID == self.GroupID {
                    priceProduct = price.Price ?? 0
                    break
                }
            }
            priceProduct = priceProduct * Double((Quantity ?? 0))
        }
        
        return priceProduct.formatMoney
    }
    
    func totalPriceDouble() -> Double {
        guard let Prices = Prices else {
            return 0
        }
        var priceProduct: Double = 0
        
        if OptionGroups?.count == 0 {
            priceProduct = (Prices.first?.Price ?? 0) * Double((Quantity ?? 0))
        } else {
            for price in Prices {
                if price.GroupID == self.GroupID {
                    priceProduct = price.Price ?? 0
                    break
                }
            }
            priceProduct = priceProduct * Double((Quantity ?? 0))
        }
        
        return priceProduct
    }
    
    func totalPrice(with Quantity: Int) -> String {
        guard let Prices = Prices else {
            return "0đ"
        }
        var priceProduct: Double = 0
        
        if OptionGroups?.count == 0 {
            priceProduct = (Prices.first?.Price ?? 0) * Double(Quantity)
        } else {
            for price in Prices {
                if price.GroupID == self.GroupID {
                    priceProduct = price.Price ?? 0
                    break
                }
            }
            priceProduct = priceProduct * Double(Quantity)
        }
        
        return priceProduct.formatMoney
    }
    
    func price() -> String {
        guard let Prices = Prices else {
            return "0đ"
        }
        var priceProduct: Double = 0
        
        if OptionGroups?.count == 0 {
            priceProduct = Prices.first?.Price ?? 0
        } else {
            for price in Prices {
                if price.GroupID == self.GroupID {
                    priceProduct = price.Price ?? 0
                    break
                }
            }
        }
        
        return priceProduct.formatMoney
    }
    
    func priceDouble() -> Double {
        guard let Prices = Prices else {
            return 0
        }
        var priceProduct: Double = 0
        
        if OptionGroups?.count == 0 {
            priceProduct = Prices.first?.Price ?? 0
        } else {
            for price in Prices {
                if price.GroupID == self.GroupID {
                    priceProduct = price.Price ?? 0
                    break
                }
            }
        }
        
        return priceProduct
    }
    
    func groupName() -> String {
        guard let Prices = Prices else {
            return ""
        }
        var groupName: String = ""
        for price in Prices {
            if price.GroupID == self.GroupID {
                groupName = price.Details?.first?.Value ?? ""
                break
            }
        }
        return groupName
    }
}


