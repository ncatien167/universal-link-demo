//
//  StoreData.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 16/07/2022.
//

import Foundation

struct StoreData: Codable {
    var ID: Int?
    var StoreName: String?
    var StoreAddress: String?
    var ProvinceID: Int?
    var Lat: Double?
    var Long: Double?
    var Status: Int?
    var CreatedAt: String?
    var CreatedBy: Int?
    var ModifiedAt: String?
    var ModifiedBy: Int?
    var km: Double?
}
