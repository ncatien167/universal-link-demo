//
//  BookingService.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 13/4/25.
//

import Foundation
struct BookingService {
    
    static func requestGetHotels(completion: (([BookingHotel]?) -> Void)? = nil) {
        APIController.request([BookingHotel].self, .bookingHotels, params: nil) { error, data in
            if let _ = error {
                completion?([])
                return
            }
            
            completion?(data)
        }
    }
    
    static func requestSearchHotels(params: [String:Any], completion: ((Hotel?) -> Void)? = nil) {
        APIController.request(Hotel.self, .bookingHotelsSearch, params: params) { error, data in
            if let _ = error {
                completion?(nil)
                return
            }
            
            completion?(data)
        }
    }
    
    static func requestHistoryHotels(completion: (([Booking]?) -> Void)? = nil) {
        APIController.request([Booking].self, .bookingGets, params: nil) { error, data in
            if let _ = error {
                completion?(nil)
                return
            }
            
            completion?(data)
        }
    }
    
    static func requestDeleteBooking(params: [String:Any], completion: ((ResponseMessage?) -> Void)? = nil) {
        APIController.request(ResponseMessage.self, .bookingDelete, params: params) { error, data in
            if let _ = error {
                completion?(data)
                return
            }
            
            completion?(data)
        }
    }
    
    static func requestPaymentBooking(params: [String:Any], completion: ((String?) -> Void)? = nil) {
        APIController.request(String.self, .bookingPayment, params: params) { error, data in
            if let _ = error {
                completion?(nil)
                return
            }
            
            completion?(data)
        }
    }
}

struct BookingHotel: Codable {
    var Code: String?
    var Name: String?
    var ImageHost: String?
}

struct Hotel: Codable {
    let hotel: String?
    let hotelAddress: String?
    let hotelArea: String?
    let availableRoom: [Room]?
}

struct Room: Codable {
    let roomType: String?
    let roomKind: String?
    let roomTypeCode: Int?
    let roomKindCode: Int?
    let adults: Int?
    let availableRoomNum: Int?
    let price: Double?
    let image: [String]?
    let detail: [String]?
    let policy: [String]?
    let roomConvinient: String?
}

struct Booking: Codable {
    let ID: String?
    let UserID: Int?
    let BookingName: String?
    let ArrivalDate: String?
    let CheckoutDate: String?
    let Contact: String?
    let Note: String?
    let Email: String?
    let PartnerBookingID: Int?
    let PartnerBookingStatus: String?
    let PartnerBookingMessage: String?
    let CreatedAt: String?
    let ModifiedAt: String?
}
