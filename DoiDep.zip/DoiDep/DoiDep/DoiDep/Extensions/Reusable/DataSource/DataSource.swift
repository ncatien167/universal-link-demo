//
//  DataSource.swift
//
//  Copyright © 2018. All rights reserved.
//

import UIKit

class DataSource<Model: Any>: NSObject {
    
    var dataProvider: DataProvider<Model>
    
    var loadMore: (()->())?
    var onChangeReachedLastItem: (()->())?
    var onFetching: (()->())?
    var isReachedLastItem: Bool {
        didSet {
            onChangeReachedLastItem?()
        }
    }
    var isFetching: Bool {
        didSet {
            onFetching?()
        }
    }
    
    init(dataProvider: DataProvider<Model>) {
        self.dataProvider = dataProvider
        self.isFetching = false
        self.isReachedLastItem = false
    }
    
    func loadMoreIfNeeded(at index: Int) {
        
        guard !isFetching,
            !isReachedLastItem,
            loadMore != nil,
            index == dataProvider.data.count - 1
            else { return }
        
        isFetching = true
        loadMore?()
        
    }
    
}
