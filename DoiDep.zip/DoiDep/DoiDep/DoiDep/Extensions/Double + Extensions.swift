//
//  Double + Extensions.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 17/07/2022.
//

import UIKit

extension Double {
    var formatMoney: String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = Locale(identifier: "vi")
        formatter.numberStyle = .decimal
        
        guard let formattedString = formatter.string(from: self as NSNumber) else {
            return "0đ"
        }
        return formattedString + "đ"
    }
    
    var formatMoneyBooking: String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = Locale(identifier: "vi")
        formatter.numberStyle = .decimal
        
        guard let formattedString = formatter.string(from: self as NSNumber) else {
            return "0đ"
        }
        return formattedString + " đ"
    }
}
