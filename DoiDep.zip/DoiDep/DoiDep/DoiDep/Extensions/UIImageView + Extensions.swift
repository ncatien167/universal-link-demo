//
//  UIImageView + Extensions.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 19/07/2022.
//

import UIKit
import AVFoundation
import ImageIO

let imageCacheDoiDep = NSCache<AnyObject,AnyObject>()
extension UIImageView {
    func loadImage(urlString: String, _ image: UIImage) {
          // set image default
          self.image = image
          
          //check imageCache
          if let cachedImage = imageCacheDoiDep.object(forKey: urlString as AnyObject) as? UIImage {
               self.image = cachedImage
               return
          }
          
          //othrwise fire off a new download
          if let url:URL = URL(string: urlString) {
               URLSession.shared.dataTask(with: url, completionHandler: { (data, response, error) in
                    if error != nil{
                         print(error ?? "")
                         return
                    }
                    DispatchQueue.main.async(execute: {
                         if let downloadImage = UIImage(data: data!) {
                             imageCacheDoiDep.setObject(downloadImage, forKey: urlString as AnyObject)
                              self.image = downloadImage
                         }
                    })
               }).resume()
          }
     }
     
     func changeToColor(_ color: UIColor) {
          if let img = self.image {
               self.image = img.withRenderingMode(.alwaysTemplate)
               self.tintColor = color
          }
     }
}
