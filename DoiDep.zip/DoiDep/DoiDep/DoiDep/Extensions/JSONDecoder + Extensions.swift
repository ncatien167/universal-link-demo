//
//  JSONDecoder + Extensions.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 15/07/2022.
//

import Foundation

extension JSONDecoder {
    
    static func decode<T: Decodable>(_ type: T.Type, from data: Data?, completion: (_ error: String?,_ result: T?) -> Void) {
        
        guard let data = data else {
            completion("The data couldn't be read because it is missing", nil)
            return
        }
    
        let responseJson = String(data: data, encoding: .utf8)
        Logger.log(message: responseJson ?? "No json response", event: .info)
        
        let jsonDecoder = JSONDecoder()
        jsonDecoder.keyDecodingStrategy = .convertFromSnakeCase

        do {
            let result = try jsonDecoder.decode(type, from: data)
            completion(nil, result)
        } catch (let error) {
            completion(error.localizedDescription, nil)
            Logger.log(message: "\(error)", event: .error)
        }
        
    }
    
}
