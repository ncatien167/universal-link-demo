//
//  Date + Extensions.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 15/07/2022.
//

import Foundation

extension Date {
    
    private static let formatter: DateFormatter = {
        return DateFormatter()
    }()
        
    func toString(dateFormat format: String) -> String {
        let dateFormatter = Date.formatter
        dateFormatter.dateFormat = format
        dateFormatter.locale = Locale(identifier: "vi")
        return dateFormatter.string(from: self)
    }
    
    func parseToDateTime(dateFormat format: String = "dd MMM") -> String {
        
        if Calendar.current.isDateInToday(self) {
            let dateFormatter = Date.formatter
            dateFormatter.locale = Locale(identifier: "vi")
            dateFormatter.dateFormat = "hh:mma"
            return dateFormatter.string(from: self)
        }
        
        return toString(dateFormat: format)
        
    }
    
    func currentDate() -> Date {
         let formatter = DateFormatter()
         formatter.dateFormat = "dd/MM/yyyy"
         formatter.timeZone = TimeZone(identifier: "UTC")
         formatter.locale = Locale(identifier: "vi_VN")
         let dateString = formatter.string(from: Date())
         let date = formatter.date(from: dateString)
         return date ?? Date()
    }
    
}

extension DateFormatter {
     
     func dateformatter(_ format: String = "dd/MM/yyyy | HH:mm") -> DateFormatter {
          let dateFormatter = DateFormatter()
          dateFormatter.dateStyle = DateFormatter.Style.long
          dateFormatter.dateFormat = format
          dateFormatter.locale = NSLocale(localeIdentifier: "vi_VN") as Locale
          return dateFormatter
     }
}

extension Date {
    func removeTime() -> Date {
        let calendar = Calendar.current
        return calendar.startOfDay(for: self)
    }
}
