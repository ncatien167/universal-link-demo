//
//  CGFloat + Extensions.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 15/07/2022.
//

import UIKit

extension CGFloat {
    
    var widthRatio: CGFloat {
        return floor(self * ScreenSize.SCREEN_WIDTH / ScreenSize.IPX_WIDTH)
    }
    
    var widthRatioIphoneX: CGFloat {
        if DeviceType.isIpad() {
            return floor(CGFloat(self) * 575 / ScreenSize.IPX_WIDTH)
        }
        return floor(CGFloat(self) * ScreenSize.SCREEN_WIDTH / ScreenSize.IPX_WIDTH)
    }
    
    var heightRatio: CGFloat {
        return floor(self * ScreenSize.SCREEN_HEIGHT / ScreenSize.IPX_HEIGHT)
    }
    
}

extension Int {
    var widthRatio: CGFloat {
        return floor(CGFloat(self) * ScreenSize.SCREEN_WIDTH / ScreenSize.IPX_WIDTH)
    }
    
    var widthRatioIphoneX: CGFloat {
        if DeviceType.isIpad() {
            return floor(CGFloat(self) * 575 / ScreenSize.IPX_WIDTH)
        }
        return floor(CGFloat(self) * ScreenSize.SCREEN_WIDTH / ScreenSize.IPX_WIDTH)
    }
    
    var heightRatio: CGFloat {
        return floor(CGFloat(self) * ScreenSize.SCREEN_HEIGHT / ScreenSize.IPX_HEIGHT)
    }
}

extension Double {
    var widthRatio: CGFloat {
        return floor(CGFloat(self) * ScreenSize.SCREEN_WIDTH / ScreenSize.IPX_WIDTH)
    }
    
    var widthRatioIphoneX: CGFloat {
        if DeviceType.isIpad() {
            return floor(CGFloat(self) * 575 / ScreenSize.IPX_WIDTH)
        }
        return floor(CGFloat(self) * ScreenSize.SCREEN_WIDTH / ScreenSize.IPX_WIDTH)
    }
    
    var heightRatio: CGFloat {
        return floor(CGFloat(self) * ScreenSize.SCREEN_HEIGHT / ScreenSize.IPX_HEIGHT)
    }
}

enum UIUserInterfaceIdiom : Int
{
    case Unspecified
    case Phone
    case Pad
}

struct ScreenSize
{
    static let SCREEN_WIDTH              = UIScreen.main.bounds.size.width
    static let SCREEN_HEIGHT             = UIScreen.main.bounds.size.height
    static let SCREEN_MAX_LENGTH         = max(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
    static let SCREEN_MIN_LENGTH         = min(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
    static let IP6_WIDTH: CGFloat        = 375.0
    static let IPX_HEIGHT: CGFloat       = 812.0
    static let IPX_WIDTH: CGFloat        = 375.0
    static let RATIO_IPAD_FONT: CGFloat  = 1.2
    
}

struct DeviceType
{
    static let IS_IPHONE_4_OR_LESS  = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH < 568.0
    static let IS_IPHONE_5          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 568.0
    static let IS_IPHONE_6          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 667.0
    static let IS_IPHONE_6P         = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 736.0
    static let IS_IPHONE_X          = UIDevice.current.userInterfaceIdiom == .phone &&
    ScreenSize.SCREEN_MAX_LENGTH == 812.0
    static let IS_IPAD              = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1024.0
    static let IS_IPAD_PRO          = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1366.0
    
    static let IS_NORMAL_IPHONE     = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 736.0
    static let IS_NOTCH_IPHONE      = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH >= 812.0
    static let IS_COMMON_IPAD       = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH >= 1024.0
    
    static func isIpad() -> Bool {
        if DeviceType.IS_IPAD || DeviceType.IS_IPAD_PRO || DeviceType.IS_COMMON_IPAD {
            return true
        }
        
        return false
    }
    
    static func isIphoneX() -> Bool {
         var isIphoneX = false
         if UIDevice.current.modelName == Model.iPhoneX.rawValue || UIDevice.current.modelName == Model.iPhoneXR.rawValue || UIDevice.current.modelName == Model.iPhoneXS.rawValue || UIDevice.current.modelName == Model.iPhoneXSmax.rawValue || UIDevice.current.modelName == Model.iPhone11.rawValue || UIDevice.current.modelName == Model.iPhone11Pro.rawValue || UIDevice.current.modelName == Model.iPhone11ProMax.rawValue ||
              UIDevice.current.modelName == Model.iPhone12mini.rawValue ||
              UIDevice.current.modelName == Model.iPhone12.rawValue ||
              UIDevice.current.modelName == Model.iPhone12Pro.rawValue ||
              UIDevice.current.modelName == Model.iPhone12ProMax.rawValue ||
                UIDevice.current.modelName == Model.iPhone13.rawValue ||
                UIDevice.current.modelName == Model.iPhone13mini.rawValue ||
                UIDevice.current.modelName == Model.iPhone13Pro.rawValue ||
                UIDevice.current.modelName == Model.iPhone13ProMax.rawValue ||
                UIDevice.current.modelName == Model.iPhone14.rawValue ||
                UIDevice.current.modelName == Model.iPhone14Pro.rawValue ||
                UIDevice.current.modelName == Model.iPhone14Plus.rawValue ||
                UIDevice.current.modelName == Model.iPhone14ProMax.rawValue {
              isIphoneX = true
         } else {
              isIphoneX = false
         }
         return isIphoneX
    }
}

extension UIDevice {
     var modelName: String {
          var systemInfo = utsname()
          uname(&systemInfo)
          let machineMirror = Mirror(reflecting: systemInfo.machine)
          let identifier = machineMirror.children.reduce("") { identifier, element in
               guard let value = element.value as? Int8, value != 0 else { return identifier }
               return identifier + String(UnicodeScalar(UInt8(value)))
          }
          
          switch identifier {
          case "iPod5,1":                                 return "iPod Touch 5"
          case "iPod7,1":                                 return "iPod Touch 6"
          case "iPhone3,1", "iPhone3,2", "iPhone3,3":     return "iPhone 4"
          case "iPhone4,1":                               return "iPhone 4s"
          case "iPhone5,1", "iPhone5,2":                  return "iPhone 5"
          case "iPhone5,3", "iPhone5,4":                  return "iPhone 5c"
          case "iPhone6,1", "iPhone6,2":                  return "iPhone 5s"
          case "iPhone7,2":                               return "iPhone 6"
          case "iPhone7,1":                               return "iPhone 6 Plus"
          case "iPhone8,1":                               return "iPhone 6s"
          case "iPhone8,2":                               return "iPhone 6s Plus"
          case "iPhone9,1", "iPhone9,3":                  return "iPhone 7"
          case "iPhone9,2", "iPhone9,4":                  return "iPhone 7 Plus"
          case "iPhone8,4":                               return "iPhone SE"
          case "iPhone10,1", "iPhone10,4":                return "iPhone 8"
          case "iPhone10,2", "iPhone10,5":                return "iPhone 8 Plus"
          case "iPhone10,3", "iPhone10,6":                return "iPhone X"
          case "iPhone11,2":                              return "iPhone XS"
          case "iPhone11,4", "iPhone11,6":                return "iPhone XS Max"
          case "iPhone11,8":                              return "iPhone XR"
          case "iPhone12,1":                              return "iPhone 11"
          case "iPhone12,3":                              return "iPhone 11 Pro"
          case "iPhone12,5":                              return "iPhone 11 Pro Max"
          case "iPhone12,8":                              return "iPhone SE (2nd generation)"
          case "iPhone13,1":                              return "iPhone 12 mini"
          case "iPhone13,2":                              return "iPhone 12"
          case "iPhone13,3":                              return "iPhone 12 Pro"
          case "iPhone13,4":                              return "iPhone 12 Pro Max"
          case "iPhone14,4":                              return "iPhone 13 mini"
          case "iPhone14,5":                              return "iPhone 13"
          case "iPhone14,2":                              return "iPhone 13 Pro"
          case "iPhone14,3":                              return "iPhone 13 Pro Max"
          case "iPhone14,7":                              return "iPhone 14"
          case "iPhone14,8":                              return "iPhone 14 Plus"
          case "iPhone15,2":                              return "iPhone 14 Pro"
          case "iPhone15,3":                              return "iPhone 14 Pro Max"
          case "iPad2,1", "iPad2,2", "iPad2,3", "iPad2,4":return "iPad 2"
          case "iPad3,1", "iPad3,2", "iPad3,3":           return "iPad 3"
          case "iPad3,4", "iPad3,5", "iPad3,6":           return "iPad 4"
          case "iPad4,1", "iPad4,2", "iPad4,3":           return "iPad Air"
          case "iPad5,3", "iPad5,4":                      return "iPad Air 2"
          case "iPad6,11", "iPad6,12":                    return "iPad 5"
          case "iPad7,5", "iPad7,6":                      return "iPad 6"
          case "iPad2,5", "iPad2,6", "iPad2,7":           return "iPad Mini"
          case "iPad4,4", "iPad4,5", "iPad4,6":           return "iPad Mini 2"
          case "iPad4,7", "iPad4,8", "iPad4,9":           return "iPad Mini 3"
          case "iPad5,1", "iPad5,2":                      return "iPad Mini 4"
          case "iPad6,3", "iPad6,4":                      return "iPad Pro 9.7 Inch"
          case "iPad6,7", "iPad6,8":                      return "iPad Pro 12.9 Inch"
          case "iPad7,1", "iPad7,2":                      return "iPad Pro (12.9-inch) (2nd generation)"
          case "iPad7,3", "iPad7,4":                      return "iPad Pro (10.5-inch)"
          case "iPad8,1", "iPad8,2", "iPad8,3", "iPad8,4":return "iPad Pro (11-inch)"
          case "iPad8,5", "iPad8,6", "iPad8,7", "iPad8,8":return "iPad Pro (12.9-inch) (3rd generation)"
          case "AppleTV5,3":                              return "Apple TV"
          case "AppleTV6,2":                              return "Apple TV 4K"
          case "AudioAccessory1,1":                       return "HomePod"
          default:                                        return identifier
          }
     }
}

public enum Model : String {
     case simulator   = "simulator/sandbox",
     iPod1            = "iPod 1",
     iPod2            = "iPod 2",
     iPod3            = "iPod 3",
     iPod4            = "iPod 4",
     iPod5            = "iPod 5",
     iPad2            = "iPad 2",
     iPad3            = "iPad 3",
     iPad4            = "iPad 4",
     iPhone4          = "iPhone 4",
     iPhone4S         = "iPhone 4S",
     iPhone5          = "iPhone 5",
     iPhone5S         = "iPhone 5S",
     iPhone5C         = "iPhone 5C",
     iPadMini1        = "iPad Mini 1",
     iPadMini2        = "iPad Mini 2",
     iPadMini3        = "iPad Mini 3",
     iPadAir1         = "iPad Air 1",
     iPadAir2         = "iPad Air 2",
     iPadPro9_7       = "iPad Pro 9.7\"",
     iPadPro9_7_cell  = "iPad Pro 9.7\" cellular",
     iPadPro10_5      = "iPad Pro 10.5\"",
     iPadPro10_5_cell = "iPad Pro 10.5\" cellular",
     iPadPro12_9      = "iPad Pro 12.9\"",
     iPadPro12_9_cell = "iPad Pro 12.9\" cellular",
     iPhone6          = "iPhone 6",
     iPhone6plus      = "iPhone 6 Plus",
     iPhone6S         = "iPhone 6S",
     iPhone6Splus     = "iPhone 6S Plus",
     iPhoneSE         = "iPhone SE",
     iPhone7          = "iPhone 7",
     iPhone7plus      = "iPhone 7 Plus",
     iPhone8          = "iPhone 8",
     iPhone8plus      = "iPhone 8 Plus",
     iPhoneX          = "iPhone X",
     iPhoneXS         = "iPhone XS",
     iPhoneXSmax      = "iPhone XS Max",
     iPhoneXR         = "iPhone XR",
     iPhone11         = "iPhone 11",
     iPhone11Pro      = "iPhone 11 Pro",
     iPhone11ProMax   = "iPhone 11 Pro Max",
     iPhone12mini     = "iPhone 12 mini",
     iPhone12         = "iPhone 12",
     iPhone12Pro      = "iPhone 12 Pro",
     iPhone12ProMax   = "iPhone 12 Pro Max",
     iPhone13mini     = "iPhone 13 mini",
     iPhone13         = "iPhone 13",
     iPhone13Pro      = "iPhone 13 Pro",
     iPhone13ProMax   = "iPhone 13 Pro Max",
      iPhone14         = "iPhone 14",
      iPhone14Plus     = "iPhone 14 Plus",
      iPhone14Pro      = "iPhone 14 Pro",
      iPhone14ProMax   = "iPhone 14 Pro Max",
     unrecognized     = "?unrecognized?"
}

extension Formatter {
     static let withSeparator: NumberFormatter = {
          let formatter = NumberFormatter()
          formatter.locale = Locale(identifier: "vi_VN")
          formatter.groupingSeparator = "."
          formatter.numberStyle = .decimal
          return formatter
     }()
}

extension UInt64 {
     var formattedWithSeparator: String {
          return Formatter.withSeparator.string(for: self) ?? ""
     }
}

extension Double {
     var formattedWithSeparator: String {
          return Formatter.withSeparator.string(for: self) ?? ""
     }
     
     func round(to places: Int) -> Double {
          let divisor = pow(10.0, Double(places))
          return Darwin.round(self * divisor) / divisor
     }

}
