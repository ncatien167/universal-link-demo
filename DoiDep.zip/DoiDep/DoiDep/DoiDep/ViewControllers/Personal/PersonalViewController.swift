//
//  PersonalViewController.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 19/07/2022.
//

import UIKit

class PersonalViewController: BackNavigationVC {

    lazy var contentView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        return view
    }()
    
    lazy var imageAvatar: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleToFill
        imageView.layer.cornerRadius = 40.heightRatio
        imageView.layer.masksToBounds = true
        return imageView
    }()
    
    lazy var labelName: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.systemFont(ofSize: 16, weight: .regular)
        return label
    }()
    
    lazy var labelPhone: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.systemFont(ofSize: 15, weight: .regular)
        return label
    }()
    
    lazy var buttonAddress: PersonalButtonView = {
        let button = PersonalButtonView()
        button.setup(title: "Địa chỉ giao hàng", leftImage: UIImage().getImage(with: "ic_location", and: Bundle(for: PersonalViewController.self))!, rightImage: UIImage().getImage(with: "ic_right_arrow_main", and: Bundle(for: PersonalViewController.self))!)
        button.didTap = { [weak self] in
            guard let self = self else { return }
            self.didTapAddress()
        }
        return button
    }()
    
    lazy var buttonMyOrder: PersonalButtonView = {
        let button = PersonalButtonView()
        button.setup(title: "Đơn hàng của bạn", leftImage: UIImage().getImage(with: "ic_yourcart", and: Bundle(for: PersonalViewController.self))!, rightImage: UIImage().getImage(with: "ic_right_arrow_main", and: Bundle(for: PersonalViewController.self))!)
        button.didTap = { [weak self] in
            guard let self = self else { return }
            self.didTapMyOrder()
        }
        return button
    }()
    
    lazy var buttonLogOut: UIButton = {
        let button = UIButton()
        button.setTitle("Đăng xuất", for: .normal)
        button.setTitleColor(Colors.authenticateColor, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .light)
        button.addTarget(self, action: #selector(didTapLogout), for: .touchUpInside)
        return button
    }()
    
    // MARK: - Properties
   
    var didGoToAddress: (()->())?
    var didGoToMyOrder: (()->())?
    var didTapBack: (()->())?
    
    // MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    private func setupUI() {
        self.view.addSubview(contentView)
        contentView.snp.makeConstraints { make in
            make.top.equalTo(headerView.snp.bottom)
            make.bottom.leading.trailing.equalToSuperview()
        }
        
        let userView = UIView()
        let backgroundName = UIImageView(image: UIImage().getImage(with: "bg_bottom_bar", and: Bundle(for: PersonalViewController.self))!)
        backgroundName.layer.cornerRadius = 10
        backgroundName.layer.masksToBounds = true
        backgroundName.contentMode = .scaleToFill
        userView.addSubviews(backgroundName, imageAvatar)
        contentView.addSubview(userView)
        
        userView.snp.makeConstraints { make in
            make.top.equalTo(headerView.snp.bottom).offset(15.heightRatio)
            make.leading.trailing.equalToSuperview()
        }
        
        backgroundName.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.height.equalTo(60.heightRatio)
            make.trailing.equalToSuperview().inset(15.heightRatio)
            make.leading.equalToSuperview().inset(50.heightRatio)
        }
        
        imageAvatar.snp.makeConstraints { make in
            make.leading.equalToSuperview().inset(15.heightRatio)
            make.top.bottom.equalToSuperview()
            make.width.height.equalTo(80.heightRatio)
        }

        let stackViewName = UIStackView(arrangedSubviews: [labelName, labelPhone])
        stackViewName.axis = .vertical
        stackViewName.alignment = .fill
        stackViewName.distribution = .fillEqually
        stackViewName.spacing = 5
        
        userView.addSubview(stackViewName)
        stackViewName.snp.makeConstraints { make in
            make.leading.equalTo(imageAvatar.snp.trailing).offset(10.widthRatio)
            make.trailing.equalToSuperview().inset(20.widthRatio)
            make.centerY.equalToSuperview()
        }
        
        let stackButton = UIStackView(arrangedSubviews: [buttonMyOrder, buttonAddress])
        stackButton.axis = .vertical
        stackButton.alignment = .center
        stackButton.distribution = .fill
        stackButton.spacing = 15.heightRatio
        
        contentView.addSubview(stackButton)
        stackButton.snp.makeConstraints { make in
            make.top.equalTo(userView.snp.bottom).offset(15.heightRatio)
            make.leading.trailing.equalToSuperview()
        }
        
        buttonAddress.setConstraintWidth(constant: 345.widthRatio)
        buttonMyOrder.setConstraintWidth(constant: 345.widthRatio)
        
        contentView.addSubview(buttonLogOut)
        buttonLogOut.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.width.equalTo(130.widthRatio)
            make.bottom.equalToSuperview().inset(30.heightRatio)
        }
    }
    
    override func setUpLeftBarButton() {
        let backButtonItem = UIBarButtonItem(image: UIImage().getImage(with: "ic_close_white", and: Bundle(for: PersonalViewController.self))!, style: .plain, target: self, action: #selector(self.backAction))
        firstNavItem?.leftBarButtonItem = backButtonItem
        firstNavItem?.leftBarButtonItem?.tintColor = .white
    }
    
    func setupData() {
        DispatchQueue.main.async {
            if let urlImage = UserService.shared.getDataUser().Avatar {
                self.imageAvatar.loadImage(urlString: urlImage, UIImage().getImage(with: "ic_personal_avatar_male", and: Bundle(for: PersonalViewController.self))!)
            } else {
                self.imageAvatar.image = UIImage().getImage(with: "ic_personal_avatar_male", and: Bundle(for: PersonalViewController.self))!
            }
            self.labelName.text = UserService.shared.getDataUser().FullName
            self.labelPhone.text = UserService.shared.getDataUser().Phone
        }
    }
    
    private func didTapAddress() {
        didGoToAddress?()
    }
    
    private func didTapMyOrder() {
        didGoToMyOrder?()
    }
    
    override func backAction() {
        self.didTapBack?()
    }
    
    @objc private func didTapLogout() {
        CommonPopup.showAlertWith(titleOk: "Đồng ý", titleCancel: "Trở lại", "Bạn có muốn đăng xuất?") {
            DoiDep.shared.delegate?.onLogOut()
            CartManager.shared.removeCart()
            self.didTapBack?()
        } cancelCompletion: {
            
        }
    }
}
