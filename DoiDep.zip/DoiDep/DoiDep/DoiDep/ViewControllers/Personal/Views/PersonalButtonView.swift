//
//  File.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 31/07/2022.
//

import UIKit

class PersonalButtonView: UIView {
    
    lazy var leftIcon: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    lazy var labelTitle: UILabel = {
        let label = UILabel()
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 16, weight: .light)
        return label
    }()
    
    lazy var rightIcon: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    lazy var button: UIButton = {
        let button = UIButton()
        button.addTarget(self, action: #selector(didTapButton), for: .touchUpInside)
        return button
    }()
    
    var didTap: (()->())?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        let stackView = UIStackView(arrangedSubviews: [leftIcon, labelTitle, rightIcon])
        stackView.axis = .horizontal
        stackView.alignment = .center
        stackView.distribution = .fill
        stackView.spacing = 10
        self.addSubview(stackView)
        stackView.snp.makeConstraints { make in
            make.top.bottom.equalToSuperview()
            make.leading.trailing.equalToSuperview().inset(10.widthRatio)
        }
        leftIcon.setConstraintWidthAndHeight(widthConstant: 30.heightRatio, heightConstant: 30.heightRatio)
        rightIcon.setConstraintWidthAndHeight(widthConstant: 20.heightRatio, heightConstant: 20.heightRatio)
        
        self.addSubview(button)
        button.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview()
        }
        
        stackView.layoutMargins = UIEdgeInsets(top: 5.heightRatio, left: 5.widthRatio, bottom: 5.heightRatio, right: 0)
        stackView.isLayoutMarginsRelativeArrangement = true
        
        self.layer.cornerRadius = 10
        self.layer.borderWidth = 0.5
        self.layer.borderColor = Colors.mainColor.cgColor
    }
    
    @objc private func didTapButton() {
        didTap?()
    }
    
    func setup(title: String, leftImage: UIImage?, rightImage: UIImage?) {
        labelTitle.text = title
        leftIcon.image = leftImage
        rightIcon.image = rightImage
    }
}
