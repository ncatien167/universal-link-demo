//
//  MyOrderInfoView.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 07/08/2022.
//

import UIKit

class MyOrderInfoView: UIView {

    lazy var labelMoney: UILabel = {
        let label = UILabel()
        label.textAlignment = .right
        label.textColor = Colors.normalTextColor
        label.font = UIFont.systemFont(ofSize: 14, weight: .light)
        return label
    }()
    
    lazy var labelTotalAmount: UILabel = {
        let label = UILabel()
        label.textAlignment = .left
        label.textColor = Colors.mainColor
        label.font = UIFont.systemFont(ofSize: 15, weight: .light)
        return label
    }()
    
    lazy var labelPromosMoney: UILabel = {
        let label = UILabel()
        label.textAlignment = .right
        label.textColor = Colors.customGreenColor
        label.font = UIFont.systemFont(ofSize: 14, weight: .light)
        return label
    }()
    
    lazy var stackPromos: UIStackView = {
        let stackPromos = UIStackView()
        stackPromos.isHidden = true
        stackPromos.spacing = 10
        stackPromos.axis = .horizontal
        stackPromos.alignment = .fill
        stackPromos.distribution = .fill
        return stackPromos
    }()
    
    lazy var labelTotalMoney: UILabel = {
        let label = UILabel()
        label.textAlignment = .right
        label.textColor = Colors.mainColor
        label.font = UIFont.systemFont(ofSize: 14, weight: .light)
        return label
    }()
    
    lazy var buttonTermDelivery: UIButton = {
        let button = UIButton()
        button.setTitle("Chính sách vận chuyển", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        button.setImage(UIImage().getImage(with: "ic_info", and: Bundle(for: OrderInfoView.self))!, for: .normal)
        button.setTitleColor(Colors.mainColor, for: .normal)
        button.imageView?.contentMode = .scaleAspectFit
        button.imageView?.changeToColor(Colors.mainColor)
        button.imageEdgeInsets = UIEdgeInsets(top: 0, left: 183.widthRatio, bottom: 0, right: 0)
        button.addTarget(self, action: #selector(didTapDeliveryVatButton), for: .touchUpInside)
        return button
    }()
    
    // MARK: - Properties
    
    var didTapDeliveryTermInfo: (()->())?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        let labelProvisional = UILabel()
        labelProvisional.text = "Tạm tính"
        labelProvisional.textColor = Colors.normalTextColor
        labelProvisional.font = UIFont.systemFont(ofSize: 14, weight: .regular)
        
        let stackProvisional = UIStackView(arrangedSubviews: [labelProvisional, labelMoney])
        stackProvisional.spacing = 10
        stackProvisional.axis = .horizontal
        stackProvisional.alignment = .fill
        stackProvisional.distribution = .fill
        
        let labelDeliveryVat = UILabel()
        labelDeliveryVat.text = "Phí vận chuyển"
        labelDeliveryVat.textColor = Colors.normalTextColor
        labelDeliveryVat.font = UIFont.systemFont(ofSize: 14, weight: .regular)
        
        let stackDeliveryVat = UIStackView(arrangedSubviews: [labelDeliveryVat, buttonTermDelivery])
        stackDeliveryVat.spacing = 10
        stackDeliveryVat.axis = .horizontal
        stackDeliveryVat.alignment = .fill
        stackDeliveryVat.distribution = .fill
        
        let labelPromos = UILabel()
        labelPromos.text = "Khuyến mãi"
        labelPromos.textColor = Colors.customGreenColor
        labelPromos.font = UIFont.systemFont(ofSize: 14, weight: .regular)
        
        stackPromos.addArrangedSubview(labelPromos)
        stackPromos.addArrangedSubview(labelPromosMoney)
        
        let stackTotal = UIStackView(arrangedSubviews: [labelTotalAmount, labelTotalMoney])
        stackTotal.spacing = 10
        stackTotal.axis = .horizontal
        stackTotal.alignment = .fill
        stackTotal.distribution = .fill
        
        let stackContent = UIStackView(arrangedSubviews: [stackProvisional, stackDeliveryVat, stackPromos, stackTotal])
        stackContent.spacing = 5
        stackContent.axis = .vertical
        stackContent.alignment = .fill
        stackContent.distribution = .fill
        
        self.addSubview(stackContent)
        
        labelDeliveryVat.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
        }
        
        stackContent.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview().inset(10.widthRatio)
        }
        
        buttonTermDelivery.setConstraintWidthAndHeight(widthConstant: 210.widthRatio, heightConstant: 20.heightRatio)
    }
    
    func setupData(with data: OrderData?) {
        labelMoney.text = data?.totalPrice()
        labelTotalAmount.text = "Tổng cộng (\(data?.totalQuantity() ?? 0) món)"
        labelTotalMoney.text = data?.totalPrice()
        
        guard let Voucher = data?.Voucher else {
            stackPromos.isHidden = true
            return
        }
        let totalMoneyWhenUsingPromos = (data?.totalPriceDouble() ?? 0) - (data?.Discount ?? 0)
        stackPromos.isHidden = false
        labelTotalMoney.text = totalMoneyWhenUsingPromos.formatMoney
        labelPromosMoney.text = "-" + (data?.Discount ?? 0).formatMoney
    }
    
    // MARK: - Action
    @objc private func didTapDeliveryVatButton() {
        didTapDeliveryTermInfo?()
    }
}

