//
//  HeaderOrderTypeView.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 31/07/2022.
//

import UIKit

enum OrderType {
    case processing([OrderData])
    case paid([OrderData])
    case beingTranspoter([OrderData])
    case successed([OrderData])
    case canceled([OrderData])
    
    var orderDatas: [OrderData]? {
        switch self {
        case .processing(let datas):
            return datas.filter({ return $0.Status == 1})
        case .paid(let datas):
            return datas.filter({ return $0.Status == 6})
        case .beingTranspoter(let datas):
            return datas.filter({ return $0.Status == 2})
        case .successed(let datas):
            return datas.filter({ return $0.Status == 3})
        case .canceled(let datas):
            return datas.filter({ return $0.Status == 4})
        }
    }
    
    var title: String {
        switch self {
        case .processing:
            return "Đang xử lý"
        case .paid:
            return "Đã thanh toán"
        case .beingTranspoter:
            return "Đang vận chuyển"
        case .successed:
            return "Thành công"
        case .canceled:
            return "Đã hủy"
        }
    }
    
    var isHiddenRebuy: Bool {
        switch self {
        case .processing:
            return true
        case .paid, .beingTranspoter, .successed, .canceled:
            return false
        }
    }
}

struct OrderHeaderData {
    var Name: String?
    var isSelected: Bool?
    var orderType: OrderType?
}

class HeaderOrderTypeView: UIView {
    
    // MARK: - UI
    
    lazy var backgoundImageView: UIImageView = {
        let imageView = UIImageView(image: UIImage().getImage(with: "bg_blue_color", and: Bundle(for: HeaderOrderTypeView.self))!)
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    lazy var collectionView: UICollectionView = {
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.sectionInset = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
        layout.minimumInteritemSpacing = 15
        layout.invalidateLayout()
        
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.backgroundColor = .clear
        collectionView.alwaysBounceVertical = false
        collectionView.showsVerticalScrollIndicator = false
        collectionView.showsHorizontalScrollIndicator = false
        return collectionView
    }()
    
    // MARK: - Properties
    private var data: [OrderHeaderData] = Constants.Order.orderHeaderType
    private var orderProvider: DataProvider<OrderHeaderData> = DataProvider(data: [])
    private var orderDataSource: CollectionViewDataSource<CategoryCell, OrderHeaderData>!
    
    var didChange: ((OrderHeaderData?)->())?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupUI()
        configCollectionView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Setup
    private func setupUI() {
        self.addSubviews(backgoundImageView, collectionView)
        
        backgoundImageView.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview()
        }
        
        collectionView.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview()
        }
    }
    
    private func configCollectionView() {
        orderProvider.data = data
        
        collectionView.delegate = self
        collectionView.alwaysBounceVertical = true
        collectionView.register(cellClass: CategoryCell.self)
        
        orderDataSource = CollectionViewDataSource(dataProvider: orderProvider)
        
        orderDataSource.configureCell = { [weak self] cell, model, index in
            guard let _ = self else { return }
            cell.bindDataOrderHeader(with: model)
        }
        
        collectionView.dataSource = orderDataSource
        collectionView.reloadData()
    }
    
    private func changeSelectData(with index: Int) {
        for indexCategories in 0..<(self.orderProvider.data.count) {
            if indexCategories == index {
                self.orderProvider.data[index].isSelected = true
            } else {
                self.orderProvider.data[indexCategories].isSelected = false
            }
        }
    }
    
    func reloadData() {
        DispatchQueue.main.async {
            self.orderProvider.data = self.data
            self.collectionView.reloadData()
        }
    }
}

extension HeaderOrderTypeView: UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, UIScrollViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        self.changeSelectData(with: indexPath.item)
        self.didChange?(orderProvider.data[indexPath.item])
        self.collectionView.reloadData()
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let text = orderProvider.data[indexPath.item].Name ?? ""
        let width = self.estimatedFrame(text: text, font: UIFont.systemFont(ofSize: 14)).width
        return CGSize(width: width, height: 50.heightRatio)
    }
    
    func estimatedFrame(text: String, font: UIFont) -> CGRect {
        let size = CGSize(width: 200, height: 1000) // temporary size
        let options = NSStringDrawingOptions.usesFontLeading.union(.usesLineFragmentOrigin)
        return NSString(string: text).boundingRect(with: size,
                                                   options: options,
                                                   attributes: [NSAttributedString.Key.font: font],
                                                   context: nil)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        collectionView.contentOffset.y = 0.0
    }

}
