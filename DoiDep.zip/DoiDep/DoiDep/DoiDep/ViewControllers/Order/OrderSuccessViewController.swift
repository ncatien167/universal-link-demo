//
//  OrderSuccessViewController.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 25/07/2022.
//

import UIKit

class OrderSuccessViewController: BackNavigationVC {

    // MARK: - UI
    lazy var imageContent: UIImageView = {
        let imageView = UIImageView(image: UIImage().getImage(with: "ic_payment_result", and: Bundle(for: OrderSuccessViewController.self))!)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    lazy var labelTitle: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        return label
    }()
    
    lazy var labelAddress: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.numberOfLines = 0
        label.font = UIFont.systemFont(ofSize: 15, weight: .light)
        return label
    }()
    
    lazy var labelTransactionCode: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.numberOfLines = 0
        label.font = UIFont.systemFont(ofSize: 15, weight: .light)
        return label
    }()
    
    lazy var buttonContinue: UIButton = {
        let button = UIButton()
        button.setTitle("Tiếp tục mua hàng", for: .normal)
        button.setTitleColor(Colors.authenticateColor, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14, weight: .light)
        button.titleEdgeInsets = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
        button.backgroundColor = .white
        button.layer.cornerRadius = 5
        button.addTarget(self, action: #selector(didTapContinue), for: .touchUpInside)
        return button
    }()
     
    lazy var buttonMyOrder: UIButton = {
        let button = UIButton()
        button.setTitle("Xem đơn hàng", for: .normal)
        button.setTitleColor(Colors.authenticateColor, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14, weight: .light)
        button.titleEdgeInsets = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
        button.backgroundColor = .white
        button.layer.cornerRadius = 5
        button.addTarget(self, action: #selector(didTapMyOrder), for: .touchUpInside)
        return button
    }()
    
    // MARK: - Properties
    private var selectedType = 1
    private var orderResponse: OrderResponse?
    private var paymentType: PaymentType = .pickup
    
    // MARK: - Life Cycle
    
    convenience init(selectedType: Int, orderResponse: OrderResponse, paymentType: PaymentType?) {
        self.init()
        self.selectedType = selectedType
        self.orderResponse = orderResponse
        self.paymentType = paymentType ?? .pickup
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
        setupDataUIPickUpInStore()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        DispatchQueue.main.async {
            if self.paymentType == .gateWayNamA {
                self.navigationController?.pushViewController(WebViewController(requestUrl: self.orderResponse?.Url ?? ""), animated: true)
            }
        }
    }
    
    private func setupUI() {
        let stackButtons = UIStackView(arrangedSubviews: [buttonContinue, buttonMyOrder])
        stackButtons.axis = .horizontal
        stackButtons.alignment = .fill
        stackButtons.distribution = .fillEqually
        stackButtons.spacing = 20
        
        let contentStackView = UIStackView(arrangedSubviews: [imageContent, labelTitle, labelAddress, labelTransactionCode, stackButtons])
        contentStackView.axis = .vertical
        contentStackView.alignment = .center
        contentStackView.distribution = .fill
        contentStackView.spacing = 20
        
        self.view.addSubview(contentStackView)
        contentStackView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview()
            make.leading.trailing.equalToSuperview().inset(15.widthRatio)
        }
        
        stackButtons.setConstraintWidth(constant: 345.widthRatio)
        imageContent.setConstraintWidthAndHeight(widthConstant: 150.heightRatio, heightConstant: 150.heightRatio)
        buttonMyOrder.setConstraintHeight(constant: 25.heightRatio)
        buttonContinue.setConstraintHeight(constant: 25.heightRatio)
    }

    func setupDataUIPickUpInStore() {
        labelTitle.text = "Đặt hàng thành công"
        labelAddress.text = "Địa chỉ nhận hàng\n"
        labelTransactionCode.text = "Mã đơn hàng: "
    }
    
    @objc private func didTapContinue() {
        CartManager.shared.removeCart()
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    @objc private func didTapMyOrder() {
        CartManager.shared.removeCart()
        self.navigationController?.pushViewController(MyOrderViewController(), animated: true)
    }
}
