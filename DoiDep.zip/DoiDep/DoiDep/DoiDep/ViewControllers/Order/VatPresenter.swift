//
//  VatPresenter.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 22/07/2022.
//

import Foundation

protocol VatView {
    func onCheckEitVatFailed(with mess: String)
    func onCheckEitVatSuccess(with mess: String)
}

protocol VatViewPresenter {
    init(_ view: VatView)
    
    func requestEditVat(with companyName: String, taxNumber: String, email: String, address: String)
}

class VatPresenter: VatViewPresenter {
    var view: VatView?
    
    required init(_ view: VatView) {
        self.view = view
    }
    
    func requestEditVat(with companyName: String, taxNumber: String, email: String, address: String) {
        VatInfor.requestEditVat(with: companyName, taxNumber: taxNumber, email: email, address: address) { status, message in
            guard let status = status, let mess = message else {
                self.view?.onCheckEitVatFailed(with: "Đã có lỗi xảy ra, Quý khách vui lòng thử lại")
                return
            }
            
            if status {
                self.view?.onCheckEitVatSuccess(with: mess)
                return
            }
            
            self.view?.onCheckEitVatFailed(with: "Đã có lỗi xảy ra, Quý khách vui lòng thử lại")
        }
    }
}
