//
//  OrderViewController.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 21/07/2022.
//

import UIKit

class OrderViewController: BackNavigationVC {
    
    // MARK: - UI
    lazy var contentView: UIView = {
        let view = UIView()
        view.backgroundColor = Colors.colorSilverGround
        return view
    }()
    
    lazy var scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        return scrollView
    }()
    
    lazy var contentStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.alignment = .center
        stackView.distribution = .fill
        return stackView
    }()
    
    lazy var labelTypeOrder: PaddingLabel = {
        let label = PaddingLabel()
        label.text = "Hình thức mua hàng"
        label.textColor = Colors.authenticateColor
        label.backgroundColor = Colors.colorSilverGround
        label.font = UIFont.systemFont(ofSize: 15, weight: .bold)
        label.edgeInset = UIEdgeInsets(top: 0, left: 15.widthRatio, bottom: 0, right: 0)
        return label
    }()
    
    lazy var typeOrderView: TypeOrderView = {
        let view = TypeOrderView()
        view.backgroundColor = .white
        view.didTapDelivery = { [weak self] in
            guard let self = self else { return }
            self.selectedType = 1
            self.addressCustomView.setupUIDeliveryType()
        }
        view.didTapPickUpAtStore = { [weak self] in
            guard let self = self else { return }
            self.selectedType = 2
            self.addressCustomView.setupUIPickUp(with: self.storeData)
        }
        return view
    }()
    
    lazy var labelInfoCustomer: PaddingLabel = {
        let label = PaddingLabel()
        label.text = "Thông tin người nhận"
        label.textColor = Colors.authenticateColor
        label.backgroundColor = Colors.colorSilverGround
        label.font = UIFont.systemFont(ofSize: 15, weight: .bold)
        label.edgeInset = UIEdgeInsets(top: 0, left: 15.widthRatio, bottom: 0, right: 0)
        return label
    }()
    
    lazy var addressCustomView: CustomAddressOrderView = {
        let view = CustomAddressOrderView()
        view.didTapChange = { [weak self] in
            guard let self = self else { return }
            self.didTapChangeAddressButton()
        }
        return view
    }()

    lazy var labelInfoOrder: PaddingLabel = {
        let label = PaddingLabel()
        label.text = "Thông tin đơn hàng"
        label.textColor = Colors.authenticateColor
        label.backgroundColor = Colors.colorSilverGround
        label.font = UIFont.systemFont(ofSize: 15, weight: .bold)
        label.edgeInset = UIEdgeInsets(top: 0, left: 15.widthRatio, bottom: 0, right: 0)
        return label
    }()

    lazy var orderInfoView: OrderInfoView = {
        let view = OrderInfoView()
        view.backgroundColor = .white
        return view
    }()
    
    lazy var bottomView: UIView = {
        let view = UIView()
        view.backgroundColor = Colors.white
        return view
    }()
    
    lazy var paymentButton: PaymentButton = {
        let button = PaymentButton()
        button.setup(with: "Thanh toán qua Open Banking", and: UIImage().getImage(with: "ic_open_banking", and: Bundle(for: OrderViewController.self))!)
        button.didTap = { [weak self] in
            guard let self = self else { return }
//            self.didTapPaymentButton()
        }
        return button
    }()
    
    lazy var voucherButton: PaymentButton = {
        let button = PaymentButton()
        button.setup(with: "Thêm ưu đãi", and: UIImage().getImage(with: "ic_promos", and: Bundle(for: OrderViewController.self))!)
        button.didTap = { [weak self] in
            guard let self = self else { return }
            self.didTapVoucherButton()
        }
        return button
    }()
    
    lazy var orderButton: CommonButton = {
        let button = CommonButton()
        button.didTap = { [weak self] in
            guard let self = self else { return }
            self.didTapOrderButton()
        }
        return button
    }()
    
    // MARK: - Properties
    private var presenter: OrderPresenter?
    private var selectedType = 1
    private var voucher: Voucher?
    private var datas: [PaymentTypeData] = Constants.Order.datasType
    private var paymentType: PaymentType? = .billNamA
    private var storeData: StoreData? = CommonService.shared.getStores().first
    
    // MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter = OrderPresenter(self)
        setupUI()
        handleOrderItemAction()
    }
    
    deinit {
        presenter = nil
    }
    
    // MARK: - Set up
    private func setupUI() {
        headerView.title = "Xác nhận đơn hàng"
        self.view.addSubviews(contentView, bottomView)
        self.contentView.addSubview(scrollView)
        self.scrollView.addSubview(contentStackView)
        
        contentView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(headerView.frame.height)
            make.leading.trailing.equalToSuperview()
        }
        
        bottomView.snp.makeConstraints { make in
            make.top.equalTo(contentView.snp.bottom)
            make.bottom.trailing.leading.equalToSuperview()
            make.height.equalTo(130.heightRatio)
        }
        
        setupBottomView()
        
        scrollView.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview()
        }
        
        contentStackView.snp.makeConstraints { make in
            make.top.bottom.equalToSuperview()
            make.leading.trailing.equalToSuperview()
            make.width.equalTo(375.widthRatio)
        }
        
        contentStackView.addArrangedSubview(labelTypeOrder)
        contentStackView.addArrangedSubview(typeOrderView)
        contentStackView.addArrangedSubview(labelInfoCustomer)
        setupInfoCustomerView()
        contentStackView.addArrangedSubview(labelInfoOrder)
        contentStackView.addArrangedSubview(orderInfoView)
        
        orderInfoView.setConstraintWidth(constant: 375.widthRatio)
        typeOrderView.setConstraintWidth(constant: 375.widthRatio)
        labelTypeOrder.setConstraintWidthAndHeight(widthConstant: 375.widthRatio, heightConstant: 35.heightRatio)
        labelInfoOrder.setConstraintWidthAndHeight(widthConstant: 375.widthRatio, heightConstant: 35.heightRatio)
        labelInfoCustomer.setConstraintWidthAndHeight(widthConstant: 375.widthRatio, heightConstant: 35.heightRatio)
    }
    
    private func setupInfoCustomerView() {
        contentStackView.addArrangedSubview(addressCustomView)
        addressCustomView.setConstraintWidth(constant: 375.widthRatio)
    }
    
    private func setupBottomView() {
        let lineView = UIView()
        lineView.backgroundColor = Colors.mainColor
        
        let stackButton = UIStackView(arrangedSubviews: [paymentButton, lineView, voucherButton])
        stackButton.axis = .horizontal
        stackButton.alignment = .fill
        stackButton.distribution = .fill
        stackButton.spacing = 5
        
        self.bottomView.addSubviews(orderButton, stackButton)
        
        lineView.setConstraintWidth(constant: 1)
        stackButton.snp.makeConstraints { make in
            make.top.equalToSuperview().inset(10.heightRatio)
            make.leading.trailing.equalToSuperview().inset(15.widthRatio)
        }
        
        paymentButton.snp.makeConstraints { make in
            make.width.equalTo(voucherButton.snp.width)
        }
        
        orderButton.snp.makeConstraints { make in
            make.height.equalTo(45.heightRatio)
            make.top.equalTo(stackButton.snp.bottom).offset(10.heightRatio)
            make.bottom.leading.trailing.equalToSuperview().inset(20.heightRatio)
        }
        
        orderButton.setup(title: "Đặt món: \(CartManager.shared.totalMoneyAllProductTypeString())")
    }
    
    // MARK: - Action
    
    @objc private func handleOrderItemAction() {
        orderInfoView.didTapDeliveryTermInfo = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.navigationController?.pushViewController(TermDeliveryViewController(), animated: true)
            }
        }
        orderInfoView.didTapVatInfo = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.navigationController?.pushViewController(VatViewController(), animated: true)
            }
        }
        orderInfoView.didExportVat = { [weak self] in
            guard let _ = self, let isVat = UserService.shared.getDataUser().IsVAT else { return }
            if !isVat {
                CommonPopup.showAlertOnlyOk("Vui lòng nhập đầy đủ thông tin VAT")
            }
        }
    }
    
    @objc private func didTapChangeAddressButton() {
        if selectedType == 2 {
            PopupStore.showPopup { [weak self] storeData in
                guard let self = self else { return }
                self.storeData = storeData
                self.addressCustomView.setupUIPickUp(with: storeData)
            }
            return
        }
        
        PopUpAddress.showAlert { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.navigationController?.pushViewController(CreateAddressViewController(), animated: true)
            }
        } okCompletion: { [weak self] addressID in
            guard let self = self, let addressID = addressID else { return }
            self.presenter?.requestSetDefaultAddress(with: addressID)
        } cancelCompletion: { }
    }
    
    private func didTapOrderButton() {
        if selectedType == 1 {
            guard let _ = CommonService.shared.defaultAddress() else {
                CommonPopup.showAlertOnlyOk("Quý khách chưa có địa chỉ nhận hàng")
                return
            }
        }
        self.showLoading()
        presenter?.requestOrder(with: self.voucher, paymentType: self.paymentType, selectedType: self.selectedType, storeData: self.storeData)
    }
    
    private func didTapVoucherButton() {
        let vc = VoucherViewController()
        vc.useNow = { [weak self] voucher in
            guard let self = self else { return }
            DispatchQueue.main.async {
                guard let voucher = voucher else {
                    self.voucher = nil
                    self.orderInfoView.setupDataWhenUsingPromos(with: nil)
                    self.orderButton.setup(title: "Đặt món: \(CartManager.shared.totalMoneyAllProductTypeString())")
                    self.voucherButton.setup(with: "Thêm ưu đãi", and: UIImage().getImage(with: "ic_promos", and: Bundle(for: OrderViewController.self))!)
                    return
                }
                
                if CartManager.shared.totalMoneyAllProduct() < (voucher.ProductAmoutMin ?? 0) {
                    CommonPopup.showAlertOnlyOk("Không đủ điều kiện sử dụng")
                    self.voucher = nil
                    self.orderInfoView.setupDataWhenUsingPromos(with: nil)
                    self.orderButton.setup(title: "Đặt món: \(CartManager.shared.totalMoneyAllProductTypeString())")
                    self.voucherButton.setup(with: "Thêm ưu đãi", and: UIImage().getImage(with: "ic_promos", and: Bundle(for: OrderViewController.self))!)
                    return
                }
                
                self.voucher = voucher
                CartManager.shared.setVoucher(with: voucher)
                self.orderInfoView.setupDataWhenUsingPromos(with: voucher)
                self.voucherButton.setup(with: voucher.Name ?? "", and: voucher.Type == 1 ? UIImage().getImage(with: "ic_gift", and: Bundle(for: OrderViewController.self))! : UIImage().getImage(with: "ic_shipping1", and: Bundle(for: OrderViewController.self))!)
                
                switch (VoucherUseType.init(rawValue: voucher.UseType ?? 0) ?? .amount) {
                    case .amount:
                        let totalMoneyWhenUsingPromos = CartManager.shared.totalMoneyAllProduct() - (voucher.Amount ?? 0)
                        self.orderButton.setup(title: "Đặt món: \(totalMoneyWhenUsingPromos.formatMoney)")
                        break
                    case .precent:
                        let percent: Double = Double(voucher.Percent ?? 0)
                        let amountPromos = (CartManager.shared.totalMoneyAllProduct() / percent)

                        let totalMoneyWhenUsingPromos = CartManager.shared.totalMoneyAllProduct() - amountPromos
                        self.orderButton.setup(title: "Đặt món: \(totalMoneyWhenUsingPromos.formatMoney)")
                        break
                }
            }
        }
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    private func didTapPaymentButton() {
        PaymentCustomView.showPopupPaymentGateway(datas: self.datas) { [weak self] type, datas in
            guard let self = self, let type = type, let datas = datas else { return }
            DispatchQueue.main.async {
                self.datas = datas
                self.paymentType = type
                self.paymentButton.setup(with: type.paymentType.title ?? "", and: type.paymentType.icon)
            }
        }
    }
}

extension OrderViewController: OrderView {
    func onCheckCreateOrderFail(with message: String?) {
        DispatchQueue.main.async {
            self.hideLoading()
            CommonPopup.showAlertOnlyOk(message ?? "Tạo đơn hàng thất bại")
        }
    }
    
    func onCheckCreateOrderSuccess(with data: OrderResponse) {
        DispatchQueue.main.async {
            self.hideLoading()
            
            if let message = data.Message {
                CommonPopup.showAlertOnlyOk(message)
                return
            }
            
            switch self.paymentType {
                case .pickup:
                    self.navigationController?.pushViewController(OrderSuccessViewController(selectedType: self.selectedType, orderResponse: data, paymentType: self.paymentType), animated: true)
                    break
                case .billNamA:
                    CartManager.shared.removeCart()
                    if let vc = DoiDep.reviewViewController {
                        var dataOrder = data
                        dataOrder.UserName = UserService.shared.getDataUser().FullName
                        dataOrder.Phone = UserService.shared.getDataUser().Phone
                        dataOrder.Voucher = self.voucher
                        DoiDep.shared.delegate?.onGotoPayment(with: dataOrder.convertObjectToDictionary)
                        self.navigationController?.pushViewController(vc, animated: true)
                        self.removeFromParent()
                    }
                    break
                case .gateWayNamA:
                    self.navigationController?.pushViewController(OrderSuccessViewController(selectedType: self.selectedType, orderResponse: data, paymentType: self.paymentType), animated: true)
                    break
                default:
                    break
            }
        }
    }
    
    func onCheckSetIsDefaultSuccess() {
        DispatchQueue.main.async {
            self.addressCustomView.setupUIDeliveryType()
        }
    }
}

