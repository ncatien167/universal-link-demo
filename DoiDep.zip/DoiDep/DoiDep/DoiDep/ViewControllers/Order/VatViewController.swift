//
//  VatViewController.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 22/07/2022.
//

import UIKit

class VatViewController: BackNavigationVC {

    // MARK: - UI
    lazy var contentView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        return view
    }()
    
    lazy var labelDes: UILabel = {
        let label = UILabel()
        label.text = "Quý khách vui lòng nhập thông tin đầy đủ để Đôi Dép\nxuất hoá đơn cho Quý khách"
        label.font = UIFont.systemFont(ofSize: 14, weight: .light)
        label.textColor = Colors.authenticateColor
        label.textAlignment = .center
        label.numberOfLines = 0
        return label
    }()
    
    lazy var companyField: TitleTextField = {
        let view = TitleTextField()
        view.setup(title: "Tên công ty", placeHolder: "Tên công ty")
        return view
    }()
    
    lazy var taxField: TitleTextField = {
        let view = TitleTextField()
        view.setup(title: "Mã số thuế", placeHolder: "Mã số thuế")
        return view
    }()
    
    lazy var emailField: TitleTextField = {
        let view = TitleTextField()
        view.setup(title: "Email", placeHolder: "Email")
        return view
    }()
    
    lazy var addressField: TitleTextField = {
        let view = TitleTextField()
        view.setup(title: "Địa chỉ", placeHolder: "Địa chỉ")
        return view
    }()
    
    lazy var doneButton: CommonButton = {
        let button = CommonButton()
        button.setup(title: "Cập nhật", 5)
        button.didTap = { [weak self] in
            guard let self = self else { return }
            self.didTapDoneButton()
        }
        return button
    }()
    
    // MARK: - Presenter
    private var presenter: VatPresenter?
    
    // MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter = VatPresenter(self)
        setupUI()
        setupData()
    }
    
    deinit {
        presenter = nil
    }

    // MARK: - Set up
    private func setupUI() {
        self.headerView.title = "Thông tin xuất hoá đơn"
        self.view.addSubview(contentView)
        self.contentView.addSubview(labelDes)
        
        contentView.snp.makeConstraints { make in
            make.top.equalTo(headerView.snp.bottom)
            make.bottom.leading.trailing.equalToSuperview()
        }
        
        labelDes.snp.makeConstraints { make in
            make.top.equalToSuperview().inset(20.heightRatio)
            make.leading.trailing.equalToSuperview().inset(15.widthRatio)
        }
        
        let stackView = UIStackView(arrangedSubviews: [companyField, taxField, emailField, addressField, doneButton])
        stackView.axis = .vertical
        stackView.alignment = .center
        stackView.distribution = .fill
        stackView.spacing = 10.heightRatio
        contentView.addSubview(stackView)
        
        stackView.snp.makeConstraints { make in
            make.top.equalTo(labelDes.snp.bottom).offset(15.heightRatio)
            make.leading.trailing.equalToSuperview()
        }
        
        taxField.setConstraintWidthAndHeight(widthConstant: 350.widthRatio, heightConstant: 50.heightRatio)
        doneButton.setConstraintWidthAndHeight(widthConstant: 350.widthRatio, heightConstant: 35.heightRatio)
        emailField.setConstraintWidthAndHeight(widthConstant: 350.widthRatio, heightConstant: 50.heightRatio)
        companyField.setConstraintWidthAndHeight(widthConstant: 350.widthRatio, heightConstant: 50.heightRatio)
        addressField.setConstraintWidthAndHeight(widthConstant: 350.widthRatio, heightConstant: 50.heightRatio)
    }

    private func setupData() {
        let userData = UserService.shared.getDataUser()
        
        // Nếu không có Vat sẽ không cần cập nhật data
        guard let isVat = userData.IsVAT, isVat else {
            return
        }
        
        companyField.textField.text = userData.VatInfor?.CompanyName
        taxField.textField.text = userData.VatInfor?.TaxCode
        emailField.textField.text = userData.VatInfor?.Email
        addressField.textField.text = userData.VatInfor?.Address
    }
    // MARK: - Action
    private func didTapDoneButton() {
        guard let companyName = companyField.textField.text, let tax = taxField.textField.text, let email = emailField.textField.text, let address = addressField.textField.text else {
            CommonPopup.showAlertOnlyOk("Vui lòng nhập đầy đủ thông tin")
            return
        }
        
        if companyName == "" {
            CommonPopup.showAlertOnlyOk("Vui lòng nhập tên công ty")
            return
        }
        
        if tax == "" {
            CommonPopup.showAlertOnlyOk("Vui lòng nhập mã số thuế")
            return
        }
        
        if email == "" {
            CommonPopup.showAlertOnlyOk("Vui lòng nhập Email")
            return
        }
        
        if !email.checkValidationEmail() {
            CommonPopup.showAlertOnlyOk("Vui lòng nhập đúng định dạng Email")
            return
        }
        
        if address == "" {
            CommonPopup.showAlertOnlyOk("Vui lòng nhập địa chỉ")
            return
        }
        
        presenter?.requestEditVat(with: companyName, taxNumber: tax, email: email, address: address)
    }
}

extension VatViewController: VatView {
    func onCheckEitVatFailed(with mess: String) {
        CommonPopup.showAlertOnlyOk(mess)
    }
    
    func onCheckEitVatSuccess(with mess: String) {
        CommonPopup.showAlertOnlyOk(mess)
    }
}

class TitleTextField: UIView {
    lazy var labelTitle: UILabel = {
        let label = UILabel()
        label.textColor = Colors.normalTextColor
        label.font = UIFont.systemFont(ofSize: 15, weight: .light)
        return label
    }()
    
    lazy var textField: UITextField = {
        let textField = UITextField()
        textField.textColor = Colors.authenticateColor
        return textField
    }()
    
    lazy var bottomLineView: UIView = {
         let view = UIView()
         view.backgroundColor = Colors.mainColor
         view.translatesAutoresizingMaskIntoConstraints = false
         return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupUI()
    }
    
    private func setupUI() {
        let stackView = UIStackView(arrangedSubviews: [labelTitle, textField])
        stackView.axis = .vertical
        stackView.alignment = .fill
        stackView.distribution = .fill
        stackView.spacing = 10
        
        self.addSubviews(stackView, bottomLineView)
        stackView.snp.makeConstraints { make in
            make.top.leading.trailing.equalToSuperview()
        }
        
        bottomLineView.snp.makeConstraints { make in
            make.height.equalTo(0.5)
            make.top.equalTo(stackView.snp.bottom).offset(3)
            make.bottom.leading.trailing.equalToSuperview()
        }
    }

    func setup(title: String, placeHolder: String) {
        labelTitle.text = title
        textField.attributedPlaceholder = NSAttributedString(string: placeHolder, attributes:[NSAttributedString.Key.foregroundColor: Colors.mainColor])
    }
}
