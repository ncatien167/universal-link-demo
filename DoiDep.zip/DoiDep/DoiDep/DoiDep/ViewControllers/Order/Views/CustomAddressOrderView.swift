//
//  CustomAddressOrderView.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 25/07/2022.
//

import UIKit

class CustomAddressOrderView: UIView {

    lazy var stackInfo: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.alignment = .fill
        stackView.distribution = .fillEqually
        stackView.spacing = 10
        stackView.isHidden = true
        return stackView
    }()
    
    lazy var labelTitleAddress: UILabel = {
        let label = UILabel()
        label.text = "Địa chỉ nhận hàng"
        label.textColor = Colors.normalTextColor
        label.font = UIFont.systemFont(ofSize: 15, weight: .light)
        return label
    }()
    
    lazy var labelAddress: PaddingLabel = {
        let label = PaddingLabel()
        label.numberOfLines = 0
        label.textColor = Colors.normalTextColor
        label.font = UIFont.systemFont(ofSize: 15, weight: .light)
        label.edgeInset = UIEdgeInsets(top: 0, left: 15.widthRatio, bottom: 0, right: 0)
        return label
    }()
    
    lazy var labelInfoOrder: PaddingLabel = {
        let label = PaddingLabel()
        label.text = "Thông tin đơn hàng"
        label.textColor = Colors.authenticateColor
        label.backgroundColor = Colors.colorSilverGround
        label.font = UIFont.systemFont(ofSize: 15, weight: .bold)
        label.edgeInset = UIEdgeInsets(top: 0, left: 15.widthRatio, bottom: 0, right: 0)
        return label
    }()
    
    lazy var buttonChangeAddress: UIButton = {
        let button = UIButton()
        button.setTitle("Thay đổi", for: .normal)
        button.setTitleColor(Colors.authenticateColor, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 15, weight: .light)
        button.addTarget(self, action: #selector(didTapChangeAddressButton), for: .touchUpInside)
        return button
    }()
    
    var didTapChange: (()->())?
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        let labelTitleName = UILabel()
        labelTitleName.text = "Tên"
        labelTitleName.textColor = Colors.normalTextColor
        labelTitleName.font = UIFont.systemFont(ofSize: 15, weight: .light)
        
        let labelName = PaddingLabel()
        labelName.text = UserService.shared.getDataUser().FullName
        labelName.textColor = Colors.normalTextColor
        labelName.font = UIFont.systemFont(ofSize: 15, weight: .light)
        labelName.edgeInset = UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 10.widthRatio)
        labelName.layer.cornerRadius = 5
        labelName.layer.borderWidth = 0.5
        labelName.layer.borderColor = Colors.mainColor.cgColor
        
        let labelTitlePhone = UILabel()
        labelTitlePhone.text = "Số điện thoại"
        labelTitlePhone.textColor = Colors.normalTextColor
        labelTitlePhone.font = UIFont.systemFont(ofSize: 15, weight: .light)
        
        let labelPhone = PaddingLabel()
        labelPhone.text = UserService.shared.getDataUser().Phone
        labelPhone.textColor = Colors.normalTextColor
        labelPhone.font = UIFont.systemFont(ofSize: 15, weight: .light)
        labelPhone.edgeInset = UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 10.widthRatio)
        labelPhone.layer.cornerRadius = 5
        labelPhone.layer.borderWidth = 0.5
        labelPhone.layer.borderColor = Colors.mainColor.cgColor
        
        let stackName = UIStackView(arrangedSubviews: [labelTitleName, labelName])
        stackName.axis = .vertical
        stackName.alignment = .fill
        stackName.distribution = .fill
        stackName.spacing = 5
        
        let stackPhone = UIStackView(arrangedSubviews: [labelTitlePhone, labelPhone])
        stackPhone.axis = .vertical
        stackPhone.alignment = .fill
        stackPhone.distribution = .fill
        stackPhone.spacing = 5
        
        stackInfo.addArrangedSubview(stackName)
        stackInfo.addArrangedSubview(stackPhone)
        
        let stackAddress = UIStackView(arrangedSubviews: [labelAddress, buttonChangeAddress])
        stackAddress.axis = .horizontal
        stackAddress.alignment = .fill
        stackAddress.distribution = .fill
        stackAddress.layer.cornerRadius = 10
        stackAddress.layer.borderWidth = 0.5
        stackAddress.layer.borderColor = Colors.mainColor.cgColor
        stackAddress.layoutMargins = UIEdgeInsets(top: 10.heightRatio, left: 10.heightRatio, bottom: 10.heightRatio, right: 5.widthRatio)
        stackAddress.isLayoutMarginsRelativeArrangement = true
        
        let stackViewInfoCustomer = UIStackView(arrangedSubviews: [stackInfo, labelTitleAddress, stackAddress])
        stackViewInfoCustomer.backgroundColor = .white
        stackViewInfoCustomer.spacing = 5
        stackViewInfoCustomer.axis = .vertical
        stackViewInfoCustomer.alignment = .fill
        stackViewInfoCustomer.distribution = .fill
        stackViewInfoCustomer.layoutMargins = UIEdgeInsets(top: 10.heightRatio, left: 15.widthRatio, bottom: 10.heightRatio, right: 15.widthRatio)
        stackViewInfoCustomer.isLayoutMarginsRelativeArrangement = true
        
        self.addSubview(stackViewInfoCustomer)
        
        labelName.setConstraintHeight(constant: 25.heightRatio)
        labelPhone.setConstraintHeight(constant: 25.heightRatio)
        
        stackViewInfoCustomer.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview()
        }
        buttonChangeAddress.setConstraintWidth(constant: 70.widthRatio)
        
        if CommonService.shared.getAddresses().count == 0 {
            labelAddress.text = "Nhập để thêm địa chỉ mới"
        } else {
            for address in CommonService.shared.getAddresses() {
                if let isDefault = address.IsDefault {
                    if isDefault {
                        labelAddress.text = "\(address.Address ?? ""), \(address.WardName ?? ""), \(address.DistrictName ?? ""), \((address.ProvinceName ?? ""))"
                        return
                    }
                }
            }
        }
    }
    
    func setupUIDeliveryType() {
        stackInfo.isHidden = true
        labelAddress.font = UIFont.systemFont(ofSize: 15, weight: .light)
        labelAddress.textColor = Colors.normalTextColor
        if CommonService.shared.getAddresses().count == 0 {
            labelAddress.text = "Nhập để thêm địa chỉ mới"
        } else {
            for address in CommonService.shared.getAddresses() {
                if let isDefault = address.IsDefault {
                    if isDefault {
                        labelAddress.text = "\(address.Address ?? ""), \(address.WardName ?? ""), \(address.DistrictName ?? ""), \((address.ProvinceName ?? ""))"
                        return
                    }
                }
            }
        }
    }
    
    func setupUIPickUp(with storeData: StoreData?) {
        stackInfo.isHidden = false
        labelAddress.text = storeData?.StoreName
        labelTitleAddress.text = "Chọn một cửa hàng để đặt hàng xác nhận"
        labelAddress.font = UIFont.systemFont(ofSize: 15, weight: .bold)
        labelAddress.textColor = Colors.authenticateColor
    }
    
    @objc private func didTapChangeAddressButton() {
        didTapChange?()
    }
}
