//
//  PaymentCustomView.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 25/07/2022.
//

import UIKit

class PaymentCustomView: UIViewController {
    
    private lazy var labelTitle: PaddingLabel = {
        let label = PaddingLabel()
        label.text = "Phương thức thanh toán"
        label.edgeInset = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
        label.layer.cornerRadius = 5
        label.layer.masksToBounds = true
        label.textAlignment = .center
        label.textColor = Colors.white
        label.backgroundColor = Colors.mainColor
        label.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        return label
    }()
    
    private lazy var cancelButton: UIButton = {
        let btn = UIButton()
        btn.setImage(UIImage().getImage(with: "ic_close", and: Bundle(for: PaymentCustomView.self))!, for: .normal)
        btn.addTarget(self, action: #selector(didCancel(_:)), for: .touchUpInside)
        return btn
    }()
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView()
        return tableView
    }()
    
    lazy var contentAlertView: UIView = {
        let view = UIView()
        view.backgroundColor = Colors.white
        view.layer.cornerRadius = 15
        view.layer.masksToBounds = true
        return view
    }()
    
    private lazy var dimmedBackgroundView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = UIColor.black.withAlphaComponent(0.3)
        return view
    }()
    
    // MARK: - Properties
    var datas: [PaymentTypeData] = []
    
    private var typeProvider: DataProvider<PaymentTypeData> = DataProvider(data: [])
    private var typesDataSource: TableViewDataSource<PaymentGatewayCell, PaymentTypeData>!
    private var type: PaymentType? = .billNamA
    
    typealias completionHandler = (PaymentType?, [PaymentTypeData]?) -> ()
    private var completion: completionHandler?
    
    internal required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private init(datas: [PaymentTypeData], completion: completionHandler? = nil) {
        super.init(nibName: nil, bundle: nil)
        self.completion = completion
        self.datas = datas
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initLayout()
        configTableview()
    }
    
    func initLayout() {
        self.view.addSubview(dimmedBackgroundView)
        self.view.addSubview(contentAlertView)
        self.contentAlertView.addSubviews(cancelButton, labelTitle, tableView)
        
        dimmedBackgroundView.snp.makeConstraints { (make) in
            make.trailing.leading.top.bottom.equalToSuperview()
        }
        
        contentAlertView.snp.makeConstraints { (make) in
            make.height.equalTo(300.heightRatio)
            make.bottom.leading.trailing.equalToSuperview()
        }
        
        cancelButton.snp.makeConstraints { make in
            make.top.leading.equalToSuperview().inset(15.heightRatio)
            make.width.height.equalTo(25.heightRatio)
        }
        
        labelTitle.snp.makeConstraints { make in
            make.height.equalTo(40.heightRatio)
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().inset(10.heightRatio)
        }
        tableView.snp.makeConstraints { make in
            make.top.equalTo(labelTitle.snp.bottom).offset(10.heightRatio)
            make.bottom.leading.trailing.equalToSuperview()
        }
    }
    
    private func configTableview() {
        typeProvider.data = datas
        tableView.delegate = self
        tableView.rowHeight = 35.heightRatio
        tableView.separatorStyle = .none
        tableView.alwaysBounceVertical = true
        tableView.register(cellClass: PaymentGatewayCell.self)
        
        typesDataSource = TableViewDataSource(dataProvider: typeProvider)
        
        typesDataSource.configureCell = { [weak self] cell, model, index in
            guard let _ = self else { return }
            cell.bindData(with: model)
        }
        
        tableView.dataSource = typesDataSource
        tableView.reloadData()
    }
    
    // MARK: show alert

    static func showPopupPaymentGateway(datas: [PaymentTypeData], completion: completionHandler? = nil) {
        let alert = PaymentCustomView(datas: datas, completion: completion)
        DispatchQueue.main.async(execute: {
            guard let viewController = UIViewController.topMostViewController() else { return }
            presentPopover(alert, viewController: viewController)
        })
    }
    
    @objc func didCancel(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    private static func presentPopover(_ alert: UIViewController, viewController: UIViewController) {
        alert.modalPresentationStyle = .overCurrentContext
        alert.modalTransitionStyle = .crossDissolve
        alert.definesPresentationContext = true
        viewController.present(alert, animated: true, completion: nil)
    }
}

extension PaymentCustomView: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let completion = completion else {
            dismiss(animated: true, completion: nil)
            return
        }
        for item in 0..<datas.count {
            if indexPath.row == item {
                datas[item].isSelected = true
            } else {
                datas[item].isSelected = false
            }
        }
        
        completion(datas[indexPath.row].type, datas)
        dismiss(animated: true, completion: nil)
    }
}
