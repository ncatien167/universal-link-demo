//
//  OrderInfoView.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 24/07/2022.
//

import UIKit

class OrderInfoView: UIView {
    
    lazy var tableView: UITableView = {
        let tableView = UITableView()
        return tableView
    }()
    
    lazy var labelMoney: UILabel = {
        let label = UILabel()
        label.textAlignment = .right
        label.textColor = Colors.normalTextColor
        label.font = UIFont.systemFont(ofSize: 15, weight: .regular)
        return label
    }()
    
    lazy var labelTotalAmount: UILabel = {
        let label = UILabel()
        label.textAlignment = .left
        label.textColor = Colors.mainColor
        label.font = UIFont.systemFont(ofSize: 15, weight: .regular)
        return label
    }()
    
    lazy var labelPromosMoney: UILabel = {
        let label = UILabel()
        label.textAlignment = .right
        label.textColor = Colors.customGreenColor
        label.font = UIFont.systemFont(ofSize: 15, weight: .regular)
        return label
    }()
    
    lazy var stackPromos: UIStackView = {
        let stackPromos = UIStackView()
        stackPromos.isHidden = true
        stackPromos.spacing = 10
        stackPromos.axis = .horizontal
        stackPromos.alignment = .fill
        stackPromos.distribution = .fill
        return stackPromos
    }()
    
    lazy var labelTotalMoney: UILabel = {
        let label = UILabel()
        label.textAlignment = .right
        label.textColor = Colors.mainColor
        label.font = UIFont.systemFont(ofSize: 15, weight: .regular)
        return label
    }()
    
    lazy var buttonTermDelivery: UIButton = {
        let button = UIButton()
        button.setTitle("Chính sách vận chuyển", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        button.setImage(UIImage().getImage(with: "ic_info", and: Bundle(for: OrderInfoView.self))!, for: .normal)
        button.setTitleColor(Colors.mainColor, for: .normal)
        button.imageView?.contentMode = .scaleAspectFit
        button.imageView?.changeToColor(Colors.mainColor)
        button.imageEdgeInsets = UIEdgeInsets(top: 0, left: 183.widthRatio, bottom: 0, right: 0)
        button.addTarget(self, action: #selector(didTapDeliveryVatButton), for: .touchUpInside)
        return button
    }()
    
    lazy var buttonExportVat: UIButton = {
        let button = UIButton()
        button.setTitle("Xuất hoá đơn?", for: .normal)
        button.setTitleColor(Colors.black, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        button.setImage(UIImage().getImage(with: "ic_non_select", and: Bundle(for: OrderInfoView.self))!, for: .normal)
        button.imageEdgeInsets = UIEdgeInsets(top: 0, left: -10.widthRatio, bottom: 0, right: 0)
        button.addTarget(self, action: #selector(didTapExportVatButton), for: .touchUpInside)
        button.imageView?.contentMode = .scaleAspectFit
        return button
    }()
    
    lazy var buttonVatInfo: UIButton = {
        let button = UIButton()
        let yourAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: 15),
            .foregroundColor: Colors.mainColor,
            .underlineStyle: NSUnderlineStyle.single.rawValue
        ]
        let attributeString = NSMutableAttributedString(
            string: "Thông tin",
            attributes: yourAttributes
        )
        button.setAttributedTitle(attributeString, for: .normal)
        button.addTarget(self, action: #selector(didTapVatInfoButton), for: .touchUpInside)
        return button
    }()
    
    // MARK: - Properties
    
    private var orderItemProvider: DataProvider<CartData> = DataProvider(data: [])
    private var orderItemDataSource: TableViewDataSource<OrderItemCell, CartData>!
    private var didCheckVat: Bool = false {
        didSet {
            if didCheckVat {
                buttonExportVat.setImage(UIImage().getImage(with: "ic_selected", and: Bundle(for: OrderInfoView.self))!, for: .normal)
            } else {
                buttonExportVat.setImage(UIImage().getImage(with: "ic_non_select", and: Bundle(for: OrderInfoView.self))!, for: .normal)
            }
        }
    }
    var didTapDeliveryTermInfo: (()->())?
    var didExportVat: (()->())?
    var didTapVatInfo: (()->())?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupUI()
        configTableview()
        setupData()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        self.addSubview(tableView)
        let tabbleViewHeight = 67.heightRatio * CGFloat(CartManager.shared.getDataCart().count)
        tableView.snp.makeConstraints { make in
            make.top.leading.trailing.equalToSuperview().inset(15.heightRatio)
            make.height.greaterThanOrEqualTo(tabbleViewHeight)
        }
        
        setupOrtherInfo()
    }
    
    private func setupOrtherInfo() {
        let labelProvisional = UILabel()
        labelProvisional.text = "Tạm tính"
        labelProvisional.textColor = Colors.normalTextColor
        labelProvisional.font = UIFont.systemFont(ofSize: 15, weight: .regular)
        
        let stackProvisional = UIStackView(arrangedSubviews: [labelProvisional, labelMoney])
        stackProvisional.spacing = 10
        stackProvisional.axis = .horizontal
        stackProvisional.alignment = .fill
        stackProvisional.distribution = .fill
        
        let labelDeliveryVat = UILabel()
        labelDeliveryVat.text = "Phí vận chuyển"
        labelDeliveryVat.textColor = Colors.normalTextColor
        labelDeliveryVat.font = UIFont.systemFont(ofSize: 15, weight: .regular)
        
        let stackDeliveryVat = UIStackView(arrangedSubviews: [labelDeliveryVat, buttonTermDelivery])
        stackDeliveryVat.spacing = 10
        stackDeliveryVat.axis = .horizontal
        stackDeliveryVat.alignment = .fill
        stackDeliveryVat.distribution = .fill
        
        let labelPromos = UILabel()
        labelPromos.text = "Khuyến mãi"
        labelPromos.textColor = Colors.customGreenColor
        labelPromos.font = UIFont.systemFont(ofSize: 15, weight: .regular)
        
        stackPromos.addArrangedSubview(labelPromos)
        stackPromos.addArrangedSubview(labelPromosMoney)
        
        let stackTotal = UIStackView(arrangedSubviews: [labelTotalAmount, labelTotalMoney])
        stackTotal.spacing = 10
        stackTotal.axis = .horizontal
        stackTotal.alignment = .fill
        stackTotal.distribution = .fill
        
        let stackButtons = UIStackView(arrangedSubviews: [buttonExportVat, buttonVatInfo, UILabel()])
        stackButtons.spacing = 5
        stackButtons.axis = .horizontal
        stackButtons.alignment = .leading
        stackButtons.distribution = .fill
        
        let stackContent = UIStackView(arrangedSubviews: [stackProvisional, stackDeliveryVat, stackPromos, stackTotal, stackButtons])
        stackContent.spacing = 5
        stackContent.axis = .vertical
        stackContent.alignment = .fill
        stackContent.distribution = .fill
        
        self.addSubview(stackContent)
        
        labelDeliveryVat.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
        }
        
        stackContent.snp.makeConstraints { make in
            make.top.equalTo(tableView.snp.bottom).offset(5.heightRatio)
            make.leading.trailing.equalToSuperview().inset(15.widthRatio)
            make.bottom.equalToSuperview()
        }
        
        buttonTermDelivery.setConstraintWidthAndHeight(widthConstant: 210.widthRatio, heightConstant: 20.heightRatio)
        buttonExportVat.setConstraintWidthAndHeight(widthConstant: 125.widthRatio, heightConstant: 30.heightRatio)
        buttonVatInfo.setConstraintWidth(constant: 100.widthRatio)
    }
    
    private func setupData() {
        labelMoney.text = CartManager.shared.totalMoneyAllProductTypeString()
        labelTotalAmount.text = "Tổng cộng (\(CartManager.shared.totalQuantity()) món)"
        labelTotalMoney.text = CartManager.shared.totalMoneyAllProductTypeString()
    }
    
    func setupDataWhenUsingPromos(with data: Voucher?) {
        guard let data = data else {
            stackPromos.isHidden = true
            labelMoney.text = CartManager.shared.totalMoneyAllProductTypeString()
            labelTotalAmount.text = "Tổng cộng (\(CartManager.shared.totalQuantity()) món)"
            labelTotalMoney.text = CartManager.shared.totalMoneyAllProductTypeString()
            return
        }
        
        stackPromos.isHidden = false
        labelMoney.text = CartManager.shared.totalMoneyAllProductTypeString()
        labelTotalAmount.text = "Tổng cộng (\(CartManager.shared.totalQuantity()) món)"
        
        var totalMoneyWhenUsingPromos: Double = 0
        var amountPromos: Double = 0
        switch (VoucherUseType.init(rawValue: data.UseType ?? 0) ?? .amount) {
            case .amount:
                amountPromos = (data.Amount ?? 0)
                totalMoneyWhenUsingPromos = CartManager.shared.totalMoneyAllProduct() - (data.Amount ?? 0)
                break
            case .precent:
                let percent: Double = Double(data.Percent ?? 0)
                amountPromos = (CartManager.shared.totalMoneyAllProduct() / percent)
                totalMoneyWhenUsingPromos = CartManager.shared.totalMoneyAllProduct() - amountPromos
                break
        }
        
        labelPromosMoney.text = "-" + amountPromos.formatMoney
        labelTotalMoney.text = totalMoneyWhenUsingPromos.formatMoney
    }
    
    private func configTableview() {
        orderItemProvider.data = CartManager.shared.getDataCart()
        tableView.alwaysBounceVertical = true
        tableView.separatorStyle = .none
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 50.heightRatio
        tableView.register(cellClass: OrderItemCell.self)
        
        orderItemDataSource = TableViewDataSource(dataProvider: orderItemProvider)
        
        orderItemDataSource.configureCell = { [weak self] cell, model, index in
            guard let _ = self else { return }
            cell.bindData(with: model, and: index.row)
            cell.selectionStyle = .none
        }
        
        tableView.dataSource = orderItemDataSource
        tableView.reloadData()
    }
    
    // MARK: - Action
    @objc private func didTapDeliveryVatButton() {
        didTapDeliveryTermInfo?()
    }
    
    @objc private func didTapExportVatButton() {
        didCheckVat = !didCheckVat
        didExportVat?()
        guard let isVat = UserService.shared.getDataUser().IsVAT else { return }
        if !isVat {
            didCheckVat = !didCheckVat
        }
    }
    
    @objc private func didTapVatInfoButton() {
        didTapVatInfo?()
    }
}

