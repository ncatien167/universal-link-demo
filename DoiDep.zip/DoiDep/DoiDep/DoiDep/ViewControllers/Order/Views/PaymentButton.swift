//
//  PaymentButton.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 24/07/2022.
//

import UIKit

class PaymentButton: UIButton {
    lazy var labelTitle: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textAlignment = .left
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 15, weight: .light)
        return label
    }()
    
    lazy var iconImage: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    lazy var button: UIButton = {
        let button = UIButton()
        button.backgroundColor = .clear
        button.addTarget(self, action: #selector(didTapButton), for: .touchUpInside)
        button.isHighlighted = true
        return button
    }()
    
    var didTap: (()->())?
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        let stackView = UIStackView(arrangedSubviews: [iconImage, labelTitle])
        stackView.axis = .horizontal
        stackView.alignment = .center
        stackView.distribution = .fill
        
        self.addSubviews(stackView,button)
        stackView.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview()
            make.centerY.equalToSuperview()
        }

        button.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview()
        }
        
        iconImage.setConstraintWidthAndHeight(widthConstant: 30.heightRatio, heightConstant: 30.heightRatio)
    }
    
    func setup(with title: String, and image: UIImage?) {
        labelTitle.text = title
        iconImage.image = image
    }
    
    @objc private func didTapButton() {
        self.didTap?()
    }
}

