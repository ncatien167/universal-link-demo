//
//  OrderItemCell.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 21/07/2022.
//

import UIKit

class OrderItemCell: UITableViewCell {
    
    // MARK: - UI
    lazy var viewBoundContent: UIView = {
         let view = UIView()
         view.backgroundColor = .white
         view.translatesAutoresizingMaskIntoConstraints = false
         view.layer.cornerRadius = 5
         view.layer.shadowColor = UIColor.lightGray.cgColor
         view.layer.shadowOpacity = 0.5
         view.layer.shadowOffset = CGSize.zero
         view.layer.shadowRadius = 5
         return view
    }()
    
    lazy var labelTitle: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 15, weight: .regular)
        label.textColor = Colors.normalTextColor
        label.numberOfLines = 0
        return label
    }()
    
    lazy var labelSubTitle: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 15, weight: .regular)
        label.textColor = Colors.normalTextColor
        return label
    }()
    
    lazy var labelMoney: UILabel = {
        let label = UILabel()
        label.textAlignment = .right
        label.font = UIFont.systemFont(ofSize: 15, weight: .regular)
        label.textColor = Colors.normalTextColor
        return label
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.setupUI()
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.awakeFromNib()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.awakeFromNib()
    }
    
    func setupUI() {
        let stackTitle = UIStackView(arrangedSubviews: [labelTitle, labelMoney])
        stackTitle.axis = .horizontal
        stackTitle.alignment = .fill
        stackTitle.distribution = .fill
        stackTitle.spacing = 10
        
        let stackContent = UIStackView(arrangedSubviews: [stackTitle, labelSubTitle])
        stackContent.spacing = 10
        stackContent.axis = .vertical
        stackContent.alignment = .fill
        stackContent.distribution = .fill

        self.contentView.addSubviews(viewBoundContent)
        viewBoundContent.addSubview(stackContent)
        
        viewBoundContent.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview()
        }
        
        stackContent.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview().inset(10.heightRatio)
        }
    }
    
    func bindData(with data: CartData, and index: Int) {
        let quantity = data.Quantity ?? 1
        labelTitle.text = "\(index + 1). \(data.Name ?? "")"
        if quantity > 1 {
            labelTitle.text = "\(index + 1). \(data.Name ?? "") x\(quantity)"
        }
        
        labelMoney.text = data.totalPrice()
        
        if data.groupName() == "" {
            labelSubTitle.isHidden = true
        } else {
            labelSubTitle.isHidden = false
            labelSubTitle.text = data.groupName()
        }
    }
}

extension UIView {
    func dropShadow(scale: Bool = true) {
        layer.masksToBounds = false
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOpacity = 0.5
        layer.shadowOffset = CGSize(width: -1, height: 1)
        layer.shadowRadius = 1

        layer.shadowPath = UIBezierPath(rect: bounds).cgPath
        layer.shouldRasterize = true
        layer.rasterizationScale = scale ? UIScreen.main.scale : 1
      }
}
