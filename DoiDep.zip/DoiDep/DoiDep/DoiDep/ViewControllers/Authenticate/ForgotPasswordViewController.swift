//
//  ForgotPasswordViewController.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 17/08/2022.
//

import UIKit

class ForgotPasswordViewController: AppNavigationVC {
    
    // MARK: - UI INIT
    lazy var mainIconImageView: UIImageView = {
        let imageView = UIImageView(image: UIImage().getImage(with: "logo_white_notagline", and: Bundle(for: LoginViewController.self))!)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    lazy var contentLoginView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 10
        return view
    }()
    
    lazy var contentStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.alignment = .center
        stackView.distribution = .fill
        stackView.spacing = 20.heightRatio
        return stackView
    }()
    
    lazy var phoneTextfield: InputView = {
        let inputView = InputView()
        inputView.setup(placeholder: "SDT")
        inputView.textField.keyboardType = .numberPad
        return inputView
    }()
    
    lazy var labelError: UILabel = {
        let label = UILabel()
        label.isHidden = true
        label.textColor = .red
        label.numberOfLines = 0
        label.font = UIFont.systemFont(ofSize: 14, weight: .light)
        return label
    }()
    
    lazy var buttonLogin: CommonButton = {
        let button = CommonButton()
        button.setup(title: "XÁC NHẬN".uppercased(), 5)
        button.didTap = { [weak self] in
            guard let self = self else { return }
            self.reSendOTP()
        }
        return button
    }()
    
    lazy var contentForgotStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.alignment = .center
        stackView.distribution = .equalSpacing
        stackView.spacing = 10.heightRatio
        return stackView
    }()
    
    lazy var contentOTPForgotStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.alignment = .center
        stackView.distribution = .equalSpacing
        stackView.spacing = 10.heightRatio
        stackView.isHidden = true
        return stackView
    }()
    
    lazy var buttonLoginNow: UIButton = {
        let button = UIButton()
        button.setTitle("Đã có tài khoản?     Đăng nhập ngay", for: .normal)
        button.setTitleColor(Colors.authenticateColor, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .light)
        button.addTarget(self, action: #selector(didTapLoginNow), for: .touchUpInside)
        return button
    }()
    
    lazy var otpTextfield: TextField = {
        let textField = TextField()
        textField.placeholder = "Nhập mã OTP"
        textField.backgroundColor = .white
        textField.font = UIFont.systemFont(ofSize: 15)
        textField.layer.cornerRadius = 10
        textField.layer.borderWidth = 0.5
        textField.layer.borderColor = Colors.mainColor.cgColor
        textField.layer.masksToBounds = true
        textField.keyboardType = .numberPad
        textField.padding = UIEdgeInsets(top: 0, left: 10.widthRatio, bottom: 0, right: 0)
        return textField
    }()
    
    lazy var newPasswordTextfield: TextField = {
        let textField = TextField()
        textField.placeholder = "Mật khẩu mới"
        textField.backgroundColor = .white
        textField.font = UIFont.systemFont(ofSize: 15)
        textField.layer.cornerRadius = 10
        textField.layer.borderWidth = 0.5
        textField.layer.borderColor = Colors.mainColor.cgColor
        textField.layer.masksToBounds = true
        textField.isSecureTextEntry = true
        textField.padding = UIEdgeInsets(top: 0, left: 10.widthRatio, bottom: 0, right: 0)
        return textField
    }()
    
    lazy var confirmPasswordTextfield: TextField = {
        let textField = TextField()
        textField.placeholder = "Xác nhận mật khẩu"
        textField.backgroundColor = .white
        textField.font = UIFont.systemFont(ofSize: 15)
        textField.layer.cornerRadius = 10
        textField.layer.borderWidth = 0.5
        textField.layer.borderColor = Colors.mainColor.cgColor
        textField.layer.masksToBounds = true
        textField.isSecureTextEntry = true
        textField.padding = UIEdgeInsets(top: 0, left: 10.widthRatio, bottom: 0, right: 0)
        return textField
    }()
    
    lazy var buttonReSend: UIButton = {
        let button = UIButton()
        button.setTitle("Gửi lại mã", for: .normal)
        button.setTitleColor(Colors.authenticateColor, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .light)
        button.addTarget(self, action: #selector(reSendOTP), for: .touchUpInside)
        return button
    }()
    
    lazy var buttonUpdate: CommonButton = {
        let button = CommonButton()
        button.setup(title: "CẬP NHẬT".uppercased(), 5)
        button.backgroundButton.image = nil
        button.backgroundColor = .white
        button.button.setTitleColor(Colors.mainColor, for: .normal)
        button.didTap = { [weak self] in
            guard let self = self else { return }
            self.updatePassword()
        }
        return button
    }()
    
    // MARK: - Presenter
    
    var presenter: ForgotPasswordPresenter?
    
    private var OTPData: ResponseOTP?
    
    // MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        presenter = ForgotPasswordPresenter(self)
        setupUI()
        handleInputField()
    }
    
    deinit {
        presenter = nil
    }
    
    private func setupUI() {
        self.headerView.title = ""
        
        let labelForgot = UILabel()
        labelForgot.text = "Lấy lại mật khẩu".uppercased()
        labelForgot.font = UIFont.systemFont(ofSize: 17, weight: .bold)
        labelForgot.textColor = .white
        labelForgot.textAlignment = .center
        
        let labelDes = UILabel()
        labelDes.text = "Vui lòng nhập SĐT\nđể xác nhận lại mật khẩu"
        labelDes.font = UIFont.italicSystemFont(ofSize: 15)
        labelDes.textColor = .white
        labelDes.textAlignment = .center
        labelDes.numberOfLines = 0
        self.view.addSubviews(mainIconImageView, contentLoginView, labelForgot, labelDes)
        
        mainIconImageView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().inset(NAV_BAR_HEIGHT)
            make.width.height.equalTo(120.widthRatio)
        }
        
        labelForgot.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(mainIconImageView.snp.bottom).offset(40.heightRatio)
            make.width.equalTo(300.widthRatio)
        }
        
        labelDes.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(labelForgot.snp.bottom).offset(30.heightRatio)
            make.width.equalTo(300.widthRatio)
        }
        
        contentLoginView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.width.equalTo(300.widthRatio)
            make.top.equalTo(labelDes.snp.bottom).offset(30.heightRatio)
        }
        
        contentForgotStackView.addArrangedSubview(phoneTextfield)
        contentForgotStackView.addArrangedSubview(labelError)
        contentForgotStackView.addArrangedSubview(buttonLogin)
        contentForgotStackView.addArrangedSubview(buttonLoginNow)
        
        let reSendView = UIView()
        reSendView.addSubview(buttonReSend)
        
        contentOTPForgotStackView.addArrangedSubview(otpTextfield)
        contentOTPForgotStackView.addArrangedSubview(reSendView)
        contentOTPForgotStackView.addArrangedSubview(newPasswordTextfield)
        contentOTPForgotStackView.addArrangedSubview(confirmPasswordTextfield)
        
        let contentStackView = UIStackView(arrangedSubviews: [contentForgotStackView, contentOTPForgotStackView])
        contentStackView.alignment = .center
        contentStackView.distribution = .equalSpacing
        contentStackView.axis = .vertical
        contentStackView.spacing = 10.heightRatio
        
        contentLoginView.addSubviews(contentStackView)
        
        contentStackView.snp.makeConstraints { make in
            make.top.leading.equalToSuperview().offset(20.widthRatio)
            make.trailing.equalToSuperview().offset(-20.widthRatio)
            make.bottom.equalToSuperview().inset(10.heightRatio)
        }
        
        buttonReSend.snp.makeConstraints { make in
            make.top.trailing.bottom.equalToSuperview()
        }
        
        labelError.setConstraintWidth(constant: 250.widthRatio)
        reSendView.setConstraintWidth(constant: 250.widthRatio)
        buttonLogin.setConstraintWidthAndHeight(widthConstant: 150.widthRatio, heightConstant: 30.heightRatio)
        phoneTextfield.setConstraintWidthAndHeight(widthConstant: 250.widthRatio, heightConstant: 40.heightRatio)
        otpTextfield.setConstraintWidthAndHeight(widthConstant: 250.widthRatio, heightConstant: 40.heightRatio)
        newPasswordTextfield.setConstraintWidthAndHeight(widthConstant: 250.widthRatio, heightConstant: 40.heightRatio)
        confirmPasswordTextfield.setConstraintWidthAndHeight(widthConstant: 250.widthRatio, heightConstant: 40.heightRatio)
    }
    
    private func updateUIWithOTP() {
        DispatchQueue.main.async {
            self.contentStackView.removeArrangedSubview(self.buttonLoginNow)
            self.contentForgotStackView.isHidden = true
            self.contentOTPForgotStackView.isHidden = false
            
            self.buttonLoginNow.setTitleColor(Colors.white, for: .normal)
            
            self.view.addSubviews(self.buttonUpdate, self.buttonLoginNow)
            self.buttonUpdate.snp.makeConstraints { make in
                make.width.equalTo(200.widthRatio)
                make.centerX.equalToSuperview()
                make.top.equalTo(self.contentLoginView.snp.bottom).offset(20.heightRatio)
            }
            
            self.buttonLoginNow.snp.makeConstraints { make in
                make.width.equalTo(300.widthRatio)
                make.centerX.equalToSuperview()
                make.top.equalTo(self.buttonUpdate.snp.bottom).offset(20.heightRatio)
            }
        }
    }
    
    private func handleInputField() {
        phoneTextfield.didBeginEditText = { [weak self] in
             guard let _ = self else { return }
             
        }
        phoneTextfield.didEditingChanged = { [weak self] in
             guard let self = self else { return }
             if let numb = self.phoneTextfield.textField.text {
                  if numb.count > 10 {
                       self.phoneTextfield.textField.text = String(numb.dropLast())
                  }
             }
        }
    }
    
    // MARK: - Action
    
    private func didTapLoginButton() {
        guard let phone = phoneTextfield.textField.text else {
            return
        }
        
        if phone.isEmpty || phone == "" || phone.count == 0 {
            self.labelError.text = "Vui lòng nhập Số điện thoại"
            self.labelError.isHidden = false
            return
        }
        if !phone.checkPhoneNumber() {
            self.labelError.text = "Vui lòng nhập đúng định dạng Số điện thoại"
            self.labelError.isHidden = false
            return
        }
        
        self.labelError.isHidden = true
        self.showLoading()
        self.presenter?.requestResetPassword(with: phone)
    }
    
    @objc private func didTapClose() {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc private func didTapSignUp() {
        self.navigationController?.pushViewController(SignUpViewController(), animated: true)
    }
    
    @objc private func didTapLoginNow() {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc private func reSendOTP() {
        didTapLoginButton()
    }
    
    private func updatePassword() {
        guard let OTP = otpTextfield.text, let newPass = newPasswordTextfield.text, let confirmPass = confirmPasswordTextfield.text else {
            self.labelError.text = "Vui lòng nhập đầy đủ thông tin"
            self.labelError.isHidden = false
            return
        }
        
        if OTP.isEmpty || OTP == "" || OTP.count == 0 {
            self.labelError.text = "Vui lòng nhập mã OTP"
            self.labelError.isHidden = false
            return
        }
        if newPass.isEmpty || newPass == "" || newPass.count == 0 {
            self.labelError.text = "Vui lòng nhập mật khẩu mới"
            self.labelError.isHidden = false
            return
        }
        if confirmPass.isEmpty || confirmPass == "" || confirmPass.count == 0 {
            self.labelError.text = "Vui lòng nhập lại mật khẩu mới"
            self.labelError.isHidden = false
            return
        }
        
        self.labelError.isHidden = true
        self.showLoading()
        presenter?.requestResetPasswordComplete(with: OTP, password: newPass, and: self.OTPData)
    }
}

// MARK: - Handle ForgotPassword View
extension ForgotPasswordViewController: ForgotPasswordView {
    func onShowOtp(with OTPData: ResponseOTP?) {
        self.hideLoading()
        self.OTPData = OTPData
        self.updateUIWithOTP()
    }
    
    func onChangePasswordSuccess() {
        self.hideLoading()
        CommonPopup.showAlertOnlyOk("Đổi mật khẩu thành công", title: nil) { [weak self] in
            guard let self = self else { return }
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func onCheckForgotPasswordFailed(with message: String) {
        self.hideLoading()
        CommonPopup.showAlertOnlyOk(message, title: nil) { [weak self] in
            guard let _ = self else { return }

        }
    }
}
