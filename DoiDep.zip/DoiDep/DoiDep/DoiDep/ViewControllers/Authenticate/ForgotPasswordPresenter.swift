//
//  ForgotPasswordPresenter.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 17/08/2022.
//

import Foundation
import AVFoundation

protocol ForgotPasswordView {
    func onShowOtp(with OTPData: ResponseOTP?)
    func onChangePasswordSuccess()
    func onCheckForgotPasswordFailed(with message: String)
}

protocol ForgotPasswordViewPresenter {
    init(_ view: ForgotPasswordView)
    
    func requestResetPassword(with phone: String)
    func requestResetPasswordComplete(with OTPString: String, password: String, and OTPData: ResponseOTP?)
}

class ForgotPasswordPresenter: ForgotPasswordViewPresenter {
    
    var view: ForgotPasswordView?
    
    required init(_ view: ForgotPasswordView) {
        self.view = view
    }
    
    func requestResetPassword(with phone: String) {
        LoginService.requestResetPassword(with: phone) { status, dataOTP in
            guard let status = status else {
                self.view?.onCheckForgotPasswordFailed(with: dataOTP?.Message ?? "Vui lòng thực hiện lại")
                return
            }
            
            if status {
                self.view?.onShowOtp(with: dataOTP)
            } else {
                self.view?.onCheckForgotPasswordFailed(with: dataOTP?.Message ?? "Vui lòng thực hiện lại")
            }
        }
    }
    
    func requestResetPasswordComplete(with OTPString: String, password: String, and OTPData: ResponseOTP?) {
        let params: [String:Any] = ["OTP": OTPString,
                                   "RefKey": OTPData?.RefKey ?? "", "Password": password]
        LoginService.requestPasswordComplete(with: params) { status, mess in
            guard let status = status else {
                self.view?.onCheckForgotPasswordFailed(with: mess ?? "Đã có lỗi xảy ra. Vui lòng thực hiện lại")
                return
            }
            
            if status {
                self.view?.onChangePasswordSuccess()
            } else {
                self.view?.onCheckForgotPasswordFailed(with: mess ?? "Đã có lỗi xảy ra. Vui lòng thực hiện lại")
            }
        }
    }

}
