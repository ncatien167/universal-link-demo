//
//  OTPPresenter.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 17/08/2022.
//

import Foundation

protocol OTPView {
    func onVerifyOTPSuccess()
    func onVerifyOTPFailed(with message: String)
}

protocol OTPViewPresenter {
    init(_ view: OTPView)
    
    func requestVerify(with OTPString: String, OTPData: ResponseOTP?)
}

class OTPPresenter: OTPViewPresenter {

    var view: OTPView?
    
    required init(_ view: OTPView) {
        self.view = view
    
    }
    
    func requestVerify(with OTPString: String, OTPData: ResponseOTP?) {
        OTPService.requestVerify(with: OTPString, and: OTPData?.RefKey ?? "") { status, mess in
            guard let status = status, let mess = mess else {
                self.view?.onVerifyOTPFailed(with: "Lỗi không xác định")
                return
            }
            if !status {
                self.view?.onVerifyOTPFailed(with: mess)
                return
            }
            
            self.view?.onVerifyOTPSuccess()
        }
    }
}
