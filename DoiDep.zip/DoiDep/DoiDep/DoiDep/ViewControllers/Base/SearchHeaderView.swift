//
//  SearchHeaderView.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 15/07/2022.
//

import UIKit

class SearchHeaderView: UIView {
    
    lazy var contentSearchHeaderView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        return view
    }()
    
    lazy var iconLogo: UIImageView = {
        let imageView = UIImageView(image: UIImage().getImage(with: "ic_arrow_left", and: Bundle(for: SearchHeaderView.self)))
        imageView.contentMode = .scaleAspectFit
        let gesture = UITapGestureRecognizer(target: self, action: #selector(didTapLeft))
        imageView.addGestureRecognizer(gesture)
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    
    lazy var iconCart: UIImageView = {
        let imageView = UIImageView(image: UIImage().getImage(with: "ic_cart_white", and: Bundle(for: SearchHeaderView.self)))
        imageView.contentMode = .scaleAspectFit
        let gesture = UITapGestureRecognizer(target: self, action: #selector(didTapRight))
        imageView.addGestureRecognizer(gesture)
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    
    lazy var labelBadgeNumber: UILabel = {
        let label = UILabel()
        label.isHidden = true
        label.textColor = .white
        label.backgroundColor = .red
        label.layer.cornerRadius = 8.heightRatio
        label.layer.masksToBounds = true
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 12, weight: .bold)
        return label
    }()
    
    lazy var searchTextField: TextField = {
        let textField = TextField()
        textField.placeholder = "Tìm kiếm"
        textField.backgroundColor = .white
        textField.font = UIFont.systemFont(ofSize: 15)
        textField.layer.cornerRadius = 10
        textField.layer.masksToBounds = true
        textField.addTarget(self, action: #selector(textFieldBeginEdit), for: .editingDidBegin)
        textField.addTarget(self, action: #selector(textFieldEndEdit), for: .editingDidEnd)
        textField.addTarget(self, action: #selector(textFieldEditingChangedValue), for: .editingChanged)
        textField.padding = UIEdgeInsets(top: 0, left: 30.widthRatio, bottom: 0, right: 0)
        textField.setLeftImage(image: UIImage().getImage(with: "icon_search", and: Bundle(for: SearchHeaderView.self)))
        return textField
    }()
    
    var badgeNumber: Int = 0 {
        didSet {
            if badgeNumber >= 1 {
                labelBadgeNumber.isHidden = false
                labelBadgeNumber.text = "\(badgeNumber)"
            } else {
                labelBadgeNumber.isHidden = true
            }
        }
    }
    
    var tapLeft: (()->())?
    var tapRight: (()->())?
    var didHandleAction: (()->())?
    var textFieldDidEndEdit: (()->())?
    var textFieldDidBeginEdit: (()->())?
    var textFieldEditingChanged: (()->())?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setupView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    private func setupView() {
        addSubview(labelBadgeNumber)
        let stackViewContent = UIStackView(arrangedSubviews: [iconLogo, searchTextField, iconCart])
        stackViewContent.axis = .horizontal
        stackViewContent.spacing = 5.widthRatio
        stackViewContent.alignment = .fill
        stackViewContent.distribution = .fill
        addSubview(stackViewContent)
        
        iconLogo.setConstraintWidth(constant: 25.heightRatio)
        iconCart.setConstraintWidth(constant: 25.heightRatio)
        
        stackViewContent.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(!DeviceType.isIphoneX() ? STATUS_BAR_HEIGHT : NAV_BAR_HEIGHT)
            make.bottom.equalToSuperview().inset(10.heightRatio)
            make.leading.trailing.equalToSuperview().inset(10.widthRatio)
        }
        
        labelBadgeNumber.snp.makeConstraints { make in
            make.top.equalTo(iconCart.snp.top).offset(-5.heightRatio)
            make.trailing.equalTo(iconCart.snp.trailing).offset(10.heightRatio)
            make.width.height.equalTo(16.heightRatio)
        }
    }
    
    @objc private func didTapLeft() {
        tapLeft?()
    }
    
    @objc private func didTapRight() {
        tapRight?()
    }
    
    // MARK: - ACTION TEXTFIELD
    
    @objc func textFieldBeginEdit() {
         textFieldDidBeginEdit?()
    }
    
    @objc func textFieldEndEdit() {
         textFieldDidEndEdit?()
    }
    
    @objc func textFieldEditingChangedValue() {
         textFieldEditingChanged?()
    }
}

extension UITextField{
    func setLeftImage(image: UIImage?) {
        let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 10.widthRatio, height: 10.widthRatio))
        imageView.image = image
        self.leftView = imageView
        self.leftViewMode = .always
    }
}
