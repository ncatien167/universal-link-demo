//
//  RoomInfoViewController.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 15/4/25.
//

import UIKit

// MARK: - ViewController
final class RoomInfoViewController: UIViewController {
    
    @IBOutlet weak var imageRoom: UIImageView!
    
    @IBOutlet weak var hotelNameLabel: UILabel!
    
    @IBOutlet weak var guestLabel: UILabel!
    
    @IBOutlet weak var roomKindLabel: UILabel!
    
    @IBOutlet weak var numberOfNightss: UILabel!
    
    @IBOutlet weak var numberOfRoom: UILabel!
    
    @IBOutlet weak var priceRoomLabel: UILabel!
    
    @IBOutlet weak var priceRoomForOneNightLabel: UILabel!
    
    @IBOutlet weak var totalMoneyLabel: UILabel!
    
    
    var room: Room?
    var bookingInfo: BookingInfo?
    var onDone: (() -> Void)?
    
    // MARK: Life‑cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()

    }
    
    private func setupUI() {
        let hotel = bookingInfo?.hotel
        let guest = bookingInfo?.guest
        hotelNameLabel.text = bookingInfo?.bookingHotel?.Name
        guestLabel.text = "\(guest?.adults ?? 1) người lớn, \(guest?.children ?? 0) trẻ em"
        numberOfRoom.text = "\(guest?.rooms ?? 1)"
        roomKindLabel.text = room?.roomKind
        let checkInDate = bookingInfo?.checkInDate?.toString(dateFormat: "dd-MM-yyyy") ?? ""
        let checkOutDate = bookingInfo?.checkOutDate?.toString(dateFormat: "dd-MM-yyyy") ?? ""
        
        numberOfNightss.text = checkInDate + " - " + checkOutDate
        
        let priceRoom = (room?.price ?? 0) * Double(bookingInfo?.numberOfNight ?? 1)
        priceRoomForOneNightLabel.text = priceRoom.formatMoneyBooking
        priceRoomLabel.text = room?.price?.formatMoneyBooking

        let totalMoney = (priceRoom) * Double(guest?.rooms ?? 1)
        totalMoneyLabel.text = totalMoney.formatMoneyBooking
    }
    
    @IBAction func doneTapped(_ sender: UIButton) {
        onDone?()
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func closeTapped(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
}
