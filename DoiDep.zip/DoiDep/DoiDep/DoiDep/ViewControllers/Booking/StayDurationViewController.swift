//
//  StayDurationViewController.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 13/4/25.
//

import UIKit

class StayDurationViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    var checkInDate: Date!
    var selectedNights: Int = 1
    var options: [(title: String, subtitle: String)] = []
    
    var onDone: ((Int, Date) -> Void)? // callback (số đêm, ngày trả phòng)

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UINib(nibName: "StayOptionCell", bundle: nil), forCellReuseIdentifier: "StayOptionCell")
        generateOptions()
    }

    func generateOptions() {
        options = []
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        let calendar = Calendar.current

        for night in 1...30 {
            if let checkOut = calendar.date(byAdding: .day, value: night, to: checkInDate) {
                let title = "\(night) đêm"
                let subtitle = "Trả phòng: \(formatter.string(from: checkOut))"
                options.append((title, subtitle))
            }
        }
        tableView.reloadData()
    }

    @IBAction func doneTapped(_ sender: UIButton) {
        let calendar = Calendar.current
        if let checkOutDate = calendar.date(byAdding: .day, value: selectedNights, to: checkInDate) {
            onDone?(selectedNights, checkOutDate)
        }
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func closeTapped(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
}

extension StayDurationViewController: UITableViewDataSource, UITableViewDelegate {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return options.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "StayCell", for: indexPath) as! StayOptionCell
        let option = options[indexPath.row]
        cell.titleLabel.text = option.title
        cell.subtitleLabel.text = option.subtitle
        
        let isSelected = indexPath.row + 1 == selectedNights
        cell.radioImageView.image = UIImage(named: isSelected ? "ic_radio_check_button_booking" : "ic_radio_un_check_button_booking")
            
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedNights = indexPath.row + 1
        tableView.reloadData()
    }
}
