//
//  BookingPaymentViewController.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 16/4/25.
//

import UIKit

// MARK: - ViewController
final class BookingPaymentViewController: AppNavigationVC {
    
    @IBOutlet weak var hotelNamLabel: UILabel!
    @IBOutlet weak var numberOfNightsLabel: UILabel!
    @IBOutlet weak var numberOfRoomsLabel: UILabel!
    @IBOutlet weak var numberOfGuestLabel: UILabel!
    @IBOutlet weak var roomKindLabel: UILabel!
    @IBOutlet weak var dayInLabel: UILabel!
    @IBOutlet weak var dayOutLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var phoneLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var guestNameLabel: UILabel!
    @IBOutlet weak var roomTypeLabel: UILabel!
    @IBOutlet weak var roomPriceLabel: UILabel!
    @IBOutlet weak var totalPriceBlackLabel: UILabel!
    @IBOutlet weak var totalPriceBlueLabel: UILabel!
    @IBOutlet weak var roomTypeTitleLabel: UILabel!
    @IBOutlet weak var roomRuleLabel: UILabel!
    @IBOutlet weak var customerStackView: UIStackView!
    @IBOutlet weak var headerHeightConstraint: NSLayoutConstraint!
    
    var room: Room?
    var bookingInfo: BookingInfo?
    var onDone: (() -> Void)?
    var customerBookingInfo: CustomerBookingInfo = CustomerBookingInfo(bookingName: UserService.shared.getDataUser().FullName, contact: UserService.shared.getDataUser().getPhone(), email: UserService.shared.getDataUser().getEmail())
    // MARK: Life‑cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        // Chiều cao chuẩn: topInset + chiều cao content (ví dụ 44)
        let topInset = view.safeAreaInsets.top
        headerHeightConstraint.constant = topInset + 44
    }
    
    private func setupUI() {
        self.headerView.isHidden = true
        self.backgroundImageView.isHidden = true
        hotelNamLabel.text = bookingInfo?.bookingHotel?.Name
        roomTypeTitleLabel.text = room?.roomType
        numberOfNightsLabel.text = "\(bookingInfo?.numberOfNight ?? 1) đêm"
        numberOfRoomsLabel.text = "\(bookingInfo?.guest?.rooms ?? 1) phòng"
        numberOfGuestLabel.text = "\(bookingInfo?.guest?.adults ?? 1) người lớn"
        roomKindLabel.text = room?.roomKind
        
        dayInLabel.text = "\(bookingInfo?.checkInDate?.toString(dateFormat: "dd-MM-yyyy") ?? "") (15:00 - 03:00)"
        dayOutLabel.text = "\(bookingInfo?.checkOutDate?.toString(dateFormat: "dd-MM-yyyy") ?? "") (trước 11:00)"
        
        guestNameLabel.text = UserService.shared.getDataUser().FullName
        nameLabel.text = UserService.shared.getDataUser().FullName
        phoneLabel.text = UserService.shared.getDataUser().getPhone()
        emailLabel.text = UserService.shared.getDataUser().getEmail()
        
        roomTypeLabel.text = room?.roomType
        roomPriceLabel.text = room?.price?.formatMoney
        roomTypeLabel.text = room?.roomType
        
        let priceRoom = (room?.price ?? 0) * Double(bookingInfo?.numberOfNight ?? 1)
        let totalMoney = (priceRoom) * Double(bookingInfo?.guest?.rooms ?? 1)
        totalPriceBlackLabel.text = totalMoney.formatMoneyBooking
        totalPriceBlueLabel.text = totalMoney.formatMoneyBooking
        
        let checkOutDate = (bookingInfo?.checkOutDate?.toString(dateFormat: "dd-MM-yyyy") ?? "")
        let checkInDate = (bookingInfo?.checkInDate?.toString(dateFormat: "dd-MM-yyyy") ?? "")
        roomRuleLabel.text = "Áp dụng chính sách hủy phòng\nMiễn phí hủy trước \(checkInDate) 14:00. Nếu hủy hoặc sửa đổi sau \(checkOutDate) 14:01, phí hủy đặt phòng sẽ được tính."
        
        let infoCustomerTap = UITapGestureRecognizer(target: self, action: #selector(didTapCustomerInfo))
        customerStackView.addGestureRecognizer(infoCustomerTap)
    }
    
    @objc func didTapCustomerInfo() {
        
    }
    
    @IBAction func backAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func bookingTapped(_ sender: Any) {
        paymentBooking()
    }
    
    private func pushToSuccess(_ string: String) {
        let storyboard = UIStoryboard(name: "Booking", bundle: nil)
        if let vc = storyboard.instantiateViewController(withIdentifier: "BookingSuccessViewController") as? BookingSuccessViewController {
            vc.bookingInfo = self.bookingInfo
            vc.room = self.room
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
}

// MARK: - API
extension BookingPaymentViewController {
    private func paymentBooking() {
        showLoading()
        let countRoom = bookingInfo?.guest?.rooms ?? 1
        let numberOfGuest = bookingInfo?.guest?.adults ?? 1
        let numberOfGuestChild = bookingInfo?.guest?.children ?? 1
        let dayIn = bookingInfo?.checkInDate?.toString(dateFormat: "yyyy-MM-dd") ?? ""
        let dayOut = bookingInfo?.checkOutDate?.toString(dateFormat: "yyyy-MM-dd") ?? ""
        let roomKindCode = room?.roomKindCode ?? 0
        let roomTypeCode = room?.roomTypeCode ?? 0
        let roomName = ""
        let price = room?.price ?? 0
        let roomType = room?.roomType ?? ""
        
        
        var roomDetails: [[String: Any]] = []
        let a = countRoom
        var b = numberOfGuest
        var c = numberOfGuestChild
        
        var adults = 0
        var childs = c
        
        for i in 0..<countRoom {
            // Xử lý số người lớn
            if a * 2 == numberOfGuest {
                adults = 2
            } else if a == numberOfGuest {
                adults = 1
            } else if numberOfGuest - a == 1 {
                if i + 1 == a {
                    adults = 1
                } else {
                    adults = 2
                }
            } else if a * 2 - numberOfGuest == 1 {
                if b - 2 == 0 {
                    b = 0
                    adults = 2
                } else if b - 2 == -1 {
                    b = 0
                    adults = 1
                } else {
                    b -= 2
                    adults = 2
                }
            }
            
            // Xử lý số trẻ em
            if c - 1 == -1 {
                c = 0
                childs = 0
            } else {
                c -= 1
                childs = 1
            }
            
            let room: [String: Any] = [
                "adult": adults,
                "child": childs,
                "arrivalDate": dayIn,
                "arrivalTime": "14:00",
                "checkoutDate": dayOut,
                "price": price,
                "roomKind": roomKindCode,
                "roomKindName": roomName,
                "roomType": roomTypeCode,
                "roomTypeName": roomType
            ]
            
            roomDetails.append(room)
        }
        
        let guestName = customerBookingInfo.bookingName ?? ""
        let contact = customerBookingInfo.bookingName ?? ""
        let email = customerBookingInfo.bookingName ?? ""
        
        let params: [String: Any] = [
            "bookingName": guestName,
            "arrivalDate": dayIn,
            "checkoutDate": dayOut,
            "contact": contact,
            "note": "",
            "email": email,
            "roomDetails": roomDetails
        ]
        BookingService.requestPaymentBooking(params: params) { response in
            DispatchQueue.main.async {
                self.hideLoading()
                if response == nil {
                    
                    self.hideLoading()
                    CommonPopup.showAlertOnlyOk("Đặt phòng thất bại. Quý khách vui lòng thử lại", title: "") {

                    }
                    return
                }
                
                self.pushToSuccess(response ?? "")
            }
        }
    }
}

struct CustomerBookingInfo {
    var bookingName: String?
    var contact: String?
    var email: String?
}
