//
//  BookingSuccessViewController.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 20/4/25.
//

import UIKit

// MARK: - ViewController
final class BookingSuccessViewController: AppNavigationVC {
    
    @IBOutlet weak var totalMoneyLabel: UILabel!
    var room: Room?
    var bookingInfo: BookingInfo?
    
    // MARK: Life‑cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()

    }
    
    private func setupUI() {
        self.headerView.isHidden = true
        self.backgroundImageView.isHidden = true
        let priceRoom = (room?.price ?? 0) * Double(bookingInfo?.numberOfNight ?? 1)
        let totalMoney = (priceRoom) * Double(bookingInfo?.guest?.rooms ?? 1)
        totalMoneyLabel.text = totalMoney.formatMoneyBooking
    }
    
    @IBAction func didTapBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func didBackToHome(_ sender: Any) {
        if let homeVC = navigationController?.viewControllers.first(where: { $0 is HomeBookingViewController }) {
            navigationController?.popToViewController(homeVC, animated: true)
        }
    }
    
    @IBAction func didTapHistory(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Booking", bundle: nil)
        if let vc = storyboard.instantiateViewController(withIdentifier: "HistoryBookingViewController") as? HistoryBookingViewController {
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}
