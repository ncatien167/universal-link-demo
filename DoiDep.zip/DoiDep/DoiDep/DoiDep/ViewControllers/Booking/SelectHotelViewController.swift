//
//  SelectHotelViewController.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 19/4/25.
//

import UIKit

class SelectHotelViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var hotels: [BookingHotel] = []
    
    var onDone: ((BookingHotel) -> Void)? // callback (số đêm, ngày trả phòng)

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UINib(nibName: "ListHotelCell", bundle: nil), forCellReuseIdentifier: "ListHotelCell")
    }

    @IBAction func closeTapped(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
}

extension SelectHotelViewController: UITableViewDataSource, UITableViewDelegate {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return hotels.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ListCell", for: indexPath) as! ListHotelCell
        cell.titleLabel.text = hotels[indexPath.row].Name
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.dismiss(animated: true) {
            self.onDone?(self.hotels[indexPath.row])
        }
        
    }
}
