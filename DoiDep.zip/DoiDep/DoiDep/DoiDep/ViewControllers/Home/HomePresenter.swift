//
//  HomePresenter.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 16/07/2022.
//

import UIKit
import CoreLocation

protocol HomeView {
    func onCheckAllCommonApiSuccess(with statusToken: Bool)
    func onReloadProduct(with productsData: [ProductData])
}

protocol HomeViewPresenter {
    init(_ view: HomeView)
    
    func requestAllCommonApi()
    func requestProductForYou()
    func requestProductByCategory(with category: Int)
}

class HomePresenter: HomeViewPresenter {
    private var currentLocation: CLLocation!
    private let locationManager = CLLocationManager()
    private var isValidToken = false
    var view: HomeView?
    
    required init(_ view: HomeView) {
        self.view = view
        setupLocation()
    }
    
    private func setupLocation() {
        switch CLLocationManager.authorizationStatus() {
        case .notDetermined:
            self.locationManager.desiredAccuracy = kCLLocationAccuracyBest
            self.locationManager.requestWhenInUseAuthorization()
            break
        case .restricted, .denied:
            break
        case .authorizedWhenInUse, .authorizedAlways:
            if CLLocationManager.authorizationStatus() == .authorizedWhenInUse ||
                CLLocationManager.authorizationStatus() ==  .authorizedAlways {
                currentLocation = locationManager.location
            }
            break
        default:
            break
        }
    }
    
    
    func requestAllCommonApi() {
        let group = DispatchGroup()
        
        group.enter()
        CommonAPIService.getProvinceData { _ in
            group.leave()
        }
        
        group.enter()
        CommonAPIService.getStoreData { _ in
            self.setupLocationStoreData()
            group.leave()
        }
        
        group.enter()
        CommonAPIService.getCategoryData { _ in
            group.leave()
        }
        
        group.enter()
        CommonAPIService.getTopSalesData { _ in
            group.leave()
        }
        
        group.enter()
        CommonAPIService.getBannerData { _ in
            group.leave()
        }
        
        group.enter()
        CommonAPIService.getBanner7Data { _ in
            group.leave()
        }
        
        if UserService.shared.isLoggedIn {
            group.enter()
            Logger.log(message: "Call Get AddressData", event: .debug)
            CommonAPIService.getAddressData { status in
                if !(status ?? false) {
                    self.isValidToken = true
                }
                group.leave()
            }
            group.enter()
            Logger.log(message: "Call Get getVoucher \(self.isValidToken)", event: .debug)
            CommonAPIService.getVoucher { _ in
                group.leave()
            }
        }
        
        // Finish fetching data
        group.notify(queue: .main) {
            Logger.log(message: "Call Get AddressData not return here \(self.isValidToken)", event: .debug)
            self.view?.onCheckAllCommonApiSuccess(with: self.isValidToken)
        }
    }
    
    func requestProductForYou() {
        ProductService.requestProductForYou { products in
            guard let products = products else {
                self.view?.onReloadProduct(with: [])
                return
            }
            
            self.view?.onReloadProduct(with: products)
        }
    }
    
    func requestProductByCategory(with category: Int) {
        ProductService.requestProductByCategory(with: category) { products in
            guard let products = products else {
                self.view?.onReloadProduct(with: [])
                return
            }
            
            self.view?.onReloadProduct(with: products)
        }
    }
    
    func setupLocationStoreData() {
        switch CLLocationManager.authorizationStatus() {
        case .notDetermined:
            break
        case .restricted, .denied:
            break
        case .authorizedWhenInUse, .authorizedAlways:
                guard let currentLocation = currentLocation else { return }
            let coordinate1 = CLLocation(latitude: currentLocation.coordinate.latitude, longitude: currentLocation.coordinate.longitude)
            var storeDatas = CommonService.shared.getStores()
            for storeDataIndex in 0..<storeDatas.count {
                let coordinate2 = CLLocation(latitude: storeDatas[storeDataIndex].Lat ?? 0, longitude: storeDatas[storeDataIndex].Long ?? 0)
                let distanceInMeters = coordinate1.distance(from: coordinate2)
                storeDatas[storeDataIndex].km = distanceInMeters
            }
            CommonService.shared.setStores(with: storeDatas.sorted(by: { ($0.km ?? 0) < ($1.km ?? 0) }))
            break
        default:
            break
        }
    }
}
