//
//  HomeSearchPresenter.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 09/08/2022.
//

import UIKit

protocol HomeSearchView {
    func onReloadProduct(with productsData: [ProductData], and totals: Int)
}

protocol HomeSearchViewPresenter {
    init(_ view: HomeSearchView)
    
    func requestSearch(with query: String, and page: Int)
}

class HomeSearchPresenter: HomeSearchViewPresenter {
    var view: HomeSearchView?
    
    required init(_ view: HomeSearchView) {
        self.view = view
    }
    
    func requestSearch(with query: String, and page: Int) {
        ProductService.requestSearchProduct(with: query, and: page) { responseProducts in
            guard let responseProducts = responseProducts else {
                self.view?.onReloadProduct(with: [], and: 0)
                return
            }
            
            self.view?.onReloadProduct(with: responseProducts.Items ?? [], and: responseProducts.Count ?? 0)
        }
    }
}
