//
//  HomeDetailPresenter.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 17/07/2022.
//

import UIKit

protocol HomeDetailView {
    func onReloadProductData(with product: ProductData)
    func onCheckRequestProDuctDetailFailed()
}

protocol HomeDetailViewPresenter {
    init(_ view: HomeDetailView)
    
    func requestProductDetail(with ID: Int)
}

class HomeDetailPresenter: HomeDetailViewPresenter {
    
    var view: HomeDetailView?
    
    required init(_ view: HomeDetailView) {
        self.view = view
    }
    
    func requestProductDetail(with ID: Int) {
        ProductService.requestProductDetail(with: ID) { product in
            guard let product = product else {
                self.view?.onCheckRequestProDuctDetailFailed()
                return
            }
            
            self.view?.onReloadProductData(with: product)
        }
    }
    
}
