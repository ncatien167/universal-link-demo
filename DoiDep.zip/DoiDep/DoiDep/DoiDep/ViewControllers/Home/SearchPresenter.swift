//
//  SearchPresenter.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 14/08/2022.
//

import Foundation

import UIKit

protocol SearchView {
    func onReloadProduct(with productsData: [ProductData])
}

protocol SearchViewPresenter {
    init(_ view: SearchView)
    
    func requestSearch(with query: String, and page: Int)
}

class SearchPresenter: SearchViewPresenter {
    var view: SearchView?
    
    required init(_ view: SearchView) {
        self.view = view
    }
    
    func requestSearch(with query: String, and page: Int) {
//        ProductService.requestSearchProduct(with: query, and: page) { products in
//            guard let products = products else {
//                self.view?.onReloadProduct(with: [])
//                return
//            }
//
//            self.view?.onReloadProduct(with: products)
//        }
    }
}
