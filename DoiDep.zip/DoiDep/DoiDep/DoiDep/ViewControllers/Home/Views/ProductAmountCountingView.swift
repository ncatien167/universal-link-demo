//
//  ProductAmountCountingView.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 18/07/2022.
//

import UIKit

class ProductAmountCountingView: UIView {
    
    // MARK: - UI
    lazy var labelTitleAmount: UILabel = {
        let label = UILabel()
        label.text = "Số lượng"
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 15, weight: .medium)
        return label
    }()
    
    lazy var labelMinus: UILabel = {
        let label = UILabel()
        label.text = "-"
        label.textColor = Colors.authenticateColor
        label.textAlignment = .center
        label.layer.cornerRadius = 13.heightRatio
        label.layer.borderWidth = 0.5
        label.layer.borderColor = Colors.authenticateColor.cgColor
        label.isUserInteractionEnabled = true
        let gesture = UITapGestureRecognizer(target: self, action: #selector(handleMinusTapped))
        label.addGestureRecognizer(gesture)
        return label
    }()
    
    lazy var labelPlus: UILabel = {
        let label = UILabel()
        label.text = "+"
        label.textColor = Colors.authenticateColor
        label.textAlignment = .center
        label.layer.cornerRadius = 13.heightRatio
        label.layer.borderWidth = 0.5
        label.layer.borderColor = Colors.authenticateColor.cgColor
        label.isUserInteractionEnabled = true
        let gesture = UITapGestureRecognizer(target: self, action: #selector(handlePlusTapped))
        label.addGestureRecognizer(gesture)
        return label
    }()
    
    lazy var amountTextField: UITextField = {
        let textField = UITextField()
        textField.text = "1"
        textField.textColor = Colors.authenticateColor
        textField.textAlignment = .center
        textField.keyboardType = .numberPad
        textField.layer.cornerRadius = 5.heightRatio
        textField.layer.borderWidth = 0.5
        textField.layer.borderColor = Colors.authenticateColor.cgColor
        textField.addTarget(self, action: #selector(textFieldBeginEdit), for: .editingDidBegin)
        textField.addTarget(self, action: #selector(textFieldEndEdit), for: .editingDidEnd)
        textField.addTarget(self, action: #selector(textFieldEditingChangedValue), for: .editingChanged)
        return textField
    }()
    
    private var counterAmount = 1 {
        didSet {
            amountTextField.text = "\(counterAmount)"
        }
    }
    
    var didPlus: ((Int?)->())?
    var didMinus: ((Int?)->())?
    
    var textFieldDidBeginEdit: (()->())?
    var textFieldDidEndEdit: (()->())?
    var textFieldEditingChanged: (()->())?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Setup
    private func setupUI() {
        self.backgroundColor = Colors.customGaryColor
        
        let stackAmount = UIStackView(arrangedSubviews: [labelMinus, amountTextField, labelPlus])
        stackAmount.axis = .horizontal
        stackAmount.alignment = .center
        stackAmount.distribution = .equalCentering
        stackAmount.spacing = 3
        
        let view = UIView()
        view.addSubview(stackAmount)
        
        let contentStack = UIStackView(arrangedSubviews: [labelTitleAmount, view])
        contentStack.axis = .horizontal
        contentStack.alignment = .fill
        contentStack.distribution = .fill
        contentStack.backgroundColor = .white
        self.addSubview(contentStack)
        
        labelMinus.setConstraintWidthAndHeight(widthConstant: 26.heightRatio, heightConstant: 26.heightRatio)
        labelPlus.setConstraintWidthAndHeight(widthConstant: 26.heightRatio, heightConstant: 26.heightRatio)
        amountTextField.setConstraintWidthAndHeight(widthConstant: 50.heightRatio, heightConstant: 35.heightRatio)
        
        labelTitleAmount.setConstraintWidth(constant: 65.widthRatio)
        
        stackAmount.snp.makeConstraints { make in
            make.center.equalToSuperview()
            make.width.equalTo(150.widthRatio)
        }
        
        contentStack.snp.makeConstraints { make in
            make.top.bottom.equalToSuperview().inset(10.heightRatio)
            make.leading.trailing.equalToSuperview()
            make.height.equalTo(50.heightRatio)
        }
        
        contentStack.layoutMargins = UIEdgeInsets(top: 0, left: 15.widthRatio, bottom: 0, right: 0)
        contentStack.isLayoutMarginsRelativeArrangement = true
    }
    
    func getAmount() -> Int {
        return counterAmount
    }
    // MARK: - Action
    
    @objc func textFieldBeginEdit() {
        textFieldDidBeginEdit?()
    }
    
    @objc func textFieldEndEdit() {
        textFieldDidEndEdit?()
        let amountString = amountTextField.text ?? "0"
        let amount = Int(amountString) ?? 0
        counterAmount = amount
    }
    
    @objc func textFieldEditingChangedValue() {
        let amountString = amountTextField.text ?? "0"
        let amount = Int(amountString) ?? 0
        if amount > 100 {
            amountTextField.text = "100"
            counterAmount = 100
            return
        }
    }
    
    @objc private func handleMinusTapped() {
        if counterAmount == 1 {
            return
        }
        
        counterAmount -= 1
        didMinus?(counterAmount)
    }
    
    @objc private func handlePlusTapped() {
        if counterAmount == 100 {
            return
        }
        
        counterAmount += 1
        didPlus?(counterAmount)
    }
}
