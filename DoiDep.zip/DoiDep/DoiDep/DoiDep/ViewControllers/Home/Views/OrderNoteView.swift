//
//  OrderNoteView.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 18/07/2022.
//

import UIKit

class OrderNoteView: UIView {
    
    // MARK: - UI
    lazy var labelTitle: UILabel = {
        let label = UILabel()
        label.text = "Ghi chú"
        label.textAlignment = .left
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 15, weight: .medium)
        return label
    }()
    
    lazy var noteTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Bạn có dặn dò gì không?"
        textField.textColor = Colors.normalTextColor
        textField.backgroundColor = Colors.customGaryColor
        textField.textAlignment = .center
        textField.layer.cornerRadius = 5
        return textField
    }()
    
    // MARK: - Properties
    var didTap: ((OptionGroups?)->())?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Setup
    private func setupUI() {
        self.addSubviews(labelTitle, noteTextField)
        
        labelTitle.snp.makeConstraints { make in
            make.top.equalToSuperview().inset(10.heightRatio)
            make.leading.equalToSuperview().inset(15.widthRatio)
        }
        
        noteTextField.snp.makeConstraints { make in
            make.height.equalTo(35.heightRatio)
            make.bottom.equalToSuperview().inset(20.heightRatio)
            make.top.equalTo(labelTitle.snp.bottom).offset(5.heightRatio)
            make.leading.trailing.equalToSuperview().inset(30.widthRatio)
        }
    }
    
}
