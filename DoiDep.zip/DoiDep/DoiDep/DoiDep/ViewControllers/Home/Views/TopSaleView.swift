//
//  TopSaleView.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 14/08/2022.
//

import UIKit

class TopSaleView: UIView {
    
    lazy var labelTitle: UILabel = {
        let label = UILabel()
        label.text = "Sản phẩm bán chạy"
        label.textColor = Colors.mainColor
        label.font = UIFont.systemFont(ofSize: 14, weight: .bold)
        label.attributedText = NSAttributedString(string: "Sản phẩm bán chạy", attributes: [.underlineStyle: NSUnderlineStyle.single.rawValue])
        return label
    }()
    
    lazy var moreButton: UIButton = {
        let button = UIButton()
        button.isHighlighted = true
        button.setTitle("Xem thêm", for: .normal)
        button.setTitleColor(Colors.normalTextColor, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 13, weight: .light)
        button.addTarget(self, action: #selector(didTapMoreButton), for: .touchUpInside)
        return button
    }()
    
    lazy var collectionView: UICollectionView = {
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 0, left: 10.widthRatio, bottom: 0, right: 0)
//        layout.estimatedItemSize = CGSize(width: 90.heightRatio, height: 100.heightRatio)
//        layout.minimumLineSpacing = 0
//        layout.minimumInteritemSpacing = 0
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.backgroundColor = .clear
        
        return collectionView
    }()
    
    
    // MARK: - Properties
    private var productProvider: DataProvider<ProductData> = DataProvider(data: [])
    private var productDataSource: CollectionViewDataSource<TopSaleCell, ProductData>!
    
    var didTapMore: (()->())?
    var didSelectProduct: ((ProductData?)->())?

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        let stackView = UIStackView(arrangedSubviews: [labelTitle, moreButton])
        stackView.axis = .horizontal
        stackView.alignment = .fill
        stackView.distribution = .fill
        addSubviews(stackView, collectionView)
        
        stackView.snp.makeConstraints { make in
            make.top.leading.trailing.equalToSuperview().inset(5.heightRatio)
        }
        
        collectionView.snp.makeConstraints { make in
            make.height.equalTo(100.widthRatio)
            make.top.equalTo(labelTitle.snp.bottom).offset(5.heightRatio)
            make.bottom.leading.trailing.equalToSuperview().inset(5.heightRatio)
        }
        
        configCollectionView()
    }
    
    private func configCollectionView() {
        collectionView.delegate = self
        collectionView.alwaysBounceVertical = true
        collectionView.register(cellClass: TopSaleCell.self)
        
        productDataSource = CollectionViewDataSource(dataProvider: productProvider)
        
        productDataSource.configureCell = { [weak self] cell, model, index in
            guard let self = self else { return }
            cell.bindDataProduct(with: model, status: index.item)
        }
        
        collectionView.dataSource = productDataSource
        collectionView.reloadData()
    }
    
    func setup(with datas: [ProductData]) {
        DispatchQueue.main.async {
            self.productProvider.data = datas
            self.collectionView.reloadData()
        }
    }
    
    @objc private func didTapMoreButton() {
        didTapMore?()
    }
}

extension TopSaleView: UICollectionViewDelegate, UIScrollViewDelegate, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if productProvider.data.count == 0 {
            return
        }
        
        didSelectProduct?(productProvider.data[indexPath.item])
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 90.widthRatio, height: 100.heightRatio)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        collectionView.contentOffset.y = 0.0
    }
}
