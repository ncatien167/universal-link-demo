//
//  CategoryCell.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 17/07/2022.
//

import UIKit

class CategoryCell: UICollectionViewCell {
    
    lazy var labelTitle: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 14, weight: .medium)
        return label
    }()
    
    lazy var bottomLineView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        return view
    }()
    
    lazy var contentStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.alignment = .center
        stackView.distribution = .fill
        stackView.spacing = 0
        return stackView
    }()
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupUI()
    }
    
    private func setupUI() {
        self.contentStackView.addArrangedSubview(labelTitle)
        self.contentStackView.addArrangedSubview(bottomLineView)
        self.contentView.addSubview(contentStackView)
        
        contentStackView.snp.makeConstraints { make in
            make.bottom.equalToSuperview().inset(5.heightRatio)
            make.top.centerX.equalToSuperview()
        }
            
        bottomLineView.snp.makeConstraints { make in
            make.height.equalTo(2)
            make.width.equalTo(labelTitle.snp.width)
        }
    }
    
    override func preferredLayoutAttributesFitting(_ layoutAttributes: UICollectionViewLayoutAttributes) -> UICollectionViewLayoutAttributes {
        setNeedsLayout()
        layoutIfNeeded()
        let size = contentView.systemLayoutSizeFitting(layoutAttributes.size)
        var frame = layoutAttributes.frame
        frame.size.width = ceil(size.width)
        layoutAttributes.frame = frame
        return layoutAttributes
    }
    
    // MARK: - Bind Data
    func bindDataCategory(with data: ProductCategory) {
        labelTitle.text = data.Name
        let isSelected = data.isSelected ?? false
        if isSelected {
            bottomLineView.isHidden = false
        } else {
            bottomLineView.isHidden = true
        }
    }
    
    func bindDataOrderHeader(with data: OrderHeaderData) {
        labelTitle.text = data.Name
        let isSelected = data.isSelected ?? false
        if isSelected {
            bottomLineView.isHidden = false
        } else {
            bottomLineView.isHidden = true
        }
    }
}
