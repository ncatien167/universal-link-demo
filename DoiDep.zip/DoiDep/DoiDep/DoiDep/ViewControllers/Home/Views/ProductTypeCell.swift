//
//  ProductTypeCell.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 18/07/2022.
//

import UIKit

class ProductTypeCell: UICollectionViewCell {
    
    lazy var labelType: UILabel = {
        let label = UILabel()
        label.textColor = Colors.authenticateColor
        label.textAlignment = .center
        label.layer.cornerRadius = 5
        label.layer.borderWidth = 0.5
        label.layer.borderColor = Colors.authenticateColor.cgColor
        return label
    }()
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupUI()
    }
    
    private func setupUI() {
        self.contentView.addSubview(labelType)
        labelType.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview()
        }

    }
    
    func bindData(with optionGroups: OptionGroups, optionValue: String? = nil) {
        if let optionValue = optionValue, let details = optionGroups.OptionDetails {
            for detail in details {
                if detail.OptionValue == optionValue {
                    labelType.text = detail.OptionValue
                    return
                }
            }
        } else {
            labelType.text = optionGroups.OptionDetails?.first?.OptionValue
        }
        
    }
}
