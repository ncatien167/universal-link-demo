//
//  VoucherViewController.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 24/07/2022.
//

import UIKit

class VoucherViewController: BackNavigationVC {

    // MARK: - UI
    
    lazy var tableView: UITableView = {
        let tableView = UITableView()
        return tableView
    }()
    
    // MARK: - Properties
    private var voucherProvider: DataProvider<Voucher> = DataProvider(data: [])
    private var voucherDataSource: TableViewDataSource<VoucherCell, Voucher>!
    
    var useNow: ((Voucher?)->())?
    
    // MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
        configTableview()
    }
    
    private func setupUI() {
        headerView.title = "Thêm ưu đãi"
        self.view.addSubview(tableView)
        
        tableView.snp.makeConstraints { make in
            make.top.equalTo(headerView.snp.bottom)
            make.bottom.leading.trailing.equalToSuperview()
        }
    }
    
    private func configTableview() {
        let vouchers = VoucherService.shared.getVouchers()
        for voucher in vouchers {
            if let expiredDay = voucher.ExpireDate?.split(separator: "T").first, let date = "\(expiredDay)".convertStringtoDateWith(format: "yyyy-MM-dd") {
                if date >= Date() {
                    voucherProvider.data.append(voucher)
                }
            }
        }
        
        tableView.rowHeight = 85.heightRatio
        tableView.separatorStyle = .none
        tableView.delegate = self
        tableView.alwaysBounceVertical = true
        tableView.register(cellClass: VoucherCell.self)
        
        voucherDataSource = TableViewDataSource(dataProvider: voucherProvider)
        
        voucherDataSource.configureCell = { [weak self] cell, model, index in
            guard let _ = self else { return }
            cell.bindData(with: model)
            cell.selectionStyle = .none
            cell.didTapUseNow = { [weak self] in
                guard let self = self else { return }
                DispatchQueue.main.async {
                    self.useNow?(model)
                    self.navigationController?.popViewController(animated: true)
                }
            }
            
            cell.didTapUseLater = { [weak self] in
                guard let self = self else { return }
                DispatchQueue.main.async {
                    self.useNow?(nil)
                    CartManager.shared.setVoucher(with: nil)
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
        
        tableView.dataSource = voucherDataSource
        tableView.reloadData()
    }
    
    private func handleUseVoucher() {
        
    }
}

extension VoucherViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}
