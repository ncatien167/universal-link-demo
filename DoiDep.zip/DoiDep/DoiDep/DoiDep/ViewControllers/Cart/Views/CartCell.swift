//
//  CartCell.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 18/07/2022.
//

import UIKit

class CartCell: UITableViewCell {
    
    lazy var productImageView: UIImageView = {
        let imageView = UIImageView(image: UIImage().getImage(with: "img_empty.png", and: Bundle(for: CartCell.self))!)
        imageView.contentMode = .scaleAspectFit
        imageView.layer.masksToBounds = true
        imageView.layer.cornerRadius = 5
        return imageView
    }()
    
    lazy var labelTitle: UILabel = {
        let label = UILabel()
        label.numberOfLines = 2
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 15, weight: .bold)
        return label
    }()
    
    lazy var labelPrice: UILabel = {
        let label = UILabel()
        label.textAlignment = .right
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 14, weight: .medium)
        return label
    }()
    
    lazy var labelMinus: UILabel = {
        let label = UILabel()
        label.text = "-"
        label.textColor = Colors.authenticateColor
        label.textAlignment = .center
        label.layer.cornerRadius = 13.heightRatio
        label.layer.borderWidth = 0.5
        label.layer.borderColor = Colors.authenticateColor.cgColor
        label.isUserInteractionEnabled = true
        let gesture = UITapGestureRecognizer(target: self, action: #selector(handleMinusTapped))
        label.addGestureRecognizer(gesture)
        return label
    }()
    
    lazy var labelPlus: UILabel = {
        let label = UILabel()
        label.text = "+"
        label.textColor = Colors.authenticateColor
        label.textAlignment = .center
        label.layer.cornerRadius = 13.heightRatio
        label.layer.borderWidth = 0.5
        label.layer.borderColor = Colors.authenticateColor.cgColor
        label.isUserInteractionEnabled = true
        let gesture = UITapGestureRecognizer(target: self, action: #selector(handlePlusTapped))
        label.addGestureRecognizer(gesture)
        return label
    }()
    
    lazy var amountTextField: UITextField = {
        let textField = UITextField()
        textField.text = "1"
        textField.textColor = Colors.authenticateColor
        textField.textAlignment = .center
        textField.keyboardType = .numberPad
        textField.layer.cornerRadius = 5.heightRatio
        textField.layer.borderWidth = 0.5
        textField.layer.borderColor = Colors.authenticateColor.cgColor
        textField.addTarget(self, action: #selector(textFieldBeginEdit), for: .editingDidBegin)
        textField.addTarget(self, action: #selector(textFieldEndEdit), for: .editingDidEnd)
        textField.addTarget(self, action: #selector(textFieldEditingChangedValue), for: .editingChanged)
        return textField
    }()
    
    lazy var buttonDelete: UIButton = {
        let button = UIButton()
        button.imageView?.contentMode = .scaleAspectFit
        button.setImage(UIImage().getImage(with: "ic_close", and: Bundle(for: CartCell.self))!, for: .normal)
        button.addTarget(self, action: #selector(tappedDelete), for: .touchUpInside)
        return button
    }()
    
    private var counterAmount = 1 {
        didSet {
            amountTextField.text = "\(counterAmount)"
        }
    }
    
    var didPlus: ((Int?)->())?
    var didMinus: ((Int?)->())?
    var didDelete: (()->())?
    
    var textFieldDidBeginEdit: (()->())?
    var textFieldDidEndEdit: (()->())?
    var textFieldEditingChanged: (()->())?
    
    private var cart: CartData?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.setupUI()
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.awakeFromNib()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.awakeFromNib()
    }
    
    func setupUI() {
        let stackAmount = UIStackView(arrangedSubviews: [labelMinus, amountTextField, labelPlus])
        stackAmount.axis = .horizontal
        stackAmount.alignment = .center
        stackAmount.distribution = .equalCentering
        stackAmount.spacing = 3
        
        let stackTitle = UIStackView(arrangedSubviews: [labelTitle, stackAmount])
        stackTitle.axis = .vertical
        stackTitle.alignment = .fill
        stackTitle.distribution = .fill
        
        let contentStackView = UIStackView(arrangedSubviews: [productImageView, stackTitle,  labelPrice])
        contentStackView.axis = .horizontal
        contentStackView.alignment = .top
        contentStackView.distribution = .equalSpacing
        self.contentView.addSubview(contentStackView)
        
        contentStackView.snp.makeConstraints { make in
            make.top.trailing.equalToSuperview().inset(30.heightRatio)
            make.bottom.leading.equalToSuperview().inset(10.widthRatio)
        }
        
        labelPrice.setConstraintWidth(constant: 85.widthRatio)
        labelMinus.setConstraintWidthAndHeight(widthConstant: 26.heightRatio, heightConstant: 26.heightRatio)
        labelPlus.setConstraintWidthAndHeight(widthConstant: 26.heightRatio, heightConstant: 26.heightRatio)
        productImageView.setConstraintWidthAndHeight(widthConstant: 75.widthRatio, heightConstant: 75.widthRatio)
        amountTextField.setConstraintWidthAndHeight(widthConstant: 50.heightRatio, heightConstant: 30.heightRatio)
        
        stackTitle.setConstraintWidthAndHeight(widthConstant: 160.widthRatio, heightConstant: 75.widthRatio)
        stackAmount.snp.makeConstraints { make in
            make.width.equalTo(160.widthRatio)
        }
        
        self.contentView.addSubview(buttonDelete)
        buttonDelete.snp.makeConstraints { make in
            make.width.height.equalTo(25.heightRatio)
            make.top.trailing.equalToSuperview().inset(5.heightRatio)
        }
    }
    
    func bindData(with cart: CartData) {
        self.cart = cart
        labelTitle.text = cart.Name
        amountTextField.text = "\(cart.Quantity ?? 0)"
        labelPrice.text = cart.totalPrice()
        counterAmount = (cart.Quantity ?? 0)
        if let urlImage = cart.Thumbnail {
            productImageView.loadImage(urlString: urlImage, UIImage().getImage(with: "img_empty.png", and: Bundle(for: CartCell.self))!)
        } else {
            productImageView.image = UIImage().getImage(with: "img_empty.png", and: Bundle(for: CartCell.self))!
        }
    }
    // MARK: - Action
    
    @objc func textFieldBeginEdit() {
        textFieldDidBeginEdit?()
    }
    
    @objc func textFieldEndEdit() {
        textFieldDidEndEdit?()
        let amountString = amountTextField.text ?? "0"
        let amount = Int(amountString) ?? 0
        counterAmount = amount
    }
    
    @objc func textFieldEditingChangedValue() {
        let amountString = amountTextField.text ?? "0"
        let amount = Int(amountString) ?? 0
        if amount > 100 {
            amountTextField.text = "100"
            counterAmount = 100
            return
        }
    }
    
    @objc private func handleMinusTapped() {
        if counterAmount == 1 {
            return
        }
        
        counterAmount -= 1
        labelPrice.text = cart?.totalPrice(with: counterAmount)
        didMinus?(counterAmount)
    }
    
    @objc private func handlePlusTapped() {
        if counterAmount == 100 {
            return
        }
        
        counterAmount += 1
        labelPrice.text = cart?.totalPrice(with: counterAmount)
        didPlus?(counterAmount)
    }
    
    @objc private func tappedDelete() {
        didDelete?()
    }
}
