//
//  CartViewController.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 18/07/2022.
//

import UIKit

class CartViewController: BackNavigationVC {

    // MARK: - UI
    lazy var backgroundImage: UIImageView = {
        let imageView = UIImageView(image: UIImage().getImage(with: "img_empty", and: Bundle(for: CartViewController.self)))
        imageView.contentMode = .scaleAspectFit
        imageView.isHidden = true
        return imageView
    }()
    
    lazy var contentView: UIView = {
        let view = UIView()
        view.backgroundColor = Colors.colorSilverGround
        return view
    }()
    
    lazy var tableView: UITableView = {
        let tableView = UITableView()
        tableView.backgroundColor = .clear
        return tableView
    }()
    
    lazy var bottomView: UIView = {
        let view = UIView()
        view.backgroundColor = Colors.customGaryColor
        return view
    }()
    
    lazy var labelTotalMoney: UILabel = {
        let label = UILabel()
        label.textAlignment = .right
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        return label
    }()
    
    lazy var orderButton: CommonButton = {
        let button = CommonButton()
        button.setup(title: "Đặt hàng", 10)
        button.didTap = { [weak self] in
            guard let self = self else { return }
            self.didTappedOrderButton()
        }
        return button
    }()
    
    // MARK: - Properties
    private var cartProvider: DataProvider<CartData> = DataProvider(data: [])
    private var cartDataSource: TableViewDataSource<CartCell, CartData>!
    
    // MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
        configTableView()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        cartProvider.data = CartManager.shared.getDataCart()
        labelTotalMoney.text = CartManager.shared.totalMoneyAllProductTypeString()
        tableView.reloadData()
    }
    
    // MARK: - Set up
    private func setupUI() {
        self.view.addSubview(contentView)
        contentView.snp.makeConstraints { make in
            make.top.equalTo(headerView.snp.bottom)
            make.bottom.leading.trailing.equalToSuperview()
        }
        
        contentView.addSubviews(backgroundImage, tableView)
        tableView.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview()
        }
        
        backgroundImage.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview().offset(-50.heightRatio)
            make.width.height.equalTo(200.heightRatio)
        }
        
        setupTotalMoneyView()
        if CartManager.shared.getDataCart().count == 0 {
            backgroundImage.isHidden = false
            tableView.isHidden = true
            bottomView.isHidden = true
            orderButton.isHidden = true
        }
    }
    
    private func setupTotalMoneyView() {
        contentView.addSubviews(bottomView, orderButton)
        
        let labelTitle = UILabel()
        labelTitle.text = "Tổng số tiền"
        labelTitle.textColor = Colors.authenticateColor
        labelTitle.font = UIFont.systemFont(ofSize: 15, weight: .bold)
        
        let labelSubTitle = UILabel()
        labelSubTitle.text = "(Bao gồm: VAT)"
        labelSubTitle.textColor = Colors.authenticateColor
        labelSubTitle.font = UIFont.systemFont(ofSize: 15, weight: .light)
        
        let stackTitle = UIStackView(arrangedSubviews: [labelTitle, labelSubTitle])
        stackTitle.axis = .vertical
        stackTitle.alignment = .fill
        stackTitle.distribution = .fill
        
        let stackMoney = UIStackView(arrangedSubviews: [stackTitle, labelTotalMoney])
        stackMoney.axis = .horizontal
        stackMoney.alignment = .fill
        stackMoney.distribution = .fill
        
        bottomView.addSubview(stackMoney)
        stackMoney.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview().inset(10.heightRatio)
        }
        
        bottomView.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview()
        }
        
        orderButton.snp.makeConstraints { make in
            make.height.equalTo(35.heightRatio)
            make.top.equalTo(bottomView.snp.bottom).offset(5)
            make.bottom.equalToSuperview().inset(25.heightRatio)
            make.leading.trailing.equalToSuperview().inset(15.widthRatio)
        }
        
        labelTotalMoney.text = CartManager.shared.totalMoneyAllProductTypeString()
    }
    
    private func configTableView() {
        cartProvider.data = CartManager.shared.getDataCart()
        tableView.separatorStyle = .none
        tableView.alwaysBounceVertical = true
        tableView.register(cellClass: CartCell.self)
        
        cartDataSource = TableViewDataSource(dataProvider: cartProvider)
        
        cartDataSource.configureCell = { [weak self] cell, model, index in
            guard let _ = self else { return }
            cell.bindData(with: model)
            cell.didDelete = { [weak self] in
                guard let self = self else { return }
                DispatchQueue.main.async {
                    CartManager.shared.deleteItemCart(with: index.row)
                    self.cartProvider.data = CartManager.shared.getDataCart()
                    self.tableView.reloadData()
                    self.labelTotalMoney.text = CartManager.shared.totalMoneyAllProductTypeString()
                }
            }
            
            cell.didPlus = { [weak self] amount in
                guard let self = self, let amount = amount else { return }
                CartManager.shared.updateQuantity(with: index.row, quantity: amount)
                DispatchQueue.main.async {
                    self.labelTotalMoney.text = CartManager.shared.totalMoneyAllProductTypeString()
                }
            }
            
            cell.didMinus = { [weak self] amount in
                guard let self = self, let amount = amount else { return }
                CartManager.shared.updateQuantity(with: index.row, quantity: amount)
                DispatchQueue.main.async {
                    self.labelTotalMoney.text = CartManager.shared.totalMoneyAllProductTypeString()
                }
            }
        }
        
        tableView.dataSource = cartDataSource
        tableView.reloadData()
    }
    
    // MARK: - Action
    private func didTappedOrderButton() {
        self.navigationController?.pushViewController(OrderViewController(), animated: true)
    }
}
