//
//  CreateAddressViewController.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 19/07/2022.
//

import UIKit

class CreateAddressViewController: BackNavigationVC {
    
    // MARK: - UI
    lazy var contentView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        return view
    }()
    
    lazy var contentStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.alignment = .center
        stackView.distribution = .fill
        stackView.spacing = 15.heightRatio
        stackView.backgroundColor = .white
        return stackView
    }()
    
    lazy var labelContact: UILabel = {
        let label = UILabel()
        label.text = "Liên hệ"
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        return label
    }()
    
    lazy var nameTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Họ và tên"
        textField.textColor = Colors.normalTextColor
        textField.font = UIFont.systemFont(ofSize: 15)
        return textField
    }()
    
    lazy var phoneTextField: UITextField = {
        let textField = UITextField()
        textField.keyboardType = .numberPad
        textField.placeholder = "Số điện thoại"
        textField.textColor = Colors.normalTextColor
        textField.font = UIFont.systemFont(ofSize: 15)
        textField.addTarget(self, action: #selector(textFieldBeginEdit), for: .editingDidBegin)
        textField.addTarget(self, action: #selector(textFieldEditingChanged), for: .editingChanged)
        textField.addTarget(self, action: #selector(textFieldEndEdit), for: .editingDidEnd)
        return textField
    }()
    
    lazy var labelAddress: UILabel = {
        let label = UILabel()
        label.text = "Địa chỉ"
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        return label
    }()
    
    lazy var buttonSelectAddress1: UIButton = {
        let button = UIButton()
        button.layer.masksToBounds = true
        button.layer.cornerRadius = 10
        button.layer.borderWidth = 0.5
        button.layer.borderColor = Colors.mainColor.cgColor
        button.contentHorizontalAlignment = .left
        button.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        button.setTitleColor(Colors.normalTextColor, for: .normal)
        button.setImage(UIImage().getImage(with: "ic_right_arrow_main", and: Bundle(for: CreateAddressViewController.self))!, for: .normal)
        button.setTitle("Tỉnh/Thành phố, Quận/Huyện, Phường/Xã", for: .normal)
        button.titleEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        button.imageEdgeInsets = UIEdgeInsets(top: 0, left: 320.widthRatio, bottom: 0, right: 0)
        button.addTarget(self, action: #selector(didGoToSelectAddress), for: .touchUpInside)
        return button
    }()
    
    lazy var buttonSelectAddress2: UIButton = {
        let button = UIButton()
        button.layer.masksToBounds = true
        button.layer.cornerRadius = 10
        button.layer.borderWidth = 0.5
        button.layer.borderColor = Colors.mainColor.cgColor
        button.contentHorizontalAlignment = .left
        button.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        button.setTitleColor(Colors.normalTextColor, for: .normal)
        button.setTitle("Tên đường, Toà nhà, Số nhà", for: .normal)
        button.titleEdgeInsets = UIEdgeInsets(top: 0, left: 10.widthRatio, bottom: 0, right: 0)
        button.addTarget(self, action: #selector(didGoToSelectAddress), for: .touchUpInside)
        return button
    }()
    
    lazy var labelSetting: UILabel = {
        let label = UILabel()
        label.text = "Cài đặt"
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        return label
    }()
    
    lazy var typeAddressView: TypeAddressView = {
        let view = TypeAddressView()
        view.didTapHome = { [weak self] in
            guard let self = self else { return }
        }
        view.didTapOffice = { [weak self] in
            guard let self = self else { return }
        }
        return view
    }()
    
    lazy var toggleCurrentAddress: UISwitch = {
        let switchView = UISwitch()
        switchView.onTintColor = Colors.mainColor
        switchView.addTarget(self, action: #selector(switchValueDidChange(_:)), for: .valueChanged)
        return switchView
    }()
    
    lazy var buttonComplete: UIButton = {
        let button = UIButton()
        button.setTitle("Hoàn thành", for: .normal)
        button.setTitleColor(Colors.mainColor, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        button.layer.masksToBounds = true
        button.layer.cornerRadius = 10
        button.layer.borderWidth = 0.5
        button.layer.borderColor = Colors.mainColor.cgColor
        button.addTarget(self, action: #selector(didTapCompleteButton), for: .touchUpInside)
        return button
    }()
    
    // MARK: - Properties
    private var presenter: CreateAddressPresenter?
    private var addressParam: AddressParam?
    private var addressData: AddressData?
    
    // MARK: - Flags
    private var isEditAddress = false
    
    // MARK: - Life Cycle
    convenience init(isEditAddress: Bool, addressData: AddressData?) {
        self.init()
        self.isEditAddress = isEditAddress
        self.addressData = addressData
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter = CreateAddressPresenter(self)
        setupUI()
        bindDataAddress()
        handleAddressType()
    }
    
    deinit {
        presenter = nil
    }
    
    // MARK: - Set up
    private func setupUI() {
        self.view.addSubview(contentView)
        contentView.addSubview(contentStackView)
        
        contentView.snp.makeConstraints { make in
            make.top.equalTo(headerView.frame.height)
            make.bottom.leading.trailing.equalToSuperview()
        }
        
        contentStackView.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview()
            make.top.equalToSuperview().inset(20.heightRatio)
        }
        
        setupContactView()
        setupAddressView()
        setupSettingView()
        contentStackView.addArrangedSubview(buttonComplete)
        buttonComplete.setConstraintWidthAndHeight(widthConstant: 345.widthRatio, heightConstant: 35.heightRatio)
    }
    
    private func setupContactView() {
        let stackName = UIStackView(arrangedSubviews: [nameTextField, phoneTextField])
        stackName.axis = .vertical
        stackName.alignment = .fill
        stackName.distribution = .equalCentering
        stackName.layer.borderWidth = 0.5
        stackName.layer.borderColor = Colors.mainColor.cgColor
        stackName.layer.cornerRadius = 10
        
        contentStackView.addArrangedSubview(labelContact)
        contentStackView.addArrangedSubview(stackName)
        
        labelContact.setConstraintWidth(constant: 315.widthRatio)
        stackName.setConstraintWidthAndHeight(widthConstant: 345.widthRatio, heightConstant: 70.heightRatio)
        
        stackName.layoutMargins = UIEdgeInsets(top: 10.heightRatio, left: 15.widthRatio, bottom: 10.heightRatio, right: 0)
        stackName.isLayoutMarginsRelativeArrangement = true
        
    }
    
    private func setupAddressView() {
        let stackAddress = UIStackView(arrangedSubviews: [buttonSelectAddress1, buttonSelectAddress2])
        stackAddress.axis = .vertical
        stackAddress.alignment = .fill
        stackAddress.distribution = .fill
        stackAddress.spacing = 10.heightRatio
        contentStackView.addArrangedSubview(labelAddress)
        contentStackView.addArrangedSubview(stackAddress)
        
        labelAddress.setConstraintWidth(constant: 315.widthRatio)
        stackAddress.setConstraintWidth(constant: 345.widthRatio)
        buttonSelectAddress1.setConstraintWidthAndHeight(widthConstant: 345.widthRatio, heightConstant: 35.heightRatio)
        buttonSelectAddress2.setConstraintWidthAndHeight(widthConstant: 345.widthRatio, heightConstant: 35.heightRatio)
    }
    
    private func setupSettingView() {
        let labelTitleType = UILabel()
        labelTitleType.text = "Loại địa chỉ"
        labelTitleType.textColor = Colors.normalTextColor
        labelTitleType.font = UIFont.systemFont(ofSize: 14)
        
        let labelTitleCurrentAddress = UILabel()
        labelTitleCurrentAddress.text = "Đặt làm địa chỉ mặc định"
        labelTitleCurrentAddress.textColor = Colors.normalTextColor
        labelTitleCurrentAddress.font = UIFont.systemFont(ofSize: 14)
        
        let stackType = UIStackView(arrangedSubviews: [labelTitleType, typeAddressView])
        stackType.axis = .horizontal
        stackType.alignment = .fill
        stackType.distribution = .fill
        
        let stackCurrentAddress = UIStackView(arrangedSubviews: [labelTitleCurrentAddress, toggleCurrentAddress])
        stackCurrentAddress.axis = .horizontal
        stackCurrentAddress.alignment = .fill
        stackCurrentAddress.distribution = .fill
        
        let stackSetting = UIStackView(arrangedSubviews: [stackType, stackCurrentAddress])
        stackSetting.axis = .vertical
        stackSetting.alignment = .fill
        stackSetting.distribution = .fill
        stackSetting.layer.borderWidth = 0.5
        stackSetting.layer.borderColor = Colors.mainColor.cgColor
        stackSetting.layer.cornerRadius = 10
        stackSetting.spacing = 15.heightRatio
        stackSetting.layoutMargins = UIEdgeInsets(top: 10.heightRatio, left: 10.widthRatio, bottom: 5.heightRatio, right: 10.widthRatio)
        stackSetting.isLayoutMarginsRelativeArrangement = true
        
        contentStackView.addArrangedSubview(labelSetting)
        contentStackView.addArrangedSubview(stackSetting)
        
        labelSetting.setConstraintWidth(constant: 315.widthRatio)
        stackSetting.setConstraintWidth(constant: 345.widthRatio)
        toggleCurrentAddress.transform = CGAffineTransform(scaleX: 0.65, y: 0.65)
    }
    
    private func bindDataAddress() {
        // Home Address = 0, Office Address = 1
        addressParam = AddressParam(UserID: UserService.shared.getDataUser().ID, CustomerName: nil, Phone: nil, Province: nil, District: nil, Ward: nil, Address: nil, AddressType: 1, IsDefault: 0, Lat: 1.0, Long: 1.0)
        
        if isEditAddress {
            addressParam?.CustomerName = addressData?.CustomerName
            addressParam?.Phone = addressData?.Phone
            addressParam?.Province = addressData?.Province
            addressParam?.District = addressData?.District
            addressParam?.Ward = addressData?.Ward
            addressParam?.Address = addressData?.Address
            addressParam?.AddressType = addressData?.AddressType
            addressParam?.Lat = addressData?.Lat
            addressParam?.Long = addressData?.Long
            
            let isDefault = addressData?.IsDefault ?? false
            addressParam?.IsDefault = isDefault ? 1 : 0
            toggleCurrentAddress.setOn(isDefault, animated: true)
            
            nameTextField.text = addressData?.CustomerName
            phoneTextField.text = addressData?.Phone
            
            let addressString = "\(addressData?.WardName ?? ""), \(addressData?.DistrictName ?? ""), \((addressData?.ProvinceName ?? ""))"
            self.buttonSelectAddress1.setTitle(addressString, for: .normal)
            self.buttonSelectAddress2.setTitle(addressData?.Address ?? "", for: .normal)
            self.buttonComplete.setTitle("Xoá địa chỉ", for: .normal)
            
            
            nameTextField.isUserInteractionEnabled = false
            nameTextField.isUserInteractionEnabled = false
            phoneTextField.isUserInteractionEnabled = false
            typeAddressView.isUserInteractionEnabled = false
            buttonSelectAddress1.isUserInteractionEnabled = false
            buttonSelectAddress2.isUserInteractionEnabled = false
        }
    }
    // MARK: - Action
    
    private func handleAddressType() {
        typeAddressView.didTapHome = { [weak self] in
            guard let self = self else { return }
            self.addressParam?.AddressType = 0
        }
        typeAddressView.didTapOffice = { [weak self] in
            guard let self = self else { return }
            self.addressParam?.AddressType = 1
        }
    }
    
    @objc private func switchValueDidChange(_ sender: UISwitch) {
        if toggleCurrentAddress.isOn == true {
            addressParam?.IsDefault = 1
        } else {
            addressParam?.IsDefault = 0
        }
    }
    
    @objc private func didTapCompleteButton() {
        if isEditAddress {
            CommonPopup.showAlertWith(titleOk: "Đồng ý", titleCancel: "Trở lại", "Bạn có muốn xoá địa chỉ?") {
                self.presenter?.requestDeleteAddress(with: self.addressData?.ID ?? -1)
            } cancelCompletion: { }
            return
        }
        
        guard let name = nameTextField.text, let phone = phoneTextField.text else {
            return
        }
        
        if name == "" {
            CommonPopup.showAlertOnlyOk("Vui lòng nhập họ tên", title: "", okCompletion: nil)
            return
        }
        
        if phone.isEmpty || phone == "" || phone.count == 0 {
            CommonPopup.showAlertOnlyOk("Vui lòng nhập số điện thoại", title: "", okCompletion: nil)
            return
        }
        
        if !phone.checkPhoneNumber() {
            CommonPopup.showAlertOnlyOk("Vui lòng nhập đúng định dạng số điện thoại", title: "", okCompletion: nil)
            return
        }
        
        if !phone.checkPhoneNumber() {
            CommonPopup.showAlertOnlyOk("Số điện thoại không hợp lệ", title: "", okCompletion: nil)
            return
        }
        
        guard let _ = addressParam?.Province,
                let _ = addressParam?.District,
                let _ = addressParam?.Ward,
                let _ = addressParam?.Address else {
            CommonPopup.showAlertOnlyOk("Vui lòng chọn thông tin địa chỉ", title: "", okCompletion: nil)
            return
        }
        
        addressParam?.CustomerName = name
        addressParam?.Phone = phone
        
        guard let addressParam = addressParam else {
            return
        }

        self.showLoading()
        presenter?.requestCreateAddress(with: addressParam)
    }
    
    @objc private func didGoToSelectAddress() {
        let vc = SelectAddressViewController()
        vc.didDone = { [weak self] wardDistrictData, address in
            guard let self = self else { return }
            self.addressParam?.Province = wardDistrictData?.ProvinceID
            self.addressParam?.District = wardDistrictData?.DistrictID
            self.addressParam?.Ward = wardDistrictData?.ID
            self.addressParam?.Address = address
            DispatchQueue.main.async {
                let addressString = "\(wardDistrictData?.WardName ?? ""), \(wardDistrictData?.DistrictName ?? ""), \(CommonService.shared.getProvinceData(with: wardDistrictData?.ProvinceID ?? -1)?.Name ?? "")"
                self.buttonSelectAddress1.setTitle(addressString, for: .normal)
                self.buttonSelectAddress2.setTitle(address, for: .normal)
            }
        }
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc func textFieldBeginEdit() {
        
    }
    
    @objc func textFieldEditingChanged() {
        if let numb = self.phoneTextField.text {
             if numb.count > 10 {
                  self.phoneTextField.text = String(numb.dropLast())
             }
        }
    }
    
    @objc func textFieldEndEdit() {
        
    }
    
}

extension CreateAddressViewController: CreateAddressView {
    func onCheckCreateAddressSuccess() {
        self.hideLoading()
        CommonPopup.showAlertOnlyOk("Tạo địa chỉ thành công", title: nil) {
            DispatchQueue.main.async {
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
    
    func onCheckCreateAddressFailed() {
        self.hideLoading()
        CommonPopup.showAlertOnlyOk("Tạo địa chỉ thất bại", title: nil) {
            
        }
    }
    
    func onCheckSetIsDefaultSuccess() {
        CommonPopup.showAlertOnlyOk("Cập nhật địa chỉ thành công", title: nil) {
            
        }
    }
    
    func onDeleteAddressSuccess() {
        CommonService.shared.updateAddressAfterDelete(with: self.addressData)
        CommonPopup.showAlertOnlyOk("Xoá địa chỉ thành công", title: nil) {
            self.navigationController?.popViewController(animated: true)
        }
    }
}
