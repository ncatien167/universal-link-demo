//
//  SelectAddressPresenter.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 20/07/2022.
//

import Foundation

protocol SelectAddressView {
    func onCheckRequestDistrict(with wardDistrictDatas: [WardDistrictData])
    func onCheckRequestWard(with wardDistrictDatas: [WardDistrictData])
}

protocol SelectAddressViewPresenter {
    init(_ view: SelectAddressView)

    func requestDistrict(with provinceID: Int)
    func requestWard(with districtID: Int)
}

class SelectAddressPresenter: SelectAddressViewPresenter {
    
    var view: SelectAddressView?
    
    required init(_ view: SelectAddressView) {
        self.view = view
    }
    
    func requestDistrict(with provinceID: Int) {
        AddressService.getDistrictData(with: provinceID) { datas in
            self.view?.onCheckRequestDistrict(with: datas ?? [])
        }
    }
    
    func requestWard(with districtID: Int) {
        AddressService.getWardData(with: districtID) { datas in
            self.view?.onCheckRequestWard(with: datas ?? [])
        }
    }
}
 
