//
//  AddressOrderCell.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 21/07/2022.
//

import UIKit

class AddressOrderCell: UITableViewCell {
    
    // MARK: - UI
    
    lazy var viewContainer: UIView = {
        let view = UIView()
        view.layer.cornerRadius = 10
        view.layer.borderWidth = 0.5
        view.layer.borderColor = Colors.mainColor.cgColor
        return view
    }()
    
    lazy var contentStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.alignment = .fill
        stackView.distribution = .fill
        stackView.spacing = 10.heightRatio
        return stackView
    }()
    
    lazy var labelName: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        label.textColor = Colors.mainColor
        return label
    }()
    
    lazy var labelPhone: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        label.textColor = Colors.mainColor
        return label
    }()
    
    lazy var labelTypeAddress: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.textColor = Colors.white
        label.backgroundColor = Colors.mainColor
        label.font = UIFont.systemFont(ofSize: 15)
        label.layer.cornerRadius = 10.widthRatio
        label.layer.masksToBounds = true
        return label
    }()
    
    lazy var labelAddress: UILabel = {
        let label = UILabel()
        label.textAlignment = .left
        label.textColor = Colors.normalTextColor
        label.font = UIFont.systemFont(ofSize: 15, weight: .light)
        return label
    }()

    lazy var labelAddress2: UILabel = {
        let label = UILabel()
        label.textColor = Colors.normalTextColor
        label.font = UIFont.systemFont(ofSize: 13, weight: .light)
        return label
    }()
    
    lazy var labelSetCurrentAddress: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 13)
        label.textColor = Colors.authenticateColor
        return label
    }()
    
    lazy var iconCheck: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.setupUI()
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.awakeFromNib()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.awakeFromNib()
    }
    
    func setupUI() {
        self.contentView.addSubview(viewContainer)
        viewContainer.addSubviews(contentStackView, iconCheck)
        
        viewContainer.snp.makeConstraints { make in
            make.top.bottom.equalToSuperview().inset(10.heightRatio)
            make.leading.trailing.equalToSuperview().inset(15.heightRatio)
        }
        
        iconCheck.snp.makeConstraints { make in
            make.top.leading.equalToSuperview().inset(10.heightRatio)
            make.width.height.equalTo(25.heightRatio)
        }
        
        contentStackView.snp.makeConstraints { make in
            make.leading.equalTo(iconCheck.snp.trailing).inset(-10.widthRatio)
            make.top.bottom.trailing.equalToSuperview().inset(10.heightRatio)
        }
        
        let stackName = UIStackView(arrangedSubviews: [labelName, labelPhone])
        stackName.axis = .horizontal
        stackName.alignment = .leading
        stackName.distribution = .fillProportionally
        stackName.spacing = 20
        
        let stackAddress = UIStackView(arrangedSubviews: [labelTypeAddress, labelAddress])
        stackAddress.spacing = 20
        stackAddress.axis = .horizontal
        stackAddress.alignment = .leading
        stackAddress.distribution = .fillProportionally

        contentStackView.addArrangedSubview(stackName)
        contentStackView.addArrangedSubview(stackAddress)
        contentStackView.addArrangedSubview(labelAddress2)
        contentStackView.addArrangedSubview(labelSetCurrentAddress)
        labelAddress.setConstraintHeight(constant: 25.heightRatio)
        labelTypeAddress.setConstraintWidthAndHeight(widthConstant: 100.widthRatio, heightConstant: 25.heightRatio)
    }
    
    func bindData(with address: AddressData) {
        iconCheck.image = (address.IsDefault ?? false) ? UIImage().getImage(with: "ic_selected", and: Bundle(for: AddressOrderCell.self))! : UIImage().getImage(with: "ic_non_select", and: Bundle(for: AddressOrderCell.self))!
        labelName.text = address.CustomerName
        labelPhone.text = address.Phone
        labelAddress.text = address.Address
        labelAddress2.text = "\(address.WardName ?? ""), \(address.DistrictName ?? ""), \((address.ProvinceName ?? ""))"
        
        if let addressType = address.AddressType {
            if addressType == 0 {
                labelTypeAddress.text = "NHÀ RIÊNG"
            } else if addressType == 1 {
                labelTypeAddress.text = "VĂN PHÒNG"
            }
        }
        
        if let IsDefault = address.IsDefault {
            if IsDefault {
                labelSetCurrentAddress.isHidden = true
            } else {
                labelSetCurrentAddress.isHidden = false
                labelSetCurrentAddress.text = "Địa chỉ mặc định"
            }
        }
    }
}
