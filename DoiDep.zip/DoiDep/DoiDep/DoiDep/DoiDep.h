//
//  DoiDep.h
//  DoiDep
//
//  Created by PTVH Mac Mini 2 on 27/07/2022.
//

#import <Foundation/Foundation.h>

//! Project version number for DoiDep.
FOUNDATION_EXPORT double DoiDepVersionNumber;

//! Project version string for DoiDep.
FOUNDATION_EXPORT const unsigned char DoiDepVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DoiDep/PublicHeader.h>
