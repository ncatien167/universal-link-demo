//
//  DoiDep.swift
//  DoiDep
//
//  Created by PTVH Mac Mini 2 on 27/07/2022.
//

import Foundation
import UIKit

public protocol DoiDepDelegatePresenter: AnyObject {
    
    func onGotoPayment(with data: [String : Any])
    func onLogin(with data: [String : Any])
    func onLogOut()
}

public class DoiDep: NSObject {
    
    public static let shared = DoiDep()
    public static var reviewViewController: UIViewController?
    weak public var delegate: DoiDepDelegatePresenter?
    
    @objc public var buildType: String = "PROD" {
        didSet {
            if buildType == "PROD" {
                Config.sharedInstance.setBuildType(buildType: .PROD)
            } else {
                Config.sharedInstance.setBuildType(buildType: .NAB)
            }
        }
    }
    
    var didGoToPayment: ((OrderResponse?)->())?
    var didLogin: (()->())?
    var didLogOut: (()->())?
    
    public static func doiDepViewController(with reviewViewController: UIViewController, userData: [String:Any]?) -> UIViewController {
        DoiDep.reviewViewController = reviewViewController
        DoiDep.shared.didGoToPayment = { data in
            DoiDep.shared.delegate?.onGotoPayment(with: data?.convertObjectToDictionary ?? [:])
        }
        
        DoiDep.shared.didLogin = {
            DoiDep.shared.delegate?.onLogin(with: UserService.shared.getDataUser().convertObjectToDictionary)
        }
        
        DoiDep.shared.didLogOut = {
            DoiDep.shared.delegate?.onLogOut()
        }
        
        if let userData = userData {
            do {
                let data = try JSONDecoder().decode(UserData.self, from: try JSONSerialization.data(withJSONObject: userData, options: .prettyPrinted))
                UserService.shared.setDataUser(with: data)
            } catch {
                print(error)
            }
        }
        
        if UserService.shared.getDataUser().getToken() == "" {
            return LoginViewController()
        } else {
            return TabBarViewController()
        }
    }
    
    public static func goToMyOrder() -> UIViewController {
        return MyOrderViewController()
    }
    
    public static func clearUserDoiDep() {
        UserService.shared.removeDataUserService()
    }
}

public enum BuildType {
    case NAB
    case PROD
}

class Config {
    
    static let sharedInstance = Config()
    private init() {}
    public static var buildType = BuildType.NAB
    
    func getBuildType() -> BuildType{
        return Config.buildType
    }
    
    func setBuildType(buildType: BuildType) {
        Config.buildType = buildType
    }
    
}
