//
//  InputView.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 15/07/2022.
//

import UIKit

class InputView: UIView, UITextFieldDelegate {
    
    lazy var textField: TextField = {
        let textField = TextField()
        textField.delegate = self
        textField.font = UIFont.systemFont(ofSize: 15)
        textField.addTarget(self, action: #selector(textFieldBeginEdit), for: .editingDidBegin)
        textField.addTarget(self, action: #selector(textFieldEditingChanged), for: .editingChanged)
        textField.addTarget(self, action: #selector(textFieldEndEdit), for: .editingDidEnd)
        textField.padding = UIEdgeInsets(top: 0, left: 0, bottom: -10.heightRatio, right: 0)
        return textField
    }()
    
    lazy var bottomLineView: UIView = {
        let view = UIView()
        view.backgroundColor = .lightGray
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    var setPlaceholder: String = "" {
        didSet {
            textField.attributedPlaceholder = NSAttributedString(
                string: setPlaceholder,
                attributes: [NSAttributedString.Key.foregroundColor: Colors.mainColor]
            )
        }
    }
    var didTapRightView: (()->())?
    var didBeginEditText: (()->())?
    var didEditingChanged: (()->())?
    var didReturnText: (()->())?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initLayout()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initLayout()
    }
    
    private func initLayout() {
        let stackView = UIStackView(arrangedSubviews: [textField, bottomLineView])
        stackView.spacing = 1
        stackView.axis = .vertical
        stackView.alignment = .fill
        stackView.distribution = .fill
        
        self.addSubview(stackView)
        stackView.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview()
        }
        
        bottomLineView.setConstraintHeight(constant: 0.5)
    }
    
    // MARK: - Setup
    
    func setup(placeholder: String) {
        self.textField.placeholder = placeholder
    }
    
    // MARK: - ACTION
    
    @objc func textFieldBeginEdit() {
        didBeginEditText?()
    }
    
    @objc func textFieldEditingChanged() {
        didEditingChanged?()
    }
    
    @objc func textFieldEndEdit() {
        
    }
    
    @objc func didTapRightViewAction() {
        didTapRightView?()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        didReturnText?()
        return true
    }
}
