//
//  OrderPresenter.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 21/07/2022.
//

import Foundation

protocol OrderView {
    func onCheckCreateOrderFail(with message: String?)
    func onCheckCreateOrderSuccess(with data: OrderResponse)
    func onCheckSetIsDefaultSuccess()
}

protocol OrderViewPresenter {
    init(_ view: OrderView)
    
    func requestSetDefaultAddress(with addressID: Int)
    func requestOrder(with voucher: Voucher?, paymentType: PaymentType?, selectedType: Int, storeData: StoreData?)
}

class OrderPresenter: OrderViewPresenter {
    var view: OrderView?
    
    required init(_ view: OrderView) {
        self.view = view
    }
    
    func requestSetDefaultAddress(with addressID: Int) {
        AddressService.requestSetDefaultAddress(with: addressID) { status in
            guard let status = status else { return }
            if status {
                self.view?.onCheckSetIsDefaultSuccess()
            }
        }
    }
    
    func requestOrder(with voucher: Voucher?, paymentType: PaymentType?, selectedType: Int, storeData: StoreData?) {
        let userData = UserService.shared.getDataUser()
        guard let defaultAddress = CommonService.shared.defaultAddress() else { return }
        let Province = defaultAddress.Province
        let District = defaultAddress.District
        let Ward = defaultAddress.Ward
        let ShipName = selectedType == 1 ? defaultAddress.CustomerName : userData.FullName
        let ShipAddress = selectedType == 1 ? defaultAddress.Address : "StoreAddress"
        let Phone = selectedType == 1 ? defaultAddress.Phone : userData.Phone
        let StoreID = selectedType == 1 ? nil : storeData?.ID
        
        let cartDatas = CartManager.shared.getDataCart()
        var OrderDetails: [OrderDetail] = []
        for cartData in cartDatas {
            let Order = OrderDetail(ProductID: cartData.ProductID, GroupID: cartData.GroupID, SKU: cartData.SKU, Quantity: cartData.Quantity, Note: cartData.Note)
            OrderDetails.append(Order)
        }
        
        let userID = UserService.shared.getDataUser().ID
        let paymentMethod = paymentType?.paymentMethod
        let voucherCode = voucher?.Code
        let isVAT = false
        let VATCompanyName = userData.VatInfor?.CompanyName
        let VATTaxCode = userData.VatInfor?.TaxCode
        let VATEmail = userData.VatInfor?.Email
        let VATAddress = userData.VatInfor?.Address
        
        let orderData = OrderData(UserID: userID, Province: Province, District: District, Ward: Ward, ShipName: ShipName, ShipAddress: ShipAddress, Phone: Phone, StoreID: StoreID, PaymentMethod: paymentMethod, VoucherCode: voucherCode, OrderDetails: OrderDetails, IsVAT: isVAT, VATCompanyName: VATCompanyName, VATTaxCode: VATTaxCode, VATEmail: VATEmail, VATAddress: VATAddress, Message: nil)
        
        OrderService.requestOrder(with: orderData) { status, data in
            guard let status = status, let data = data else {
                self.view?.onCheckCreateOrderFail(with: data?.Message)
                return
            }
            
            if !status {
                self.view?.onCheckCreateOrderFail(with: data.Message)
                return
            }
            
            self.view?.onCheckCreateOrderSuccess(with: data)
            return
        }
    }
}
