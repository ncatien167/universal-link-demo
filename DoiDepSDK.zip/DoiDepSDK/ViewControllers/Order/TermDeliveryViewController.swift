//
//  TermDeliveryViewController.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 25/07/2022.
//

import UIKit

class TermDeliveryViewController: BackNavigationVC {

    lazy var labelDes: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textColor = Colors.normalTextColor
        label.font = UIFont.systemFont(ofSize: 15, weight: .bold)
        return label
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
    }

    private func setupUI() {
        headerView.title = "Chính sách vận chuyển"
        let contentView = UIView()
        contentView.backgroundColor = .white
        self.view.addSubview(contentView)
        contentView.addSubview(labelDes)
        contentView.snp.makeConstraints { make in
            make.top.equalTo(headerView.snp.bottom)
            make.bottom.leading.trailing.equalToSuperview()
        }
        
        labelDes.snp.makeConstraints { make in
            make.top.leading.trailing.equalToSuperview().inset(15.widthRatio)
        }
        
        labelDes.text = "Chính sách vận chuyển hàng hóa của Đôi Dép:\n- Lâm Đồng, Nha Trang, Bạc Liêu, TP.HCM: 30.000đ\n* Freeship cho đơn hàng từ 500.000đ tại TP.HCM\n- Các tỉnh thành khác: 50.000đ\n\n* Phí vận chuyển trên áp dụng cho đơn hàng không quá 3kg. Nếu trọng lượng đơn quá 3kg thì cước phí vận chuyển sẽ được thông báo và xác nhận lại với khách hàng."
    }
}
