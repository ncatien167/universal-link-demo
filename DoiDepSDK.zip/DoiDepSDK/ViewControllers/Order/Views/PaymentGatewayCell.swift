//
//  PaymentGatewayCell.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 25/07/2022.
//

import UIKit

struct PaymentTypeData {
    var title: String?
    var icon: UIImage?
    var paymentMethod: Int?
    var isSelected: Bool?
    var type: PaymentType?
}

class PaymentGatewayCell: UITableViewCell {
    lazy var iconSelect: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    lazy var labelTitle: UILabel = {
        let label = UILabel()
        label.textAlignment = .left
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 15, weight: .light)
        return label
    }()
    
    lazy var iconType: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.setupUI()
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.awakeFromNib()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.awakeFromNib()
    }
    
    private func setupUI() {
        let stackView = UIStackView(arrangedSubviews: [iconSelect, labelTitle])
        stackView.axis = .horizontal
        stackView.alignment = .center
        stackView.distribution = .fill
        
        let contentStackView = UIStackView(arrangedSubviews: [stackView, iconType])
        contentStackView.axis = .horizontal
        contentStackView.alignment = .center
        contentStackView.distribution = .fill
        
        self.contentView.addSubview(contentStackView)
        contentStackView.snp.makeConstraints { make in
            make.top.bottom.equalToSuperview()
            make.leading.trailing.equalToSuperview().inset(15.widthRatio)
        }
        
        iconType.setConstraintWidthAndHeight(widthConstant: 30.heightRatio, heightConstant: 30.heightRatio)
        iconSelect.setConstraintWidthAndHeight(widthConstant: 25.heightRatio, heightConstant: 25.heightRatio)
    }
    
    func bindData(with data: PaymentTypeData) {
        labelTitle.text = data.title
        iconType.image = data.icon
        iconSelect.image = (data.isSelected ?? false) ? UIImage().getImage(with: "ic_selected", and: Bundle(for: PaymentGatewayCell.self))! : UIImage().getImage(with: "ic_non_select", and: Bundle(for: PaymentGatewayCell.self))!
    }
}

enum PaymentType: Int {
    case gateWayNamA = 0
    case pickup = 1
    case billNamA = 2
    
    var paymentType: PaymentTypeData {
        switch self {
        case .gateWayNamA:
            return Constants.Order.datasType[PaymentType.gateWayNamA.rawValue]
        case .pickup:
            return Constants.Order.datasType[PaymentType.pickup.rawValue]
        case.billNamA:
            return Constants.Order.datasType[PaymentType.billNamA.rawValue]
        }
    }
    
    var paymentMethod: Int {
        switch self {
        case .gateWayNamA:
            return 2
        case .pickup:
            return 1
        case.billNamA:
            return 3
        }
    }
    
    var title: String {
        switch self {
        case .gateWayNamA:
            return "Thanh toán qua Nam A Bank"
        case .pickup:
            return "Nhận theo địa chỉ"
        case .billNamA:
            return "Thanh toán qua Open Banking"
        }
    }
}
