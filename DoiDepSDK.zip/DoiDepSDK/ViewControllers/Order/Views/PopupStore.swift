//
//  PopupStore.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 25/07/2022.
//

import UIKit

class PopupStore: UIViewController {
    private lazy var labelTitle: PaddingLabel = {
        let label = PaddingLabel()
        label.text = "Chọn cửa hàng"
        label.edgeInset = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
        label.layer.cornerRadius = 5
        label.layer.masksToBounds = true
        label.textAlignment = .center
        label.textColor = Colors.white
        label.backgroundColor = Colors.mainColor
        label.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        return label
    }()
    
    private lazy var cancelButton: UIButton = {
        let btn = UIButton()
        btn.setImage(UIImage().getImage(with: "ic_close", and: Bundle(for: PopupStore.self))!, for: .normal)
        btn.addTarget(self, action: #selector(didCancel(_:)), for: .touchUpInside)
        return btn
    }()
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView()
        return tableView
    }()
    
    lazy var contentAlertView: UIView = {
        let view = UIView()
        view.backgroundColor = Colors.white
        view.layer.cornerRadius = 15
        view.layer.masksToBounds = true
        return view
    }()
    
    private lazy var dimmedBackgroundView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = UIColor.black.withAlphaComponent(0.3)
        return view
    }()
    
    // MARK: - Properties
    private var storeProvider: DataProvider<StoreData> = DataProvider(data: [])
    private var storeDataSource: TableViewDataSource<StoreCell, StoreData>!
    private var type: PaymentType? = .gateWayNamA
    
    typealias completionHandler = (StoreData?) -> ()
    private var completion: completionHandler?
    
    internal required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private init(completion: completionHandler? = nil) {
        super.init(nibName: nil, bundle: nil)
        self.completion = completion
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initLayout()
        configTableview()
    }
    
    func initLayout() {
        self.view.addSubview(dimmedBackgroundView)
        self.view.addSubview(contentAlertView)
        self.contentAlertView.addSubviews(cancelButton, labelTitle, tableView)
        
        dimmedBackgroundView.snp.makeConstraints { (make) in
            make.trailing.leading.top.bottom.equalToSuperview()
        }
        
        contentAlertView.snp.makeConstraints { (make) in
            make.height.equalTo(400.heightRatio)
            make.bottom.leading.trailing.equalToSuperview()
        }
        
        cancelButton.snp.makeConstraints { make in
            make.top.leading.equalToSuperview().inset(15.heightRatio)
            make.width.height.equalTo(25.heightRatio)
        }
        
        labelTitle.snp.makeConstraints { make in
            make.height.equalTo(40.heightRatio)
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().inset(10.heightRatio)
        }
        tableView.snp.makeConstraints { make in
            make.top.equalTo(labelTitle.snp.bottom).offset(10.heightRatio)
            make.bottom.leading.trailing.equalToSuperview()
        }
    }
    
    private func configTableview() {
        storeProvider.data = CommonService.shared.getStores()
        tableView.delegate = self
        tableView.rowHeight = UITableView.automaticDimension
        tableView.separatorStyle = .none
        tableView.alwaysBounceVertical = true
        tableView.register(cellClass: StoreCell.self)
        
        storeDataSource = TableViewDataSource(dataProvider: storeProvider)
        
        storeDataSource.configureCell = { [weak self] cell, model, index in
            guard let _ = self else { return }
            cell.bindData(with: model)
        }
        
        tableView.dataSource = storeDataSource
        tableView.reloadData()
    }
    
    // MARK: show alert

    static func showPopup(completion: completionHandler? = nil) {
        let alert = PopupStore(completion: completion)
        DispatchQueue.main.async(execute: {
            guard let viewController = UIViewController.topMostViewController() else { return }
            presentPopover(alert, viewController: viewController)
        })
    }
    
    @objc func didCancel(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    private static func presentPopover(_ alert: UIViewController, viewController: UIViewController) {
        alert.modalPresentationStyle = .overCurrentContext
        alert.modalTransitionStyle = .crossDissolve
        alert.definesPresentationContext = true
        viewController.present(alert, animated: true, completion: nil)
    }
}

extension PopupStore: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let completion = completion else {
            dismiss(animated: true, completion: nil)
            return
        }
        
        completion(storeProvider.data[indexPath.row])
        dismiss(animated: true, completion: nil)
    }
}

class StoreCell: UITableViewCell {
    
    lazy var labelTitle: UILabel = {
        let label = UILabel()
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 15, weight: .bold)
        return label
    }()
    
    lazy var labelAddress: UILabel = {
        let label = UILabel()
        label.textColor = Colors.normalTextColor
        label.font = UIFont.systemFont(ofSize: 13, weight: .light)
        return label
    }()
    
    lazy var labelKilometer: UILabel = {
        let label = UILabel()
        label.textAlignment = .right
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 13, weight: .light)
        return label
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.setupUI()
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.awakeFromNib()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.awakeFromNib()
    }

    private func setupUI() {
        let icon = UIImageView(image: UIImage().getImage(with: "ic_location", and: Bundle(for: PopupStore.self))!)
        icon.contentMode = .scaleAspectFit
        let lineView = UIView()
        lineView.backgroundColor = Colors.mainColor
        
        self.contentView.addSubviews(icon, labelTitle, labelAddress, labelKilometer, lineView)
        icon.snp.makeConstraints { make in
            make.width.height.equalTo(20.heightRatio)
            make.top.leading.equalToSuperview().inset(15.heightRatio)
        }
        labelTitle.snp.makeConstraints { make in
            make.top.equalToSuperview().inset(15.heightRatio)
            make.leading.equalTo(icon.snp.trailing).offset(5)
        }
        labelKilometer.snp.makeConstraints { make in
            make.top.trailing.equalToSuperview().inset(15.heightRatio)
            make.leading.equalTo(labelTitle.snp.trailing).offset(5)
            make.width.equalTo(80.widthRatio)
        }
        labelAddress.snp.makeConstraints { make in
            make.top.equalTo(labelTitle.snp.bottom).offset(5.heightRatio)
            make.leading.trailing.equalToSuperview().inset(15.heightRatio)
        }
        lineView.snp.makeConstraints { make in
            make.top.equalTo(labelAddress.snp.bottom).offset(5.heightRatio)
            make.height.equalTo(0.5)
            make.bottom.equalToSuperview().inset(5)
        }
    }
    
    func bindData(with storeData: StoreData) {
        labelTitle.text = storeData.StoreName
        labelAddress.text = storeData.StoreAddress
        let km = storeData.km ?? 0
        labelKilometer.text = String(format: "%.2fk", (km/1000)) + "km"
    }
}
