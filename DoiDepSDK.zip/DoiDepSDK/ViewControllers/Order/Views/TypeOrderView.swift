//
//  TypeOrderView.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 21/07/2022.
//

import UIKit

class TypeOrderView: UIView {
    
    lazy var iconCheck1: UIImageView = {
        let imageView = UIImageView(image: UIImage().getImage(with: "ic_selected", and: Bundle(for: TypeOrderView.self))!)
        imageView.contentMode = .scaleAspectFit
        imageView.isUserInteractionEnabled = true
        let gesture = UITapGestureRecognizer(target: self, action: #selector(tappedDelivery))
        imageView.addGestureRecognizer(gesture)
        return imageView
    }()
    
    lazy var labelTitle1: UILabel = {
        let label = UILabel()
        label.text = "Giao tận nơi"
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 15, weight: .light)
        return label
    }()
    
    lazy var iconCheck2: UIImageView = {
        let imageView = UIImageView(image: UIImage().getImage(with: "ic_non_select", and: Bundle(for: TypeOrderView.self))!)
        imageView.contentMode = .scaleAspectFit
        imageView.isUserInteractionEnabled = true
        let gesture = UITapGestureRecognizer(target: self, action: #selector(tappedPickUpAtStore))
        imageView.addGestureRecognizer(gesture)
        return imageView
    }()
    
    lazy var labelTitle2: UILabel = {
        let label = UILabel()
        label.text = "Nhận tại cửa hàng"
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 15, weight: .light)
        return label
    }()
    
    var isPickupAtStore: Bool = false {
        didSet {
            if isPickupAtStore {
                iconCheck1.image = UIImage().getImage(with: "ic_non_select", and: Bundle(for: TypeOrderView.self))!
                iconCheck2.image = UIImage().getImage(with: "ic_selected", and: Bundle(for: TypeOrderView.self))!
            } else {
                iconCheck1.image = UIImage().getImage(with: "ic_selected", and: Bundle(for: TypeOrderView.self))!
                iconCheck2.image = UIImage().getImage(with: "ic_non_select", and: Bundle(for: TypeOrderView.self))!
            }
        }
    }
    
    var didTapDelivery: (()->())?
    var didTapPickUpAtStore: (()->())?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        let stack1 = UIStackView(arrangedSubviews: [iconCheck1, labelTitle1])
        stack1.spacing = 10
        stack1.axis = .horizontal
        stack1.alignment = .fill
        stack1.distribution = .fill
        
        let stack2 = UIStackView(arrangedSubviews: [iconCheck2, labelTitle2])
        stack2.spacing = 10
        stack2.axis = .horizontal
        stack2.alignment = .fill
        stack2.distribution = .fill
        
        let stackContent = UIStackView(arrangedSubviews: [stack1, stack2])
        stackContent.axis = .vertical
        stackContent.alignment = .fill
        stackContent.distribution = .fill
        stackContent.layer.cornerRadius = 10
        stackContent.layer.borderWidth = 0.5
        stackContent.layer.borderColor = Colors.mainColor.cgColor
        self.addSubview(stackContent)
        
        stackContent.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview().inset(10.heightRatio)
        }
        
        iconCheck1.setConstraintWidthAndHeight(widthConstant: 30.heightRatio, heightConstant: 30.heightRatio)
        iconCheck2.setConstraintWidthAndHeight(widthConstant: 30.heightRatio, heightConstant: 30.heightRatio)
        
        stackContent.layoutMargins = UIEdgeInsets(top: 5.heightRatio, left: 15.widthRatio, bottom: 5.heightRatio, right: 15.widthRatio)
        stackContent.isLayoutMarginsRelativeArrangement = true
    }
    
    @objc private func tappedDelivery() {
        if !isPickupAtStore {
            return
        }
        
        isPickupAtStore = false
        didTapDelivery?()
    }
    
    @objc private func tappedPickUpAtStore() {
        if isPickupAtStore {
            return
        }
        
        isPickupAtStore = true
        didTapPickUpAtStore?()
    }
}
