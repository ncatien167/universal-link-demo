//
//  AddressCell.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 21/07/2022.
//

import UIKit

class AddressCell: UITableViewCell {
    
    // MARK: - UI
    
    lazy var viewContainer: UIView = {
        let view = UIView()
        view.layer.cornerRadius = 10
        view.layer.borderWidth = 0.5
        view.layer.borderColor = Colors.mainColor.cgColor
        return view
    }()
    
    lazy var contentStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.alignment = .fill
        stackView.distribution = .fill
        stackView.spacing = 10.heightRatio
        return stackView
    }()
    
    lazy var labelName: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        label.textColor = Colors.authenticateColor
        return label
    }()
    
    lazy var labelPhone: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 13)
        label.textColor = Colors.authenticateColor
        return label
    }()
    
    lazy var labelAddress: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 13)
        label.textColor = Colors.authenticateColor
        return label
    }()
    
    lazy var labelSetCurrentAddress: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 13)
        label.textColor = Colors.authenticateColor
        return label
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.setupUI()
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.awakeFromNib()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.awakeFromNib()
    }
    
    func setupUI() {

        self.contentView.addSubview(viewContainer)
        viewContainer.addSubview(contentStackView)
        
        viewContainer.snp.makeConstraints { make in
            make.top.bottom.equalToSuperview().inset(10.heightRatio)
            make.leading.trailing.equalToSuperview().inset(15.heightRatio)
        }
        
        contentStackView.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview().inset(10.heightRatio)
        }
        
        let iconLocation1 = UIImageView(image: UIImage().getImage(with: "ic_location", and: Bundle(for: AddressCell.self))!)
        iconLocation1.contentMode = .scaleAspectFit
        
        let iconLocation2 = UIImageView(image: UIImage().getImage(with: "ic_location", and: Bundle(for: AddressCell.self))!)
        iconLocation2.contentMode = .scaleAspectFit
        
        let stackName = UIStackView(arrangedSubviews: [labelName, labelPhone])
        stackName.axis = .vertical
        stackName.alignment = .fill
        stackName.distribution = .fill
        
        let stackFirst = UIStackView(arrangedSubviews: [stackName, iconLocation1])
        stackFirst.axis = .horizontal
        stackFirst.alignment = .center
        stackFirst.distribution = .fill
        
        let stackCurrentAddress = UIStackView(arrangedSubviews: [iconLocation2, labelSetCurrentAddress])
        stackCurrentAddress.axis = .horizontal
        stackCurrentAddress.alignment = .fill
        stackCurrentAddress.distribution = .fill
        
        contentStackView.addArrangedSubview(stackFirst)
        contentStackView.addArrangedSubview(labelAddress)
        contentStackView.addArrangedSubview(stackCurrentAddress)
        
        iconLocation1.setConstraintWidthAndHeight(widthConstant: 30.heightRatio, heightConstant: 30.heightRatio)
        iconLocation2.setConstraintWidthAndHeight(widthConstant: 25.heightRatio, heightConstant: 20.heightRatio)
    }
    
    func bindData(with address: AddressData) {
        labelName.text = address.CustomerName
        labelPhone.text = address.Phone
        labelAddress.text = "\(address.Address ?? ""), \(address.WardName ?? ""), \(address.DistrictName ?? ""), \((address.ProvinceName ?? ""))"
        
        labelSetCurrentAddress.text = "Địa chỉ mặc định"
    }
}
