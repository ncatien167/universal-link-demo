//
//  TypeAddressView.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 20/07/2022.
//

import UIKit

class TypeAddressView: UIView {
    
    lazy var buttonOffice: UIButton = {
        let button = UIButton()
        button.backgroundColor = .white
        button.layer.cornerRadius = 5
        button.layer.borderWidth = 0.5
        button.layer.borderColor = Colors.mainColor.cgColor
        button.setTitle("Văn phòng", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        button.setTitleColor(Colors.authenticateColor, for: .normal)
        button.layer.masksToBounds = true
        button.addTarget(self, action: #selector(tappedOffice), for: .touchUpInside)
        return button
    }()
    
    lazy var buttonHome: UIButton = {
        let button = UIButton()
        button.backgroundColor = .white
        button.layer.cornerRadius = 5
        button.layer.borderWidth = 0.5
        button.layer.borderColor = Colors.mainColor.cgColor
        button.backgroundColor = Colors.mainColor
        button.setTitle("Nhà riêng", for: .normal)
        button.setTitleColor(Colors.white, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        button.layer.masksToBounds = true
        button.addTarget(self, action: #selector(tappedHome), for: .touchUpInside)
        return button
    }()
    
    var isSelectHome: Bool = true {
        didSet {
            if isSelectHome {
                buttonHome.backgroundColor = Colors.mainColor
                buttonOffice.backgroundColor = .white
                
                buttonHome.setTitleColor(Colors.white, for: .normal)
                buttonOffice.setTitleColor(Colors.authenticateColor, for: .normal)
            } else {
                buttonHome.backgroundColor = .white
                buttonOffice.backgroundColor = Colors.mainColor
                
                buttonHome.setTitleColor(Colors.authenticateColor, for: .normal)
                buttonOffice.setTitleColor(Colors.white, for: .normal)
            }
        }
    }
    
    var didTapHome: (()->())?
    var didTapOffice: (()->())?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        let stackButton = UIStackView(arrangedSubviews: [buttonOffice, buttonHome])
        stackButton.axis = .horizontal
        stackButton.alignment = .fill
        stackButton.distribution = .fillEqually
        stackButton.spacing = 10
        self.addSubview(stackButton)
        stackButton.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview()
        }
        
        buttonHome.setConstraintWidthAndHeight(widthConstant: 100.widthRatio, heightConstant: 20.widthRatio)
        buttonOffice.setConstraintWidthAndHeight(widthConstant: 100.widthRatio, heightConstant: 20.widthRatio)
    }
    
    @objc private func tappedHome() {
        didTapHome?()
        if !isSelectHome {
            isSelectHome = true
        }
    }
    
    @objc private func tappedOffice() {
        didTapOffice?()
        if isSelectHome {
            isSelectHome = false
        }
    }
}

