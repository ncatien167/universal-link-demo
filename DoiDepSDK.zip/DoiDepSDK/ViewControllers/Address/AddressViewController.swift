//
//  AddressViewController.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 19/07/2022.
//

import UIKit

class AddressViewController: BackNavigationVC {

    lazy var contentView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        return view
    }()
    
    lazy var scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        return scrollView
    }()
    
    lazy var contentStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.alignment = .center
        stackView.distribution = .fillProportionally
        stackView.spacing = 15.heightRatio
        stackView.backgroundColor = .white
        return stackView
    }()
    
    lazy var tableView: UITableView = {
        let tableView = UITableView()
        return tableView
    }()
    
    lazy var buttonCreateAddress: PersonalButtonView = {
        let button = PersonalButtonView()
        button.setup(title: "Thêm địa chỉ mới", leftImage: UIImage().getImage(with: "ic_plus", and: Bundle(for: PersonalViewController.self))!, rightImage: UIImage())
        button.didTap = { [weak self] in
            guard let self = self else { return }
            self.didTapCreateAddress()
        }
        return button
    }()
    
    // MARK: - Properties
    private var addressProvider: DataProvider<AddressData> = DataProvider(data: [])
    private var addressDataSource: TableViewDataSource<AddressCell, AddressData>!
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
        configTableView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        addressProvider.data = CommonService.shared.getAddresses()
        tableView.reloadData()
    }
    //MARK: - Set up
    
    private func setupUI() {
        self.headerView.title = "Địa chỉ giao hàng"
        self.view.addSubview(contentView)
        self.contentView.addSubviews(tableView, buttonCreateAddress)

        contentView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(headerView.frame.height)
            make.bottom.leading.trailing.equalToSuperview()
        }
        
        tableView.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview()
            make.top.equalToSuperview().inset(15.heightRatio)
        }
        
        buttonCreateAddress.snp.makeConstraints { make in
            make.bottom.equalToSuperview().inset(35.heightRatio)
            make.leading.trailing.equalToSuperview().inset(15.heightRatio)
            make.top.equalTo(tableView.snp.bottom).offset(15.heightRatio)
        }
    }
    
    private func configTableView() {
        tableView.delegate = self
        tableView.separatorStyle = .none
        tableView.alwaysBounceVertical = true
        tableView.register(cellClass: AddressCell.self)
        addressDataSource = TableViewDataSource(dataProvider: addressProvider)
        
        addressDataSource.configureCell = { [weak self] cell, model, index in
            guard let _ = self else { return }
            cell.bindData(with: model)
            cell.selectionStyle = .none
        }
        
        tableView.dataSource = addressDataSource
        tableView.reloadData()
    }
    
    private func didTapCreateAddress() {
        self.navigationController?.pushViewController(CreateAddressViewController(), animated: true)
    }
}

extension AddressViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.navigationController?.pushViewController(CreateAddressViewController(isEditAddress: true, addressData: addressProvider.data[indexPath.row]), animated: true)
    }
}
