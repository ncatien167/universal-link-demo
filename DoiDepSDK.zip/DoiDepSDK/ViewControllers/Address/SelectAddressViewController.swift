//
//  SelectAddressViewController.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 20/07/2022.
//

import UIKit

enum StepSelectAddress {
    case province
    case district
    case ward
}

class SelectAddressViewController: BackNavigationVC {

    // MARK: - UI
    
    lazy var contentStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.alignment = .center
        stackView.distribution = .fill
        stackView.backgroundColor = .white
        return stackView
    }()
    
    lazy var labelTitleTable: UILabel = {
        let label = UILabel()
        label.text = "Tỉnh/Thành phố"
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 15, weight: .bold)
        return label
    }()
    
    lazy var buttonReset: UIButton = {
        let button = UIButton()
        button.isHidden = true
        button.setTitle("Thiết lập lại", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        button.setTitleColor(Colors.authenticateColor, for: .normal)
        button.addTarget(self, action: #selector(didTapResetButton), for: .touchUpInside)
        return button
    }()
    
    lazy var labelProvince: ABCView = {
        let view = ABCView()
        view.isHidden = true
        return view
    }()
    
    lazy var labelDistrict: ABCView = {
        let view = ABCView()
        view.isHidden = true
        return view
    }()
    
    lazy var labelWard: ABCView = {
        let view = ABCView()
        view.isHidden = true
        return view
    }()
    
    lazy var addressTextField: TextField = {
        let textField = TextField()
        textField.isHidden = true
        textField.layer.cornerRadius = 5
        textField.layer.borderWidth = 0.5
        textField.layer.borderColor = Colors.mainColor.cgColor
        textField.font = UIFont.systemFont(ofSize: 15)
        textField.textColor = Colors.normalTextColor
        textField.placeholder = "Nhập địa chỉ hiện tại của bạn"
        return textField
    }()
    
//    lazy var
    lazy var tableView: UITableView = {
        let tableView = UITableView()
        return tableView
    }()
    
    // MARK: - Properties
    private var provinceProvider: DataProvider<AreaProvinceData> = DataProvider(data: [])
    private var provinceDataSource: TableViewDataSource<UITableViewCell, AreaProvinceData>!
    
    private var wardDistrictProvider: DataProvider<WardDistrictData> = DataProvider(data: [])
    private var wardDistrictDataSource: TableViewDataSource<UITableViewCell, WardDistrictData>!
    
    private var areaProvinceData: [WardDistrictData] = []
    
    private var stepSelectAddress: StepSelectAddress = .province
    private var wardDistrictData: WardDistrictData? = WardDistrictData()
    private var presenter: SelectAddressPresenter?
    
    var didDone: ((WardDistrictData?, String?)->())?
    
    // MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter = SelectAddressPresenter(self)
        setupUI()
        configTableview()
        configProviderAndDataSource()
    }
    
    deinit {
        presenter = nil
    }

    // MARK: - Set up
    
    override func setUpRightBarButton() {
        let doneButtonItem = UIBarButtonItem(title: "Chọn", style: .plain, target: self, action: #selector(didTapDoneButton))
        firstNavItem?.rightBarButtonItem = doneButtonItem
        firstNavItem?.rightBarButtonItem?.tintColor = .white
    }
    
    private func setupUI() {
        self.view.addSubview(contentStackView)
        
        contentStackView.snp.makeConstraints { make in
            make.top.equalTo(headerView.snp.bottom)
            make.bottom.leading.trailing.equalToSuperview()
        }
        
        let stackTitle = UIStackView(arrangedSubviews: [labelTitleTable, buttonReset])
        stackTitle.axis = .horizontal
        stackTitle.alignment = .fill
        stackTitle.distribution = .fill
        
        contentStackView.addArrangedSubview(addressTextField)
        contentStackView.addArrangedSubview(stackTitle)
        contentStackView.addArrangedSubview(labelProvince)
        contentStackView.addArrangedSubview(labelDistrict)
        contentStackView.addArrangedSubview(labelWard)
        contentStackView.addArrangedSubview(tableView)
        
        tableView.setConstraintWidth(constant: 375.widthRatio)
        labelWard.setConstraintWidth(constant: 345.widthRatio)
        labelDistrict.setConstraintWidth(constant: 345.widthRatio)
        labelProvince.setConstraintWidth(constant: 345.widthRatio)
        buttonReset.setConstraintWidth(constant: 100.widthRatio)

        addressTextField.setConstraintWidthAndHeight(widthConstant: 345.widthRatio, heightConstant: 35.heightRatio)
        stackTitle.setConstraintWidthAndHeight(widthConstant: 345.widthRatio, heightConstant: 35.heightRatio)
        
        contentStackView.layoutMargins = UIEdgeInsets(top: 15.heightRatio, left: 15.widthRatio, bottom: 0, right: 15.widthRatio)
        contentStackView.isLayoutMarginsRelativeArrangement = true
    }
    
    private func configTableview() {
        tableView.delegate = self
        tableView.alwaysBounceVertical = true
        tableView.register(cellClass: UITableViewCell.self)
    }
    
    private func configProviderAndDataSource() {
        provinceProvider.data = CommonService.shared.getAreaProvinces()
        provinceDataSource = TableViewDataSource(dataProvider: provinceProvider)
        provinceDataSource.configureCell = { [weak self] cell, model, index in
            guard let _ = self else { return }
            cell.textLabel?.text = model.Name
            cell.textLabel?.font = UIFont.systemFont(ofSize: 14, weight: .light)
            cell.textLabel?.textColor = Colors.normalTextColor
            cell.separatorInset = UIEdgeInsets(top: 0, left: 15.widthRatio, bottom: 0, right: 15.widthRatio)
        }
        
        tableView.dataSource = provinceDataSource
        tableView.reloadData()
    }
    
    private func changeConfigProviderAndDataSource() {
        wardDistrictDataSource = TableViewDataSource(dataProvider: wardDistrictProvider)
        wardDistrictDataSource.configureCell = { [weak self] cell, model, index in
            guard let _ = self else { return }
            cell.textLabel?.text = model.getName()
            cell.textLabel?.font = UIFont.systemFont(ofSize: 14, weight: .light)
            cell.textLabel?.textColor = Colors.normalTextColor
            cell.separatorInset = UIEdgeInsets(top: 0, left: 15.widthRatio, bottom: 0, right: 15.widthRatio)
        }
        
        tableView.dataSource = wardDistrictDataSource
        tableView.reloadData()
    }
    
    // MARK: - Handle
    private func handleUISelectProvince(with provinceID: Int) {
        labelTitleTable.text = "Khu vực được chọn"
        labelProvince.isHidden = false
        buttonReset.isHidden = false
        
        labelProvince.setText(with: CommonService.shared.getProvinceData(with: provinceID)?.Name)
    }
    
    private func handleUISelectDistrict() {
        labelDistrict.isHidden = false
        labelDistrict.setText(with: self.wardDistrictData?.DistrictName)
    }
    
    private func handleUISelectWard() {
        wardDistrictProvider.data = []
        tableView.reloadData()
        labelWard.isHidden = false
        addressTextField.isHidden = false
        labelWard.setText(with: self.wardDistrictData?.WardName, true)
    }
    
    // MARK: - Action
    @objc private func didTapResetButton() {
        DispatchQueue.main.async {
            self.stepSelectAddress = .province
            self.labelWard.isHidden = true
            self.buttonReset.isHidden = true
            self.labelDistrict.isHidden = true
            self.labelProvince.isHidden = true
            self.addressTextField.isHidden = true
            self.wardDistrictData = WardDistrictData()
            self.configProviderAndDataSource()
        }
    }
    
    @objc private func didTapDoneButton() {
        guard let wardDistrictData = self.wardDistrictData else {
            return
        }
        
        guard let _ = wardDistrictData.ProvinceID, let _ = wardDistrictData.DistrictID, let _ = wardDistrictData.ID, let address = addressTextField.text else {
            CommonPopup.showAlertOnlyOk("Vui lòng chọn và nhập địa chỉ của bạn", title: nil, okCompletion: nil)
            return
        }
        
        if address == "" {
            CommonPopup.showAlertOnlyOk("Vui lòng chọn và nhập địa chỉ của bạn", title: nil, okCompletion: nil)
            return
        }
        
        didDone?(wardDistrictData, address)
        self.navigationController?.popViewController(animated: true)
    }
}

// MARK: - Table View Delegate
extension SelectAddressViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch stepSelectAddress {
        case .province:
            stepSelectAddress = .district
            changeConfigProviderAndDataSource()
            wardDistrictData?.Name = provinceProvider.data[indexPath.row].Name
            wardDistrictData?.ProvinceID = provinceProvider.data[indexPath.row].ID
            presenter?.requestDistrict(with: (provinceProvider.data[indexPath.row].ID ?? 0))
            break
        case .district:
            stepSelectAddress = .ward
            let districtName = "\(wardDistrictProvider.data[indexPath.row].Prefix ?? "") \(wardDistrictProvider.data[indexPath.row].Name ?? "")"
            wardDistrictData?.DistrictName = districtName
            wardDistrictData?.DistrictID = wardDistrictProvider.data[indexPath.row].ID
            presenter?.requestWard(with: (wardDistrictProvider.data[indexPath.row].ID ?? 0))
            break
        case .ward:
            let wardName = "\(wardDistrictProvider.data[indexPath.row].Prefix ?? "") \(wardDistrictProvider.data[indexPath.row].Name ?? "")"
            wardDistrictData?.WardName = wardName
            wardDistrictData?.ID = wardDistrictProvider.data[indexPath.row].ID
            handleUISelectWard()
            break
        }
    }
}

// MARK: - Presenter View
extension SelectAddressViewController: SelectAddressView {
    func onCheckRequestDistrict(with wardDistrictDatas: [WardDistrictData]) {
        DispatchQueue.main.async {
            self.wardDistrictProvider.data = wardDistrictDatas
            self.tableView.reloadData()
            self.handleUISelectProvince(with: wardDistrictDatas.first?.ProvinceID ?? 0)
        }
    }
    
    func onCheckRequestWard(with wardDistrictDatas: [WardDistrictData]) {
        DispatchQueue.main.async {
            self.wardDistrictProvider.data = wardDistrictDatas
            self.tableView.reloadData()
            self.handleUISelectDistrict()
        }
    }
        
}

class ABCView: UIView {
    
    lazy var label: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 14)
        return label
    }()
    
    lazy var viewLine: UIView = {
        let view = UIView()
        view.backgroundColor = Colors.mainColor
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        let viewLabel = UIView()
        viewLabel.backgroundColor = Colors.mainColor
        viewLabel.addSubviews(label)
        label.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview().inset(10)
        }
        
        self.addSubviews(viewLabel, viewLine)
        
        viewLabel.snp.makeConstraints { make in
            make.top.leading.equalToSuperview()
            make.height.equalTo(40.heightRatio)
        }
        viewLine.snp.makeConstraints { make in
            make.top.equalTo(viewLabel.snp.bottom)
            make.leading.equalToSuperview().inset(10)
            make.bottom.equalToSuperview()
            make.width.equalTo(2)
            make.height.equalTo(35.heightRatio)
        }
    }
    
    func setText(with text: String?, _ isLastItem: Bool = false) {
        label.text = text
        if (isLastItem) {
            viewLine.isHidden = true
        }
    }
}

class TextField: UITextField {

    var padding = UIEdgeInsets(top: 0, left: 10.heightRatio, bottom: 0, right: 5)

    override open func textRect(forBounds bounds: CGRect) -> CGRect {
        return bounds.inset(by: padding)
    }

    override open func placeholderRect(forBounds bounds: CGRect) -> CGRect {
        return bounds.inset(by: padding)
    }

    override open func editingRect(forBounds bounds: CGRect) -> CGRect {
        return bounds.inset(by: padding)
    }
}
