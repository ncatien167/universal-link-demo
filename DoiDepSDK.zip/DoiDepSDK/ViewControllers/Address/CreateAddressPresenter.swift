//
//  CreateAddressPresenter.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 20/07/2022.
//

import Foundation

protocol CreateAddressView {
    func onCheckCreateAddressSuccess()
    func onCheckCreateAddressFailed()
    func onCheckSetIsDefaultSuccess()
    func onDeleteAddressSuccess()
}

protocol CreateAddressViewPresenter {
    init(_ view: CreateAddressView)

    func requestCreateAddress(with addressParam: AddressParam)
    func requestSetDefaultAddress(with addressID: Int)
    func requestDeleteAddress(with addressID: Int)
}

class CreateAddressPresenter: CreateAddressViewPresenter {
    
    var view: CreateAddressView?
    
    required init(_ view: CreateAddressView) {
        self.view = view
    }
    
    func requestCreateAddress(with addressParam: AddressParam) {
        AddressService.requestCreateAddress(with: addressParam) { status in
            guard let status = status else {
                self.view?.onCheckCreateAddressFailed()
                return
            }
            
            if !status {
                self.view?.onCheckCreateAddressFailed()
                return
            }
            
            CommonAPIService.getAddressData { _ in
                self.view?.onCheckCreateAddressSuccess()
            }
            return
        }
    }

    func requestSetDefaultAddress(with addressID: Int) {
        AddressService.requestSetDefaultAddress(with: addressID) { status in
            guard let status = status else { return }
            if status {
                self.view?.onCheckSetIsDefaultSuccess()
            }
        }
    }
    
    func requestDeleteAddress(with addressID: Int) {
        AddressService.requestDeleteAddress(with: addressID) { status in
            guard let status = status else { return }
            if status {
                self.view?.onDeleteAddressSuccess()
            }
        }
    }
}
