//
//  WebViewController.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 27/07/2022.
//

import UIKit
import WebKit

class WebViewController: BackNavigationVC {
    
    lazy var contentView: UIView = {
        let view = UIView()
        view.backgroundColor = Colors.colorSilverGround
        return view
    }()
    
    lazy var webView: WKWebView = {
        let jscript = "var meta = document.createElement('meta'); meta.setAttribute('name', 'viewport'); meta.setAttribute('content', 'width=device-width'); document.getElementsByTagName('head')[0].appendChild(meta);"
        let userScript = WKUserScript(source: jscript, injectionTime: .atDocumentEnd, forMainFrameOnly: true)
        let wkUController = WKUserContentController()
        wkUController.addUserScript(userScript)
        
        let wkWebConfig = WKWebViewConfiguration()
        wkWebConfig.userContentController = wkUController
        
        let webView = WKWebView()
        webView.backgroundColor = .white
        return webView
    }()
    
    private var requestUrl = ""
    private var htmlString = ""
    
    
    convenience init(requestUrl: String) {
        self.init()
        self.requestUrl = requestUrl
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initLayout()
        requestWebView()
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    private func initLayout() {
        self.view.addSubview(contentView)
        self.contentView.addSubview(webView)
        
        contentView.snp.makeConstraints { make in
            make.top.equalTo(headerView.snp.bottom)
            make.bottom.leading.trailing.equalToSuperview()
        }
        
        webView.snp.makeConstraints { make in
            make.top.equalTo(headerView.snp.bottom)
            make.bottom.leading.trailing.equalToSuperview()
        }
    }
    
    private func requestWebView() {
        if self.htmlString != "" {
            webView.loadHTMLString(htmlString, baseURL: nil)
            return
        }
        
        if let url = URL(string: requestUrl) {
            let request = URLRequest(url: url)
            webView.load(request)
        }
        
    }
    
}

extension WebViewController: WKNavigationDelegate {
    
    func webView(_ webView: WKWebView,didFinish navigation: WKNavigation!) {
        
    }
    
}
