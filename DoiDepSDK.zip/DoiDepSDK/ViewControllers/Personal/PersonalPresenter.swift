//
//  PersonalPresenter.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 15/08/2022.
//

import Foundation

protocol PersonalView {
    
}

protocol PersonalViewPresenter {
    init(_ view: PersonalView)
}

class PersonalPresenter: PersonalViewPresenter {
    var view: PersonalView?
    
    required init(_ view: PersonalView) {
        self.view = view

    }
    
    
}
