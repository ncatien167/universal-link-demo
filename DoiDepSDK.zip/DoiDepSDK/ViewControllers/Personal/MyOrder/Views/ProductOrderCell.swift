//
//  ProductOrderCell.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 07/08/2022.
//

import UIKit

class ProductOrderCell: UITableViewCell {
    
    // MARK: - UI
    
    lazy var labelTitle: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14, weight: .light)
        label.textColor = Colors.black
        label.numberOfLines = 0
        return label
    }()

    lazy var labelMoney: UILabel = {
        let label = UILabel()
        label.textAlignment = .right
        label.font = UIFont.systemFont(ofSize: 14, weight: .light)
        label.textColor = Colors.black
        return label
    }()
    
    lazy var lineView: UIView = {
        let view = UIView()
        view.backgroundColor = Colors.colorSilverGround
        return view
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.setupUI()
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.awakeFromNib()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.awakeFromNib()
    }
    
    func setupUI() {
        let stackTitle = UIStackView(arrangedSubviews: [labelTitle, labelMoney])
        stackTitle.axis = .horizontal
        stackTitle.alignment = .fill
        stackTitle.distribution = .fill
        stackTitle.spacing = 10

        self.contentView.addSubviews(stackTitle, lineView)
        self.contentView.backgroundColor = .clear
        
        stackTitle.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview()
        }
        
        lineView.snp.makeConstraints { make in
            make.height.equalTo(0.5)
            make.bottom.leading.trailing.equalToSuperview()
        }
    }
    
    func bindData(with data: OrderDetail, and index: Int) {
        labelTitle.text = "\(index + 1). \(data.ProductName ?? "")"
        labelMoney.text = "x\(data.Quantity ?? 0)x\(data.Price?.formatMoney ?? "0đ")"
    }
}
