//
//  CartMyOrderCell.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 02/08/2022.
//

import UIKit

class CartMyOrderCell: UITableViewCell {
    
    lazy var labelTitle: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 14, weight: .regular)
        return label
    }()
    
    lazy var labelPrice: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 13, weight: .regular)
        return label
    }()
    
    lazy var labelAmount: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textAlignment = .left
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 13, weight: .regular)
        return label
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.setupUI()
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.awakeFromNib()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.awakeFromNib()
    }
    
    private func setupUI() {
        let stackPrice = UIStackView(arrangedSubviews: [labelPrice, labelAmount])
        stackPrice.axis = .horizontal
        stackPrice.alignment = .fill
        stackPrice.distribution = .fill
        
        let contentStack = UIStackView(arrangedSubviews: [labelTitle, stackPrice])
        contentStack.axis = .vertical
        contentStack.alignment = .fill
        contentStack.distribution = .fill
        
        self.contentView.addSubview(contentStack)
        contentStack.snp.makeConstraints { make in
            make.bottom.leading.trailing.equalToSuperview()
            make.top.equalToSuperview().inset(5.heightRatio)
            make.height.equalTo(45.heightRatio)
        }
        
        labelPrice.snp.makeConstraints { make in
            make.width.equalTo(labelTitle.snp.width).multipliedBy(0.6)
        }
    }
    
    func bindData(with data: OrderDetail) {
        labelTitle.text = data.ProductName
        labelPrice.text = data.Price?.formatMoney
        labelAmount.text = "SL: \(data.Quantity ?? 0)"
    }
}

