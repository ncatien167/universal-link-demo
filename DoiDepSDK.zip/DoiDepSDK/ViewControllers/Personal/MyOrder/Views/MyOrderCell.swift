//
//  MyOrderCell.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 02/08/2022.
//

import UIKit

class MyOrderCell: UITableViewCell {
    
    lazy var containerView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        view.layer.cornerRadius = 10
        view.layer.borderWidth = 0.5
        view.layer.borderColor = Colors.mainColor.cgColor
        return view
    }()
    
    lazy var labelAddress: UILabel = {
        let label = UILabel()
        label.numberOfLines = 2
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 13, weight: .light)
        return label
    }()
    
    lazy var labelStatus: UILabel = {
        let label = UILabel()
        label.numberOfLines = 2
        label.textAlignment = .center
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 13, weight: .light)
        return label
    }()

    lazy var labelCreateDate: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textColor = Colors.normalTextColor
        label.font = UIFont.systemFont(ofSize: 13, weight: .regular)
        return label
    }()
    
    lazy var labelTotal: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 15, weight: .regular)
        return label
    }()
    
    lazy var labelTotalMoney: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textAlignment = .right
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 13, weight: .regular)
        return label
    }()
    
    lazy var tableView: UITableView = {
        let tableView = UITableView()
        tableView.separatorStyle = .none
        return tableView
    }()
    
    lazy var productImageView: UIImageView = {
        let imageView = UIImageView(image: UIImage().getImage(with: "img_empty.png", and: Bundle(for: CartCell.self))!)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    lazy var buttonReBuy: CommonButton = {
        let button = CommonButton()
        button.setup(title: "Mua lại", cornerRadius: 3, fontSize: 13)
        button.didTap = { [weak self] in
            guard let self = self else { return }
            self.didTapReBuyButton()
        }
        return button
    }()
    
    lazy var stackTable: UIStackView = {
        let stackTable = UIStackView()
        stackTable.spacing = 5
        stackTable.axis = .vertical
        stackTable.alignment = .fill
        stackTable.distribution = .fill
        return stackTable
    }()
    
    lazy var stackTotal: UIStackView = {
        let stackTotal = UIStackView()
        stackTotal.axis = .horizontal
        stackTotal.alignment = .fill
        stackTotal.distribution = .fill
        stackTotal.spacing = 10
        return stackTotal
    }()
    
    // MARK: - Properties
    private var cartProvider: DataProvider<OrderDetail> = DataProvider(data: [])
    private var cartDataSource: TableViewDataSource<CartMyOrderCell, OrderDetail>!
    
    var didReBuy: (()->())?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.setupUI()
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.awakeFromNib()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.awakeFromNib()
    }
    
    // Dùng để tránh việc reuuser cell, li dó vì hình ảnh sẽ bị load sai vị trí
    override func prepareForReuse() {
        super.prepareForReuse()
        self.productImageView.image = UIImage().getImage(with: "img_empty.png", and: Bundle(for: CartCell.self))!
//        self.labelAddress.text = ""
//        self.labelStatus.text = ""
//        self.labelCreateDate.text = "Ngày đặt: "
//        self.labelTotal.text = "Tổng tiền ( sản phẩm):"
//        self.labelTotalMoney.text = ""
    }
    
    func setupUI() {
        self.configTableView()
        self.contentView.addSubview(containerView)
        containerView.snp.makeConstraints { make in
            make.top.leading.trailing.equalToSuperview().inset(15.heightRatio)
            make.bottom.equalToSuperview().inset(20.heightRatio)
        }
        
        let iconLocation = UIImageView(image: UIImage().getImage(with: "ic_location", and: Bundle(for: AddressCell.self))!)
        iconLocation.contentMode = .scaleAspectFit
        self.containerView.addSubviews(iconLocation, labelAddress, labelStatus, productImageView)
        
        iconLocation.snp.makeConstraints { make in
            make.top.leading.equalToSuperview().inset(10.heightRatio)
            make.width.equalTo(25.heightRatio)
            make.height.equalTo(40.heightRatio)
        }

        labelAddress.snp.makeConstraints { make in
            make.height.equalTo(40.heightRatio)
            make.top.equalToSuperview().inset(10.heightRatio)
            make.leading.equalTo(iconLocation.snp.trailing).offset(5)
        }
        
        labelStatus.snp.makeConstraints { make in
            make.width.equalTo(80.widthRatio)
            make.height.equalTo(40.heightRatio)
            make.top.trailing.equalToSuperview().inset(10.heightRatio)
            make.leading.equalTo(labelAddress.snp.trailing).offset(10)
        }
        
        productImageView.snp.makeConstraints { make in
            make.top.equalTo(labelAddress.snp.bottom).offset(15.heightRatio)
            make.leading.equalToSuperview().inset(20.heightRatio)
            make.width.height.equalTo(75.heightRatio)
        }
        
        stackTable.addArrangedSubview(tableView)
        stackTable.addArrangedSubview(labelCreateDate)
        self.containerView.addSubview(stackTable)
        labelCreateDate.setConstraintHeight(constant: 20.heightRatio)
        stackTable.snp.makeConstraints { make in
            make.trailing.equalToSuperview().inset(15.widthRatio)
            make.top.equalTo(labelAddress.snp.bottom).offset(15.heightRatio)
            make.leading.equalTo(productImageView.snp.trailing).offset(10.widthRatio)
        }
        
        tableView.snp.makeConstraints { make in
            make.height.equalTo(50.heightRatio)
        }
        
        stackTotal.addArrangedSubview(labelTotal)
        stackTotal.addArrangedSubview(labelTotalMoney)
        self.containerView.addSubview(stackTotal)
        
        labelTotalMoney.setConstraintWidth(constant: 100.widthRatio)
        stackTotal.snp.makeConstraints { make in
            make.height.equalTo(30.heightRatio)
            make.bottom.equalToSuperview().inset(25.heightRatio)
            make.leading.equalToSuperview().inset(70.widthRatio)
            make.trailing.equalToSuperview().inset(10.widthRatio)
            make.top.equalTo(stackTable.snp.bottom).offset(20.heightRatio)
        }
        
        setupReBuyButton()
    }
    
    private func setupReBuyButton() {
        self.contentView.addSubview(buttonReBuy)
        buttonReBuy.snp.makeConstraints { make in
            make.bottom.equalToSuperview().inset(5.heightRatio)
            make.width.equalTo(60.widthRatio)
            make.height.equalTo(30.heightRatio)
            make.trailing.equalToSuperview().inset(25.heightRatio)
        }
    }
    
    private func configTableView() {
        cartProvider.data = []
        tableView.isScrollEnabled = false
        tableView.alwaysBounceVertical = true
        tableView.isUserInteractionEnabled = false
        tableView.register(cellClass: CartMyOrderCell.self)
        
        cartDataSource = TableViewDataSource(dataProvider: cartProvider)
        
        cartDataSource.configureCell = { [weak self] cell, model, index in
            guard let _ = self else { return }
            cell.bindData(with: model)
            cell.selectionStyle = .none
        }
        
        tableView.dataSource = cartDataSource
        tableView.reloadData()
    }
    
    func bindData(with data: OrderData, type: OrderType) {
        DispatchQueue.main.async {
            self.labelAddress.text = "\(data.ShipAddress ?? ""), \(data.WardName ?? ""), \(data.DistrictName ?? ""), \((data.ProvinceName ?? ""))"
            self.labelStatus.text = type.title
            
            self.buttonReBuy.isHidden = type.isHiddenRebuy
            let dateString = (data.CreatedAt ?? "").toDateFormat()
            self.labelCreateDate.text = "Ngày đặt: \(dateString)"
            
            self.labelTotal.text = "Tổng tiền (\(data.totalQuantity()) sản phẩm):"
            let totalPrice = data.totalPriceDouble() - (data.Discount ?? 0)
            self.labelTotalMoney.text = totalPrice.formatMoney
            
            if let urlImage = data.OrderDetails?.first?.Thumbnail {
                self.productImageView.loadImage(urlString: urlImage, UIImage().getImage(with: "img_empty.png", and: Bundle(for: MyOrderCell.self))!)
            }
            
            self.cartProvider.data = data.OrderDetails ?? []
            self.tableView.reloadData()
            
            var height = 50.heightRatio
            if let count = data.OrderDetails?.count {
                if count > 0 {
                    height = 50.heightRatio * CGFloat(count)
                }
            }

            self.tableView.snp.updateConstraints { make in
                make.height.equalTo(height)
            }
        }
    }
    
    private func didTapReBuyButton() {
        didReBuy?()
    }
}

extension MyOrderCell: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50.heightRatio
    }
}
