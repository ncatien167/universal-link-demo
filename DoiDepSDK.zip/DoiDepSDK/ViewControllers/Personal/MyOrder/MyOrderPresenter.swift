//
//  MyOrderPresenter.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 31/07/2022.
//

import UIKit

protocol MyOrderView {
    func onReloadMyOrder(with yourOrderDatas: [OrderData])
}

protocol MyOrderViewPresenter {
    init(_ view: MyOrderView)
    
    func getYourOrder(with ID: Int)
}

class MyOrderPresenter: MyOrderViewPresenter {
    
    var view: MyOrderView?
    
    required init(_ view: MyOrderView) {
        self.view = view

    }
    
    func getYourOrder(with ID: Int) {
        OrderService.requestGetYourOrder(with: ID) { status, yourOrderDatas in
            guard let status = status, let yourOrderDatas = yourOrderDatas else {
                self.view?.onReloadMyOrder(with: [])
                return
            }
            
            if !status {
                self.view?.onReloadMyOrder(with: [])
                return 
            }
            
            self.view?.onReloadMyOrder(with: yourOrderDatas)
        }
    }
}
