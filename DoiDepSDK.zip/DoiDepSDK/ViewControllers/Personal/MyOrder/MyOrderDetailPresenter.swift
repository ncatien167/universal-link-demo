//
//  MyOrderDetailPresenter.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 08/08/2022.
//

import UIKit

protocol MyOrderDetailView {
    func onDeleteMyOrderSuccess(with message: String?)
    func onDeleteMyOrderFailed(with message: String?)
}

protocol MyOrderDetailViewPresenter {
    init(_ view: MyOrderDetailView)
    
    func deleteYourOrder(with code: String)
}

class MyOrderDetailPresenter: MyOrderDetailViewPresenter {
    
    var view: MyOrderDetailView?
    
    required init(_ view: MyOrderDetailView) {
        self.view = view

    }

    func deleteYourOrder(with code: String) {
        OrderService.requestDeleteYourOrder(with: code) { status, mess in
            guard let status = status else {
                self.view?.onDeleteMyOrderFailed(with: mess)
                return
            }
            
            if status {
                self.view?.onDeleteMyOrderSuccess(with: mess)
                return
            }
            
            self.view?.onDeleteMyOrderFailed(with: mess)
        }
    }
}
