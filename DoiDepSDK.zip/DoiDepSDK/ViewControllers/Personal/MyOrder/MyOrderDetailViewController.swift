//
//  MyOrderDetailViewController.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 04/08/2022.
//

import UIKit

class MyOrderDetailViewController: BackNavigationVC {

    // MARK: - UI
    lazy var contentView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        return view
    }()
    
    lazy var scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        return scrollView
    }()
    
    lazy var backgroundImage: UIImageView = {
        let imageView = UIImageView(image: UIImage().getImage(with: "ic_logo_blur", and: Bundle(for: MyOrderDetailViewController.self)))
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    lazy var contentStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.alignment = .center
        stackView.distribution = .fill
        stackView.spacing = 20.heightRatio
        return stackView
    }()
    
    // Header
    lazy var titleHeaderView: UIView = {
        let view = UIView()
        view.backgroundColor = Colors.authenticateColor
        return view
    }()
    
    lazy var labelStatusTitle: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        return label
    }()
    
    lazy var labelSubTitle: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.text = "cảm ơn bạn đã mua sắm tại Doidep"
        label.font = UIFont.systemFont(ofSize: 14, weight: .light)
        return label
    }()
    
    // Info Address
    lazy var addressInfoView: UIView = {
        let view = UIView()
        view.layer.cornerRadius = 10
        view.layer.borderWidth = 0.5
        view.layer.borderColor = Colors.authenticateColor.cgColor
        return view
    }()
    
    lazy var labelTypeBuyProduct: UILabel = {
        let label = UILabel()
        label.textColor = Colors.normalTextColor
        label.font = UIFont.systemFont(ofSize: 14, weight: .light)
        return label
    }()
    
    lazy var labelName: UILabel = {
        let label = UILabel()
        label.textColor = Colors.mainColor
        label.font = UIFont.systemFont(ofSize: 15, weight: .bold)
        return label
    }()
    
    lazy var labelPhone: UILabel = {
        let label = UILabel()
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 14, weight: .light)
        return label
    }()
    
    lazy var labelAddress: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 14, weight: .light)
        return label
    }()

    // Thông tin đơn hàng
    lazy var productInfoView: UIView = {
        let view = UIView()
        view.layer.cornerRadius = 10
        view.layer.borderWidth = 0.5
        view.layer.borderColor = Colors.authenticateColor.cgColor
        return view
    }()
    
    lazy var labelProductTitle: UILabel = {
        let label = UILabel()
        label.text = "Thông tin đơn hàng"
        label.textColor = Colors.mainColor
        label.font = UIFont.systemFont(ofSize: 15, weight: .bold)
        return label
    }()
    
    lazy var productTableView: UITableView = {
        let tableView = UITableView()
        tableView.backgroundColor = .clear
        return tableView
    }()
    
    // Phí và giá tiền
    lazy var varAndPriceView: UIView = {
        let view = UIView()
        view.layer.cornerRadius = 10
        view.layer.borderWidth = 0.5
        view.layer.borderColor = Colors.authenticateColor.cgColor
        return view
    }()
    
    lazy var orderInfoView: MyOrderInfoView = {
        let view = MyOrderInfoView()
        view.backgroundColor = .clear
        return view
    }()
    
    // Phương thức thanh toán và đơn hàng
    lazy var paymentMethodView: UIView = {
        let view = UIView()
        view.layer.cornerRadius = 10
        view.layer.borderWidth = 0.5
        view.layer.borderColor = Colors.authenticateColor.cgColor
        return view
    }()
    
    lazy var labelPaymentMethod: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 14, weight: .light)
        return label
    }()
    
    lazy var codeView: UIView = {
        let view = UIView()
        view.layer.cornerRadius = 10
        view.layer.borderWidth = 0.5
        view.layer.borderColor = Colors.authenticateColor.cgColor
        return view
    }()
    
    lazy var labelCode: UILabel = {
        let label = UILabel()
        label.text = "Thông tin đơn hàng"
        label.textColor = Colors.mainColor
        label.font = UIFont.systemFont(ofSize: 15, weight: .bold)
        return label
    }()
    
    lazy var labelCreateAt: UILabel = {
        let label = UILabel()
        label.textColor = Colors.normalTextColor
        label.font = UIFont.systemFont(ofSize: 14, weight: .light)
        return label
    }()
    
    // Buttons
    lazy var buttonPaymentNow: UIButton = {
        let button = UIButton()
        button.setTitle("Thanh toán lại ngay", for: .normal)
        button.layer.cornerRadius = 10
        button.backgroundColor = Colors.mainColor
        button.setTitleColor(Colors.white, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .light)
        button.addTarget(self, action: #selector(didTapPaymentNow), for: .touchUpInside)
        button.isHighlighted = true
        return button
    }()
    
    lazy var buttonReBuy: UIButton = {
        let button = UIButton()
        button.setTitle("Mua lại", for: .normal)
        button.layer.cornerRadius = 10
        button.backgroundColor = Colors.mainColor
        button.setTitleColor(Colors.white, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .light)
        button.addTarget(self, action: #selector(didTapReBuy), for: .touchUpInside)
        button.isHighlighted = true
        return button
    }()
    
    lazy var buttonCancel: UIButton = {
        let button = UIButton()
        button.setTitle("Huỷ đơn hàng", for: .normal)
        button.layer.cornerRadius = 10
        button.layer.borderWidth = 0.5
        button.layer.borderColor = Colors.normalTextColor.cgColor
        button.setTitleColor(Colors.normalTextColor, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .light)
        button.addTarget(self, action: #selector(didTapCancel), for: .touchUpInside)
        button.isHighlighted = true
        return button
    }()
    
    lazy var buttonChangePaymentMethod: UIButton = {
        let button = UIButton()
        button.setTitle("Đổi phương thức thanh toán", for: .normal)
        button.layer.cornerRadius = 10
        button.layer.borderWidth = 0.5
        button.layer.borderColor = Colors.normalTextColor.cgColor
        button.setTitleColor(Colors.normalTextColor, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .light)
        button.addTarget(self, action: #selector(didTapChangePaymentMethod), for: .touchUpInside)
        button.isHighlighted = true
        return button
    }()
    
    // MARK: - Properties
    private var presenter: MyOrderDetailPresenter?
    
    private var orderData: OrderData?
    private var orderType: OrderType = .processing([])

    private var cartProvider: DataProvider<OrderDetail> = DataProvider(data: [])
    private var cartDataSource: TableViewDataSource<ProductOrderCell, OrderDetail>!
    
    // MARK: - Life Cycle
    
    convenience init(orderData: OrderData?, orderType: OrderType?) {
        self.init()
        self.orderData = orderData
        self.orderType = orderType ?? .processing([])
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter = MyOrderDetailPresenter(self)
        setupUI()
        setupData()
        setupInfoView()
        setupProductUI()
        setupUIVatAndPriceView()
        setupPaymentMethodAndCodeView()
        setupButtons()
    }
    
    deinit {
        presenter = nil
    }
    
    // MARK: - Setup
    private func setupUI() {
        headerView.title = "Đơn hàng của tôi"
        self.view.addSubview(contentView)
        self.contentView.addSubviews(backgroundImage, scrollView)
        self.scrollView.addSubview(contentStackView)
        contentView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(headerView.frame.height)
            make.bottom.leading.trailing.equalToSuperview()
        }
        
        backgroundImage.snp.makeConstraints { make in
            make.center.equalToSuperview()
            make.width.height.equalTo(300.heightRatio)
        }
        
        scrollView.snp.makeConstraints { make in
            make.top.leading.trailing.equalToSuperview()
            make.bottom.equalToSuperview().inset(20.heightRatio)
        }
        
        contentStackView.snp.makeConstraints { make in
            make.top.bottom.equalToSuperview()
            make.leading.trailing.equalToSuperview()
            make.width.equalTo(375.widthRatio)
        }
        
        setupHeaderTitle()
    }
    
    private func setupHeaderTitle() {
        let stackView = UIStackView(arrangedSubviews: [labelStatusTitle, labelSubTitle])
        stackView.axis = .vertical
        stackView.alignment = .fill
        stackView.distribution = .fill
        stackView.spacing = 5
        
        contentStackView.addArrangedSubview(titleHeaderView)
        titleHeaderView.addSubview(stackView)
        titleHeaderView.setConstraintWidthAndHeight(widthConstant: 375.widthRatio, heightConstant: 55.heightRatio)
        stackView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.trailing.equalToSuperview().inset(15.widthRatio)
        }
    }
    
    //
    private func setupInfoView() {
        contentStackView.addArrangedSubview(addressInfoView)
        addressInfoView.setConstraintWidth(constant: 345.widthRatio)
        
        let iconLocation1 = UIImageView(image: UIImage().getImage(with: "ic_location", and: Bundle(for: AddressCell.self))!)
        iconLocation1.contentMode = .scaleAspectFit
        
        let labelType = UILabel()
        labelType.text = "Hình thức mua hàng"
        labelType.textColor = Colors.authenticateColor
        labelType.font = UIFont.systemFont(ofSize: 13, weight: .light)
        
        let stackType = UIStackView(arrangedSubviews: [iconLocation1, labelType])
        stackType.axis = .horizontal
        stackType.alignment = .fill
        stackType.distribution = .fill
        stackType.spacing = 5
        
        let iconLocation2 = UIImageView(image: UIImage().getImage(with: "ic_location", and: Bundle(for: AddressCell.self))!)
        iconLocation2.contentMode = .scaleAspectFit
        
        let labelTitleAddress = UILabel()
        labelTitleAddress.text = "Địa chỉ nhận hàng"
        labelTitleAddress.textColor = Colors.authenticateColor
        labelTitleAddress.font = UIFont.systemFont(ofSize: 13, weight: .light)
        
        let stackAddress = UIStackView(arrangedSubviews: [iconLocation2, labelTitleAddress])
        stackAddress.axis = .horizontal
        stackAddress.alignment = .fill
        stackAddress.distribution = .fill
        stackAddress.spacing = 5
        
        let stackAddressInfo = UIStackView(arrangedSubviews: [labelName, labelPhone, labelAddress])
        stackAddressInfo.axis = .vertical
        stackAddressInfo.alignment = .fill
        stackAddressInfo.distribution = .fill
        stackAddressInfo.spacing = 5
        
        let stackView = UIStackView(arrangedSubviews: [stackType, labelTypeBuyProduct, stackAddress, stackAddressInfo])
        stackView.axis = .vertical
        stackView.alignment = .fill
        stackView.distribution = .fill
        stackView.spacing = 10.heightRatio
        addressInfoView.addSubview(stackView)
        
        stackView.snp.makeConstraints { make in
            make.top.bottom.equalToSuperview()
            make.leading.trailing.equalToSuperview().inset(5.widthRatio)
        }
        
        stackView.layoutMargins = UIEdgeInsets(top: 10.heightRatio, left: 5, bottom: 10.heightRatio, right: 0)
        stackView.isLayoutMarginsRelativeArrangement = true
        
        iconLocation1.setConstraintWidthAndHeight(widthConstant: 20.heightRatio, heightConstant: 20.heightRatio)
        iconLocation2.setConstraintWidthAndHeight(widthConstant: 20.heightRatio, heightConstant: 20.heightRatio)
    }
    
    //
    private func setupProductUI() {
        contentStackView.addArrangedSubview(productInfoView)
        productInfoView.setConstraintWidth(constant: 345.widthRatio)
        productInfoView.addSubviews(labelProductTitle, productTableView)
        
        labelProductTitle.snp.makeConstraints { make in
            make.top.leading.trailing.equalToSuperview().inset(10.widthRatio)
        }
        
        var height = 30.heightRatio
        if let count = orderData?.OrderDetails?.count {
            if count > 0 {
                height = 30.heightRatio * CGFloat(count)
            }
        }
        
        self.productTableView.snp.updateConstraints { make in
            make.height.equalTo(height)
            make.leading.trailing.bottom.equalToSuperview().inset(10.heightRatio)
            make.top.equalTo(labelProductTitle.snp.bottom).offset(10.heightRatio)
        }
        
        configTableView()
    }
    
    private func configTableView() {
        cartProvider.data = orderData?.OrderDetails ?? []
        
        productTableView.isScrollEnabled = false
        productTableView.alwaysBounceVertical = true
        productTableView.register(cellClass: ProductOrderCell.self)
        
        cartDataSource = TableViewDataSource(dataProvider: cartProvider)
        cartDataSource.configureCell = { [weak self] cell, model, index in
            guard let _ = self else { return }
            cell.bindData(with: model, and: index.row)
            cell.selectionStyle = .none
            cell.backgroundColor = .clear
        }
        
        productTableView.dataSource = cartDataSource
        productTableView.reloadData()
    }
    
    // MARK: - Info Price
    private func setupUIVatAndPriceView() {
        contentStackView.addArrangedSubview(varAndPriceView)
        varAndPriceView.setConstraintWidth(constant: 345.widthRatio)
        varAndPriceView.addSubview(orderInfoView)
        
        orderInfoView.snp.makeConstraints { make in
            make.top.bottom.trailing.leading.equalToSuperview()
        }
        
        orderInfoView.didTapDeliveryTermInfo = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.navigationController?.pushViewController(TermDeliveryViewController(), animated: true)
            }
        }
    }
    
    // MARK: - Payment Method And Code
    private func setupPaymentMethodAndCodeView() {
        contentStackView.addArrangedSubview(paymentMethodView)
        contentStackView.addArrangedSubview(codeView)
        
        paymentMethodView.setConstraintWidth(constant: 345.widthRatio)
        codeView.setConstraintWidth(constant: 345.widthRatio)
        
        let icon = UIImageView(image: UIImage().getImage(with: "ic_card", and: Bundle(for: AddressCell.self))!)
        icon.contentMode = .scaleAspectFit
        
        let labelType = UILabel()
        labelType.text = "Phương thức thanh toán"
        labelType.textColor = Colors.authenticateColor
        labelType.font = UIFont.systemFont(ofSize: 14, weight: .light)
        
        let stackType = UIStackView(arrangedSubviews: [icon, labelType])
        stackType.axis = .horizontal
        stackType.alignment = .fill
        stackType.distribution = .fill
        stackType.spacing = 5.heightRatio
        
        paymentMethodView.addSubviews(stackType, labelPaymentMethod)
        
        stackType.snp.makeConstraints { make in
            make.top.leading.trailing.equalToSuperview().inset(10.heightRatio)
        }
        
        labelPaymentMethod.snp.makeConstraints { make in
            make.leading.equalToSuperview().inset(35.heightRatio)
            make.top.equalTo(stackType.snp.bottom).offset(5.heightRatio)
            make.trailing.bottom.equalToSuperview().inset(10.heightRatio)
        }
        icon.setConstraintWidthAndHeight(widthConstant: 20.heightRatio, heightConstant: 20.heightRatio)
        
        let stackCreateAt = UIStackView(arrangedSubviews: [labelCode, labelCreateAt])
        stackCreateAt.axis = .vertical
        stackCreateAt.alignment = .fill
        stackCreateAt.distribution = .fill
        stackCreateAt.spacing = 10.heightRatio
        codeView.addSubview(stackCreateAt)
        stackCreateAt.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview().inset(10.heightRatio)
        }
    }
    
    //
    private func setupButtons() {
        let stackButtons = UIStackView(arrangedSubviews: [buttonPaymentNow, buttonReBuy, buttonChangePaymentMethod, buttonCancel])
        stackButtons.axis = .vertical
        stackButtons.alignment = .fill
        stackButtons.distribution = .fill
        stackButtons.spacing = 10.heightRatio
        contentStackView.addArrangedSubview(stackButtons)
        
        buttonReBuy.setConstraintWidthAndHeight(widthConstant: 330.widthRatio, heightConstant: 40.heightRatio)
        buttonCancel.setConstraintWidthAndHeight(widthConstant: 330.widthRatio, heightConstant: 40.heightRatio)
        buttonPaymentNow.setConstraintWidthAndHeight(widthConstant: 330.widthRatio, heightConstant: 40.heightRatio)
        buttonChangePaymentMethod.setConstraintWidthAndHeight(widthConstant: 330.widthRatio, heightConstant: 40.heightRatio)
        
        switch orderType {
        case .processing:
            buttonReBuy.isHidden = true
            buttonCancel.isHidden = false

            switch PaymentType.init(rawValue: (self.orderData?.PaymentMethod ?? 1) - 1) {
            case .pickup:
                buttonPaymentNow.isHidden = true
                buttonChangePaymentMethod.isHidden = false
                break
            case .billNamA:
                buttonPaymentNow.isHidden = false
                buttonChangePaymentMethod.isHidden = true
                break
            case .gateWayNamA:
                buttonPaymentNow.isHidden = true
                buttonChangePaymentMethod.isHidden = false
                break
            default:
                break
            }
            
            break
        case .paid:
            buttonReBuy.isHidden = false
            buttonCancel.isHidden = true
            buttonPaymentNow.isHidden = true
            buttonChangePaymentMethod.isHidden = true
            break
        case .beingTranspoter:
            buttonReBuy.isHidden = false
            buttonCancel.isHidden = true
            buttonPaymentNow.isHidden = true
            buttonChangePaymentMethod.isHidden = true
            break
        case .successed:
            buttonReBuy.isHidden = false
            buttonCancel.isHidden = true
            buttonPaymentNow.isHidden = true
            buttonChangePaymentMethod.isHidden = true
            break
        case .canceled:
            buttonReBuy.isHidden = false
            buttonCancel.isHidden = true
            buttonPaymentNow.isHidden = true
            buttonChangePaymentMethod.isHidden = true
            break
        }
    }
    //
    private func setupData() {
        labelStatusTitle.text = self.orderType.title
        labelTypeBuyProduct.text = (self.orderData?.StoreID ?? 1) == 1 ? "Giao tận nơi" : "Nhận theo địa chỉ"
        labelName.text = self.orderData?.ShipName
        labelPhone.text = self.orderData?.Phone
        labelAddress.text = self.orderData?.ShipAddress
        labelPaymentMethod.text = PaymentType.init(rawValue: (self.orderData?.PaymentMethod ?? 1) - 1)?.title
        labelCode.text = "Mã đơn hàng \(self.orderData?.Code ?? "")"
        orderInfoView.setupData(with: self.orderData)
        let dateString = (self.orderData?.CreatedAt ?? "").toDateFormat()
        labelCreateAt.text = dateString
    }
    
    // MARK: - Actions
    
    @objc private func didTapPaymentNow() {
//        if let vc = DoiDep.reviewViewController {
//            var dataOrder = OrderResponse(OrderCode: orderData?.Code, Url: nil, OrderDetails: orderData?.OrderDetails, UserName: UserService.shared.getDataUser().FullName, Phone: UserService.shared.getDataUser().Phone, Message: nil)
//            dataOrder.Voucher = orderData?.Voucher
//            DoiDep.shared.delegate?.onGotoPayment(with: dataOrder.convertObjectToDictionary)
//            self.navigationController?.pushViewController(vc, animated: true)
//        }
    }
    
    @objc private func didTapReBuy() {
        self.navigationController?.pushViewController(HomeDetailViewController(productID: orderData?.OrderDetails?.first?.ProductID, productData: nil), animated: true)
    }
    
    @objc private func didTapCancel() {
        let code = orderData?.Code ?? ""
        self.presenter?.deleteYourOrder(with: code)
    }
    
    @objc private func didTapChangePaymentMethod() {
        
    }
}

// MARK: - Handle Presenter
extension MyOrderDetailViewController: MyOrderDetailView {
    func onDeleteMyOrderSuccess(with message: String?) {
        CommonPopup.showAlertOnlyOk(message ?? "", title: nil) { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
    
    func onDeleteMyOrderFailed(with message: String?) {
        CommonPopup.showAlertOnlyOk("Mã đơn hàng không tồn tại hoặc trạng thái khác Đang xử lý")
    }
}
