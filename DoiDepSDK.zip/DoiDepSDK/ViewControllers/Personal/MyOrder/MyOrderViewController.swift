//
//  MyOrderViewController.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 27/07/2022.
//

import UIKit

class MyOrderViewController: BackNavigationVC {
    
    // MARK: - UI
    
    lazy var backgroundImage: UIImageView = {
        let imageView = UIImageView(image: UIImage().getImage(with: "ic_logo_blur", and: Bundle(for: MyOrderViewController.self)))
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    lazy var contentView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        return view
    }()
    
    lazy var headerOrderTypeView: HeaderOrderTypeView = {
        let view = HeaderOrderTypeView()
        return view
    }()
    
    lazy var tableView: UITableView = {
        let tableView = UITableView()
        tableView.separatorStyle = .none
        return tableView
    }()
    
    // MARK: - Presenter
    private var presenter: MyOrderPresenter?
    
    // MARK: - Properties
    private var orderDatasResponse: [OrderData] = []
    private var orderType: OrderType = .processing([])
    private var orderProvider: DataProvider<OrderData> = DataProvider(data: [])
    private var orderDataSource: TableViewDataSource<MyOrderCell, OrderData>!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter = MyOrderPresenter(self)
        self.showLoading()
    
        setupUI()
        configTableview()
        handleHeaderAction()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.presenter?.getYourOrder(with: UserService.shared.getDataUser().ID ?? -1)
    }
    
    deinit {
        presenter = nil
    }
    
    private func setupUI() {
        headerView.title = "Đơn hàng của tôi"
        self.view.addSubview(contentView)
        
        self.contentView.addSubviews(backgroundImage, headerOrderTypeView, tableView)
        
        contentView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(headerView.frame.height)
            make.bottom.leading.trailing.equalToSuperview()
        }
        
        backgroundImage.snp.makeConstraints { make in
            make.center.equalToSuperview()
            make.width.height.equalTo(300.heightRatio)
        }
        
        headerOrderTypeView.snp.makeConstraints { make in
            make.height.equalTo(50.heightRatio)
            make.top.leading.trailing.equalToSuperview()
        }
        
        tableView.snp.makeConstraints { make in
            make.top.equalTo(headerOrderTypeView.snp.bottom)
            make.bottom.leading.trailing.equalToSuperview()
        }
    }
    
    private func configTableview() {
        orderProvider.data = self.orderType.orderDatas ?? []
        tableView.delegate = self
        tableView.alwaysBounceVertical = true
        tableView.register(cellClass: MyOrderCell.self)
        
        orderDataSource = TableViewDataSource(dataProvider: orderProvider)
        
        orderDataSource.configureCell = { [weak self] cell, model, index in
            guard let self = self else { return }
            cell.bindData(with: model, type: self.orderType)
            cell.selectionStyle = .none
            cell.didReBuy = { 
                DispatchQueue.main.async {
                    self.navigationController?.pushViewController(HomeDetailViewController(productID: model.OrderDetails?.first?.ProductID, productData: nil), animated: true)
                }
            }
        }
        
        tableView.dataSource = orderDataSource
//        tableView.reloadData()
    }
    
    private func handleHeaderAction() {
        headerOrderTypeView.didChange = { [weak self] headerData in
            guard let self = self, let type = headerData?.orderType else { return }
            DispatchQueue.main.async {
                switch type {
                case .processing:
                    self.orderType = .processing(self.orderDatasResponse)
                    break
                case .paid:
                    self.orderType = .paid(self.orderDatasResponse)
                    break
                case .beingTranspoter:
                    self.orderType = .beingTranspoter(self.orderDatasResponse)
                    break
                case .successed:
                    self.orderType = .successed(self.orderDatasResponse)
                    break
                case .canceled:
                    self.orderType = .canceled(self.orderDatasResponse)
                    break
                }
                self.orderProvider.data = self.orderType.orderDatas ?? []
                self.tableView.reloadData()
            }
        }
    }

}

extension MyOrderViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.navigationController?.pushViewController(MyOrderDetailViewController(orderData: self.orderProvider.data[indexPath.row], orderType: self.orderType), animated: true)
    }
}

extension MyOrderViewController: MyOrderView {
    func onReloadMyOrder(with yourOrderDatas: [OrderData]) {
        DispatchQueue.main.async {
            self.hideLoading()
            self.orderDatasResponse = yourOrderDatas
            switch self.orderType {
            case .processing:
                self.orderType = .processing(self.orderDatasResponse)
                break
            case .paid:
                self.orderType = .paid(self.orderDatasResponse)
                break
            case .beingTranspoter:
                self.orderType = .beingTranspoter(self.orderDatasResponse)
                break
            case .successed:
                self.orderType = .successed(self.orderDatasResponse)
                break
            case .canceled:
                self.orderType = .canceled(self.orderDatasResponse)
                break
            }
            self.orderProvider.data = self.orderType.orderDatas ?? []
            self.tableView.reloadData()
        }
    }
}
