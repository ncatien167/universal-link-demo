//
//  ProductCell.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 17/07/2022.
//

import UIKit

class ProductCell: UICollectionViewCell {
    
    lazy var containerView: UIView = {
        let view = UIView()
        view.layer.borderWidth = 0.5
        view.layer.borderColor = Colors.authenticateColor.cgColor
        view.layer.cornerRadius = 5
        return view
    }()
    
    lazy var iconFavorite: UIImageView = {
        let imageView = UIImageView(image: UIImage().getImage(with: "ic_love_red", and: Bundle(for: ProductCell.self))!)
        imageView.isHidden = true
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    lazy var productImageView: UIImageView = {
        let imageView = UIImageView(image: UIImage().getImage(with: "img_empty", and: Bundle(for: ProductCell.self))!)
        imageView.contentMode = .scaleAspectFit
        imageView.layer.masksToBounds = true
        imageView.layer.cornerRadius = 5
        return imageView
    }()
    
    lazy var labelTitle: UILabel = {
        let label = UILabel()
        label.textColor = Colors.authenticateColor
        label.numberOfLines = 0
        label.font = UIFont.systemFont(ofSize: 15, weight: .bold)
        return label
    }()
    
    lazy var labelPrice: UILabel = {
        let label = UILabel()
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 15, weight: .bold)
        return label
    }()
    
    lazy var iconAddToCart: UIImageView = {
        let imageView = UIImageView(image: UIImage().getImage(with: "ic_cart_order", and: Bundle(for: ProductCell.self))!)
        imageView.contentMode = .scaleAspectFit
        imageView.layer.cornerRadius = 5
        imageView.backgroundColor = Colors.customGaryColor
        imageView.layer.masksToBounds = true
        return imageView
    }()
    
    lazy var bottomLineView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        return view
    }()
    
    // MARK: - Properties
    
    var tapAddToCartAction: (()->())?
    
    // MARK: - Flags
    override var isSelected: Bool {
        didSet {
            changeUIWhenSelected()
        }
    }
    
    var isUsingUITopSales: Bool = false {
        didSet {
            
        }
    }
    
    var isUsingFavorite: Bool = false {
        didSet {
            if isUsingFavorite {
                iconFavorite.isHidden = false
            } else {
                iconFavorite.isHidden = true
            }
        }
    }
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupUI()
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        productImageView.image = nil
    }
    
    private func setupUI() {
        self.contentView.addSubview(containerView)
        containerView.snp.makeConstraints { make in
            make.top.bottom.equalToSuperview()
            make.leading.trailing.equalToSuperview()
        }
        
        let stackPrice = UIStackView(arrangedSubviews: [labelPrice, iconAddToCart])
        stackPrice.axis = .vertical
        stackPrice.alignment = .trailing
        stackPrice.distribution = .equalSpacing
        
        let stackViewContent = UIStackView(arrangedSubviews: [iconFavorite, productImageView, labelTitle, stackPrice])
        stackViewContent.axis = .horizontal
        stackViewContent.alignment = .top
        stackViewContent.distribution = .fill
        stackViewContent.spacing = 5
        containerView.addSubviews(stackViewContent)
        
        stackViewContent.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview().inset(10.heightRatio)
            make.height.equalTo(75.widthRatio)
        }
        
        labelTitle.setConstraintWidth(constant: 150.widthRatio)
        stackPrice.setConstraintWidthAndHeight(widthConstant: 95.heightRatio, heightConstant: 55.widthRatio)
        iconFavorite.setConstraintWidthAndHeight(widthConstant: 20.heightRatio, heightConstant: 20.heightRatio)
        productImageView.setConstraintWidthAndHeight(widthConstant: 75.widthRatio, heightConstant: 75.widthRatio)
        iconAddToCart.setConstraintWidthAndHeight(widthConstant: 25.heightRatio, heightConstant: 25.heightRatio)
    }
    
    // MARK: - Bind Data
    func bindDataProduct(with data: ProductData) {
        labelTitle.text = data.Name
        let price = (data.Price ?? 0).formatMoney
        labelPrice.text = price
        if let urlImage = data.Thumbnail {
            productImageView.loadImage(urlString: urlImage, UIImage().getImage(with: "img_empty.png", and: Bundle(for: ProductCell.self))!)
        }
        
    }
    
    // MARK: - Action
    private func changeUIWhenSelected() {
        if isSelected {
            bottomLineView.isHidden = false
        } else {
            bottomLineView.isHidden = true
        }
    }
}
