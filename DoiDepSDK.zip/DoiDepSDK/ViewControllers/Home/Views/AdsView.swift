//
//  AdsView.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 14/08/2022.
//

import UIKit

class AdsView: UIView {
    
    lazy var labelTitle: UILabel = {
        let label = UILabel()
        label.text = "Chương trình ưu đãi"
        label.textColor = Colors.mainColor
        label.font = UIFont.systemFont(ofSize: 14, weight: .bold)
        return label
    }()
    
    lazy var collectionView: UICollectionView = {
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.invalidateLayout()
        
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.backgroundColor = .clear
        return collectionView
    }()
    
    
    // MARK: - Properties
    private var bannerProvider: DataProvider<BannerData> = DataProvider(data: [])
    private var bannerDataSource: CollectionViewDataSource<BannerCell, BannerData>!
    
    var didSelectBanner: ((BannerData?)->())?

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupUI() // <-- Gọi setup UI ở đây
    }
    
    private func setupUI() {
        addSubviews(labelTitle, collectionView)
        
        labelTitle.snp.makeConstraints { make in
            make.top.leading.trailing.equalToSuperview().inset(5.heightRatio)
        }
        
        collectionView.snp.makeConstraints { make in
            make.height.equalTo(100.widthRatio)
            make.top.equalTo(labelTitle.snp.bottom).offset(5.heightRatio)
            make.bottom.leading.trailing.equalToSuperview().inset(5.heightRatio)
        }
        
        configCollectionView()
    }
    
    private func configCollectionView() {
        collectionView.delegate = self
        collectionView.alwaysBounceVertical = true
        collectionView.register(cellClass: BannerCell.self)
        
        bannerDataSource = CollectionViewDataSource(dataProvider: bannerProvider)
        
        bannerDataSource.configureCell = { [weak self] cell, model, index in
            guard let self = self else { return }
            cell.bindDataProduct(with: model)
        }
        
        collectionView.dataSource = bannerDataSource
        collectionView.reloadData()
    }
    
    func setup(with datas: [BannerData]) {
        DispatchQueue.main.async {
            self.labelTitle.text = "Chương trình ưu đãi"
            self.labelTitle.font = UIFont.systemFont(ofSize: 14, weight: .bold)
            self.labelTitle.attributedText = NSAttributedString(string: "Chương trình ưu đãi", attributes: [.underlineStyle: NSUnderlineStyle.single.rawValue])
            self.bannerProvider.data = datas
            self.collectionView.reloadData()
        }
    }
    
    func setupUIForBooking(with datas: [BannerData], title: String) {
        DispatchQueue.main.async {
            self.labelTitle.textColor = Colors.black
            self.labelTitle.text = title
            self.bannerProvider.data = datas
            self.collectionView.reloadData()
        }
    }
}

extension AdsView: UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, UIScrollViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 345.widthRatio, height: 80.heightRatio)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if bannerProvider.data.count == 0 {
            return
        }
        
        didSelectBanner?(bannerProvider.data[indexPath.item])
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        collectionView.contentOffset.y = 0.0
    }
}
