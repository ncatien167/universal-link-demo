//
//  ProductTypeView.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 18/07/2022.
//

import UIKit

class ProductTypeView: UIView {
    
    // MARK: - UI
    lazy var labelTitle: UILabel = {
        let label = UILabel()
        label.text = "Loại"
        label.textAlignment = .left
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 15, weight: .medium)
        return label
    }()
    
    lazy var collectionView: UICollectionView = {
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.backgroundColor = .clear
        
        return collectionView
    }()
    
    // MARK: - Properties
    private var optionGroupProvider: DataProvider<OptionGroups> = DataProvider(data: [])
    private var optionGroupDataSource: CollectionViewDataSource<ProductTypeCell, OptionGroups>!
    private var optionValue: String?
    
    var didTap: ((OptionGroups?)->())?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupUI()
        configCollectionView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Setup
    private func setupUI() {
        self.backgroundColor = Colors.customGaryColor
        
        let view = UIView()
        view.addSubview(collectionView)
        
        let contentStack = UIStackView(arrangedSubviews: [labelTitle, view])
        contentStack.axis = .horizontal
        contentStack.alignment = .fill
        contentStack.distribution = .fill
        contentStack.backgroundColor = .white
        contentStack.spacing = 10.widthRatio
        self.addSubview(contentStack)
        
        labelTitle.setConstraintWidth(constant: 60.widthRatio)
        
        collectionView.snp.makeConstraints { make in
            make.height.equalTo(30.heightRatio)
            make.leading.trailing.equalToSuperview()
            make.centerY.equalToSuperview()
        }
        
        contentStack.snp.makeConstraints { make in
            make.top.equalToSuperview().inset(10.heightRatio)
            make.bottom.leading.trailing.equalToSuperview()
            make.height.equalTo(50.heightRatio)
        }
        
        contentStack.layoutMargins = UIEdgeInsets(top: 0, left: 15.widthRatio, bottom: 0, right: 0)
        contentStack.isLayoutMarginsRelativeArrangement = true
    }
    
    private func configCollectionView() {
        optionGroupProvider.data = []
        collectionView.delegate = self
        collectionView.alwaysBounceVertical = true
        collectionView.register(cellClass: ProductTypeCell.self)
        
        optionGroupDataSource = CollectionViewDataSource(dataProvider: optionGroupProvider)
        
        optionGroupDataSource.configureCell = { [weak self] cell, model, index in
            guard let self = self else { return }
            cell.bindData(with: model, optionValue: self.optionValue)
        }
        
        collectionView.dataSource = optionGroupDataSource
        collectionView.reloadData()
    }
    
    func setup(with optionGroups: [OptionGroups]) {
        self.optionGroupProvider.data = optionGroups
        self.collectionView.reloadData()
    }
    
    func reloadOptionValue(with value: String) {
        self.optionValue = value
        self.collectionView.reloadData()
    }
}

extension ProductTypeView: UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, UIScrollViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if optionGroupProvider.data.count > 0 {
            self.didTap?(optionGroupProvider.data[indexPath.item])
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if self.optionGroupProvider.data.count > 0 {
            let width = self.optionGroupProvider.data.first?.OptionDetails?.first?.OptionValue?.textWidth(font: UIFont.systemFont(ofSize: 15)) ?? 0
            return CGSize(width: width + 30.widthRatio, height: 30.heightRatio)
        }
        
        return CGSize(width: 100.widthRatio, height: 30.heightRatio)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        collectionView.contentOffset.y = 0.0
    }
}
