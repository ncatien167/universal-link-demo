//
//  HeaderProductTypeView.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 17/07/2022.
//

import UIKit
//import SDWebImage

class HeaderProductTypeView: UIView {
    
    // MARK: - UI
    
    lazy var backgoundImageView: UIImageView = {
        let imageView = UIImageView(image: UIImage().getImage(with: "bg_blue_color", and: Bundle(for: HeaderProductTypeView.self))!)
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    lazy var collectionView: UICollectionView = {
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
        
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.backgroundColor = .clear
        
        return collectionView
    }()
    
    // MARK: - Properties
    private var categoryProvider: DataProvider<ProductCategory> = DataProvider(data: [])
    private var categoryDataSource: CollectionViewDataSource<CategoryCell, ProductCategory>!
    
    var didChangeCategory: ((Int?)->())?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupUI()
        configCollectionView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Setup
    private func setupUI() {
        self.addSubviews(backgoundImageView, collectionView)
        
        backgoundImageView.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview()
        }
        
        collectionView.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview()
        }
    }
    
    private func configCollectionView() {
        categoryProvider.data = CommonService.shared.getProductCategories()
        
        collectionView.delegate = self
        collectionView.alwaysBounceVertical = true
        collectionView.register(cellClass: CategoryCell.self)
        
        categoryDataSource = CollectionViewDataSource(dataProvider: categoryProvider)
        
        categoryDataSource.configureCell = { [weak self] cell, model, index in
            guard let _ = self else { return }
            cell.bindDataCategory(with: model)
        }
        
        collectionView.dataSource = categoryDataSource
        collectionView.reloadData()
    }
    
    func reloadData() {
        DispatchQueue.main.async {
            self.categoryProvider.data = CommonService.shared.getProductCategories()
            self.collectionView.reloadData()
        }
    }
}

extension HeaderProductTypeView: UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, UIScrollViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        CommonService.shared.changeSelectedProductCategory(with: indexPath.item)
        self.didChangeCategory?(categoryProvider.data[indexPath.item].ID)
        self.categoryProvider.data = CommonService.shared.getProductCategories()
        self.collectionView.reloadData()
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let text = categoryProvider.data[indexPath.item].Name ?? ""
        let width = self.estimatedFrame(text: text, font: UIFont.systemFont(ofSize: 14)).width
        return CGSize(width: width, height: 50.heightRatio)
    }
    
    func estimatedFrame(text: String, font: UIFont) -> CGRect {
        let size = CGSize(width: 200, height: 1000) // temporary size
        let options = NSStringDrawingOptions.usesFontLeading.union(.usesLineFragmentOrigin)
        return NSString(string: text).boundingRect(with: size,
                                                   options: options,
                                                   attributes: [NSAttributedString.Key.font: font],
                                                   context: nil)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        collectionView.contentOffset.y = 0.0
    }
}
