//
//  BannerCell.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 14/08/2022.
//

import UIKit

class BannerCell: UICollectionViewCell {
    lazy var containerView: UIView = {
        let view = UIView()
        view.layer.borderWidth = 0.5
        view.layer.borderColor = Colors.customGaryColor.cgColor
        view.layer.cornerRadius = 5
        return view
    }()
    
    lazy var productImageView: UIImageView = {
        let imageView = UIImageView(image: UIImage().getImage(with: "img_empty", and: Bundle(for: TopSaleCell.self))!)
        imageView.contentMode = .scaleToFill
        imageView.layer.masksToBounds = true
        imageView.layer.cornerRadius = 5
        return imageView
    }()
    
    // MARK: - Flags

    public override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupUI()
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        productImageView.image = nil
    }
    
    private func setupUI() {
        self.contentView.addSubview(containerView)
        containerView.snp.makeConstraints { make in
            make.top.bottom.equalToSuperview()
            make.leading.trailing.equalToSuperview().inset(10.widthRatio)
        }
        
        containerView.addSubviews(productImageView)
        productImageView.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview()
        }
    }
    
    // MARK: - Bind Data
    func bindDataProduct(with data: BannerData) {
        if let urlImage = data.ImageUrl {
            productImageView.loadImage(urlString: urlImage, UIImage().getImage(with: "img_empty.png", and: Bundle(for: TopSaleCell.self))!)
        }
    }
}
