//
//  HomeViewController.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 15/07/2022.
//

import UIKit

class HomeViewController: AppNavigationVC {

    // MARK: - UI
    
    lazy var backgroundImage: UIImageView = {
        let imageView = UIImageView(image: UIImage().getImage(with: "ic_logo_blur", and: Bundle(for: HomeViewController.self)))
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    lazy var contentView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        return view
    }()
    
    let boundPromosView = UIView()
    
    lazy var promosView: UIView = {
        let view = UIView()
        view.layer.cornerRadius = 10
        view.layer.borderWidth = 0.5
        view.layer.borderColor = Colors.mainColor.cgColor
        return view
    }()
    
    lazy var topSaleView: TopSaleView = {
        let view = TopSaleView()
        return view
    }()
    
    lazy var bannerView: AdsView = {
        let view = AdsView()
        return view
    }()
    
    lazy var headerProductTypeView: HeaderProductTypeView = {
        let view = HeaderProductTypeView()
        return view
    }()
    
    lazy var collectionView: UICollectionView = {
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 10.heightRatio, left: 0, bottom: 20.heightRatio, right: 0)
        layout.estimatedItemSize = CGSize(width: 375.widthRatio, height: 85.heightRatio)
        
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.backgroundColor = .clear
        
        return collectionView
    }()
    
    // MARK: - Presenter
    var presenter: HomePresenter?
    
    // MARK: - Properties
    private var productProvider: DataProvider<ProductData> = DataProvider(data: [])
    private var productDataSource: CollectionViewDataSource<ProductCell, ProductData>!
    
    var didGoToHomeDetail: ((ProductData)->())?
    var didGoToHomeSearch: ((Bool?)->())? // Nếu bằng true sẽ thuộc dạng xem thêm sản phẩm Top Sale
    var didGoToWebView: ((String?)->())?
    var didGoToCart: (()->())?
    var didPopView: (()->())?
    var didGotoLogin: (()->())?
    
    // MARK: - Flags
    private var isSelectedType: Bool = false {
        didSet {
            DispatchQueue.main.async {
                if self.isSelectedType {
                    UIView.animate(withDuration: 0.5, animations: {
                        self.boundPromosView.alpha = 0
                    }) { (_) in
                        self.boundPromosView.isHidden = true
                    }
                    
                } else {
                    UIView.animate(withDuration: 0.5, animations: {
                        self.boundPromosView.isHidden = false
                    }) { (_) in
                        self.boundPromosView.alpha = 1
                    }
                }
            }
        }
    }
    
    // MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter = HomePresenter(self)
        self.showLoading()
        presenter?.requestAllCommonApi()
        
        setupUI()
        configCollectionView()
        handleActionHeader()
        handleHeaderCategoryView()
        handleBannerView()
        handleTopSaleView()
    }
    
    deinit {
        presenter = nil
    }
    
    // MARK: - Setup
    private func setupUI() {
        self.isUsingSearchHeader = true
        self.searchHeaderView.iconLogo.image = UIImage().getImage(with: "ic_close_white", and: Bundle(for: HomeViewController.self))
        self.view.addSubview(contentView)
        self.boundPromosView.addSubview(promosView)
        
        let stackHeader = UIStackView(arrangedSubviews: [boundPromosView, headerProductTypeView])
        stackHeader.axis = .vertical
        stackHeader.alignment = .center
        stackHeader.distribution = .fill
        stackHeader.spacing = 10.heightRatio
        
        self.contentView.addSubviews(backgroundImage, stackHeader, collectionView)
        contentView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(headerView.frame.height)
            make.bottom.leading.trailing.equalToSuperview()
        }
        
        backgroundImage.snp.makeConstraints { make in
            make.center.equalToSuperview()
            make.width.height.equalTo(300.heightRatio)
        }
        
        stackHeader.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview()
            make.top.equalToSuperview()
        }
        
        promosView.snp.makeConstraints { make in
            make.top.equalToSuperview().inset(10.heightRatio)
            make.bottom.trailing.leading.equalToSuperview()
        }
        
        boundPromosView.setConstraintWidthAndHeight(widthConstant: 355.widthRatio, heightConstant: 280.heightRatio)
        headerProductTypeView.setConstraintWidthAndHeight(widthConstant: 375.widthRatio, heightConstant: 50.heightRatio)
        
        collectionView.snp.makeConstraints { make in
            make.top.equalTo(headerProductTypeView.snp.bottom)
            make.bottom.leading.trailing.equalToSuperview()
        }
        
        setupPromosView()
    }
    
    private func setupPromosView() {
        promosView.addSubviews(bannerView, topSaleView)
        bannerView.snp.makeConstraints { make in
            make.width.equalTo(355.widthRatio)
            make.top.equalToSuperview().inset(5.widthRatio)
            make.leading.trailing.equalToSuperview().inset(5.widthRatio)
        }
        
        topSaleView.snp.makeConstraints { make in
            make.top.equalTo(bannerView.snp.bottom).inset(10.widthRatio)
            make.bottom.leading.trailing.equalToSuperview().inset(5.widthRatio)
        }
    }
    
    private func configCollectionView() {
        collectionView.delegate = self
        collectionView.alwaysBounceVertical = true
        collectionView.register(cellClass: ProductCell.self)
        
        productDataSource = CollectionViewDataSource(dataProvider: productProvider)
        
        productDataSource.configureCell = { [weak self] cell, model, index in
            guard let self = self else { return }
            cell.bindDataProduct(with: model)
            cell.tapAddToCartAction = { [weak self] in
                guard let _ = self else { return }
                
            }
        }
        
        collectionView.dataSource = productDataSource
        collectionView.reloadData()
    }
    
    // MARK: - Handle
    
    private func handleBannerView() {
        bannerView.didSelectBanner = { [weak self] banner in
            guard let self = self, let banner = banner else { return }
            self.didGoToWebView?(banner.LinkTo)
        }
    }
    
    private func handleTopSaleView() {
        topSaleView.didTapMore = { [weak self] in
            guard let self = self else { return }
            self.didGoToHomeSearch?(true)
        }
        
        topSaleView.didSelectProduct = { [weak self] productData in
            guard let self = self, let productData = productData else { return }
            self.didGoToHomeDetail?(productData)
        }
    }
    
    // Việc sử dụng closure để gọi qua bên Tab Bar VC để push được view controller
    // Handle sử dụng Header Search
    private func handleActionHeader() {
        self.searchHeaderView.textFieldDidBeginEdit = { [weak self] in
            guard let self = self else { return }
            self.didGoToHomeSearch?(false)
        }
        
        self.searchHeaderView.tapLeft = { [weak self] in
            guard let self = self else { return }
            if self.isSelectedType {
                self.isSelectedType = false
                return
            }
            
            self.didPopView?()
        }
        
        self.searchHeaderView.tapRight = { [weak self] in
            guard let self = self else { return }
            self.didGoToCart?()
        }
    }
    
    private func handleHeaderCategoryView() {
        headerProductTypeView.didChangeCategory = { [weak self] ID in
            guard let self = self, let ID = ID else { return }
            self.isSelectedType = true
            self.handleRequestProductByCategory(with: ID)
        }
    }
    
    // MARK: - Presenter Request
    private func handleRequestProductByCategory(with ID: Int) {
        self.showLoading()
        if ID == -1 { // -1 Được thêm vào bằng code để show mục Phổ biến
            presenter?.requestProductForYou()
        } else {
            presenter?.requestProductByCategory(with: ID)
        }
    }
}

extension HomeViewController: UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        Logger.log(message: "Home Collection View Tapped", event: .debug)
        let productData = productProvider.data[indexPath.item]
        didGoToHomeDetail?(productData)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 375.widthRatio, height: 85.widthRatio)
    }
}

extension HomeViewController: HomeView {
    
    func onReloadProduct(with productsData: [ProductData]) {
        DispatchQueue.main.async {
            self.hideLoading()
            self.productProvider.data = productsData
            self.collectionView.reloadData()
        }
    }
    
    func onCheckAllCommonApiSuccess(with statusToken: Bool) {
        if statusToken {
            DispatchQueue.main.async {
                self.hideLoading()
                CommonPopup.showAlertOnlyOk("Phiên đăng nhập Đôi Dép đã hết hạn", title: "") {
//                    DoiDep.shared.delegate?.onLogOut()
                    CartManager.shared.removeCart()
                    self.didGotoLogin?()
                }
            }
            return
        }
        
        headerProductTypeView.reloadData()
        topSaleView.setup(with: CommonService.shared.getTopProducts())
        bannerView.setup(with: CommonService.shared.getBanners())
        // Bắt đầu call api Product cho mục Phổ biến
        presenter?.requestProductForYou()
    }
}
