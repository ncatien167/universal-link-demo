//
//  HomeDetailViewController.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 17/07/2022.
//

import UIKit

class HomeDetailViewController: BackNavigationVC {

    // MARK: - UI
    
    lazy var labelBadgeNumber: UILabel = {
        let label = UILabel()
        label.isHidden = true
        label.textColor = .white
        label.backgroundColor = .red
        label.layer.cornerRadius = 8.heightRatio
        label.layer.masksToBounds = true
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 12, weight: .bold)
        return label
    }()
    
    lazy var contentView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        return view
    }()
    
    lazy var scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        return scrollView
    }()
    
    lazy var contentStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.alignment = .center
        stackView.distribution = .fill
        stackView.spacing = 10.heightRatio
        return stackView
    }()
    
    lazy var productImage: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    lazy var labelTitle: UILabel = {
        let label = UILabel()
        label.textColor = Colors.authenticateColor
        label.numberOfLines = 0
        label.font = UIFont.systemFont(ofSize: 16, weight: .medium)
        return label
    }()
    
    lazy var iconFavorite: UIImageView = {
        let imageView = UIImageView(image: UIImage().getImage(with: "ic_love_red", and: Bundle(for: HomeDetailViewController.self))!)
        imageView.isHidden = true
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    lazy var labelPrice: UILabel = {
        let label = UILabel()
        label.textColor = Colors.priceColor
        label.numberOfLines = 0
        label.font = UIFont.systemFont(ofSize: 14, weight: .medium)
        return label
    }()
    
    lazy var labelNote: UILabel = {
        let label = UILabel()
        label.text = "(Mô tả)"
        label.textColor = Colors.normalTextColor
        label.numberOfLines = 0
        label.font = UIFont.systemFont(ofSize: 14, weight: .light)
        return label
    }()
    
    lazy var labelDes: UILabel = {
        let label = UILabel()
        label.textColor = .black
        label.numberOfLines = 0
        label.font = UIFont.systemFont(ofSize: 14, weight: .medium)
        return label
    }()
    
    lazy var productTypeView: ProductTypeView = {
        let view = ProductTypeView()
        return view
    }()
    
    lazy var amountCountingView: ProductAmountCountingView = {
        let view = ProductAmountCountingView()
        return view
    }()
    
    lazy var noteView: OrderNoteView = {
        let view = OrderNoteView()
        return view
    }()
    
    lazy var bottomView: UIView = {
        let view = UIView()
        view.backgroundColor = Colors.customGaryColor
        return view
    }()
    
    lazy var labelTotalMoney: UILabel = {
        let label = UILabel()
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        return label
    }()
    
    lazy var addToCartButton: CommonButton = {
        let button = CommonButton()
        button.setup(title: "Thêm vào giỏ", 10)
        button.didTap = { [weak self] in
            guard let self = self else { return }
            self.addToCartAction()
        }
        return button
    }()
    
    // MARK: - Presenter
    var presenter: HomeDetailPresenter?
    
    // MARK: - Properties
    
    private var productData: ProductData?
    private var optionValue: String?
    private var productID: Int?
    // MARK: - Life Cycle
    
    convenience init(productID: Int?, productData: ProductData?) {
        self.init()
        self.productID = productID
        self.productData = productData
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter = HomeDetailPresenter(self)
        self.showLoading()
        presenter?.requestProductDetail(with: productID ?? -1)
        addObsevers()
        setupUI()
        handleSelectOptionView()
        handleTotalAmount()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        handleUpdateItemCartIcon()
    }
    
    deinit {
        presenter = nil
        removeObservers()
    }
    
    // MARK: - Setup

    override func setUpRightBarButton() {
        let viewCustom = UIView()
        let iconCart = UIImageView(image: UIImage().getImage(with: "ic_cart_white", and: Bundle(for: HomeDetailViewController.self)))
        iconCart.contentMode = .scaleAspectFit
        viewCustom.addSubviews(labelBadgeNumber, iconCart)
        iconCart.snp.makeConstraints { make in
            make.top.leading.bottom.equalToSuperview()
            make.width.height.equalTo(25.heightRatio)
            make.trailing.equalToSuperview().inset(10.widthRatio)
        }
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(goToCartAction))
        viewCustom.addGestureRecognizer(tapGesture)
        firstNavItem?.rightBarButtonItem = UIBarButtonItem(customView: viewCustom)
        firstNavItem?.rightBarButtonItem?.tintColor = .white
       
        labelBadgeNumber.snp.makeConstraints { make in
            make.top.equalTo(iconCart.snp.top).offset(-5.heightRatio)
            make.trailing.equalTo(iconCart.snp.trailing).offset(15.heightRatio)
            make.width.height.equalTo(16.heightRatio)
        }
    }
    
    private func setupUI() {
        self.view.addSubviews(contentView, bottomView)
        self.contentView.addSubview(scrollView)
        self.scrollView.addSubview(contentStackView)
        
        contentView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(headerView.frame.height)
            make.leading.trailing.equalToSuperview()
        }
        
        bottomView.snp.makeConstraints { make in
            make.top.equalTo(contentView.snp.bottom)
            make.bottom.trailing.leading.equalToSuperview()
        }
        
        setupBottomView()
        
        scrollView.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview()
        }
        
        contentStackView.snp.makeConstraints { make in
            make.top.bottom.equalToSuperview()
            make.leading.trailing.equalToSuperview()
            make.width.equalTo(375.widthRatio)
        }
        
        contentStackView.addArrangedSubview(productImage)
        setupTitleView()
        contentStackView.addArrangedSubview(labelPrice)
        contentStackView.addArrangedSubview(labelNote)
        contentStackView.addArrangedSubview(labelDes)
        contentStackView.addArrangedSubview(productTypeView)
        contentStackView.addArrangedSubview(amountCountingView)
        contentStackView.addArrangedSubview(noteView)
        
        labelDes.setConstraintWidth(constant: 345.widthRatio)
        noteView.setConstraintWidth(constant: 375.widthRatio)
        labelNote.setConstraintWidth(constant: 345.widthRatio)
        labelPrice.setConstraintWidth(constant: 345.widthRatio)
        productTypeView.setConstraintWidth(constant: 375.widthRatio)
        amountCountingView.setConstraintWidth(constant: 375.widthRatio)
        productImage.setConstraintWidthAndHeight(widthConstant: 345.widthRatio, heightConstant: 150.heightRatio)
    }
    
    private func setupBottomView() {
        let labelTitle = UILabel()
        labelTitle.text = "Tổng số tiền"
        labelTitle.textAlignment = .left
        labelTitle.textColor = Colors.authenticateColor
        labelTitle.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        
        let stackMoney = UIStackView(arrangedSubviews: [labelTitle, labelTotalMoney])
        stackMoney.axis = .horizontal
        stackMoney.alignment = .fill
        stackMoney.distribution = .fill
        bottomView.addSubviews(stackMoney, addToCartButton)
        
        stackMoney.snp.makeConstraints { make in
            make.top.equalToSuperview().inset(10.heightRatio)
            make.leading.trailing.equalToSuperview().inset(15.widthRatio)
        }
        
        addToCartButton.snp.makeConstraints { make in
            make.height.equalTo(35.heightRatio)
            make.top.equalTo(stackMoney.snp.bottom).offset(5)
            make.bottom.equalToSuperview().inset(25.heightRatio)
            make.leading.trailing.equalToSuperview().inset(15.widthRatio)
        }
    }
    
    private func setupTitleView() {
        let stackTitle = UIStackView(arrangedSubviews: [labelTitle, iconFavorite])
        stackTitle.axis = .horizontal
        stackTitle.alignment = .top
        stackTitle.distribution = .fill
        contentStackView.addArrangedSubview(stackTitle)
        stackTitle.setConstraintWidth(constant: 345.widthRatio)
        iconFavorite.setConstraintWidthAndHeight(widthConstant: 30.heightRatio, heightConstant: 30.heightRatio)
    }
    
    private func handleSelectOptionView() {
        productTypeView.didTap = { [weak self] optionGroup in
            guard let self = self else { return }
            DispatchQueue.main.async {
                let vc = SelectOptionGroupViewController(optionGroup: optionGroup)
                vc.didSelect = { [weak self] optionValue in
                    guard let self = self, let optionValue = optionValue else { return }
                    DispatchQueue.main.async {
                        self.optionValue = optionValue
                        self.productTypeView.reloadOptionValue(with: optionValue)
                        self.updateUITotalMoney()
                    }
                }
                self.navigationController?.pushViewController(vc, animated: true)
            }
        }
    }
    
    private func handleUpdateItemCartIcon() {
        // Cập nhật lại số item trong giỏ hàng
        if CartManager.shared.totalQuantity() >= 1 {
            labelBadgeNumber.isHidden = false
            labelBadgeNumber.text = "\(CartManager.shared.totalQuantity())"
        } else {
            labelBadgeNumber.isHidden = true
        }
    }
    
    private func handleTotalAmount() {
        amountCountingView.didPlus = { [weak self] amount in
            guard let self = self else { return }
            self.updateUITotalMoney()
        }
        
        amountCountingView.didMinus = { [weak self] amount in
            guard let self = self else { return }
            self.updateUITotalMoney()
        }
    }
    
    private func updateUITotalMoney() {
        if optionValue == nil {
            let totalMoney = (self.productData?.price() ?? 0) * Double(self.amountCountingView.getAmount())
            labelTotalMoney.text = totalMoney.formatMoney
        } else {
            let totalMoney = (self.productData?.price(with: optionValue ?? "") ?? 0) * Double(self.amountCountingView.getAmount())
            self.labelTotalMoney.text = totalMoney.formatMoney
        }
    }
    
}

// MARK: - Action
extension HomeDetailViewController {
    @objc private func goToCartAction() {
        self.navigationController?.pushViewController(CartViewController(), animated: true)
    }
    
    private func addToCartAction() {
        CartManager.shared.addNewCart(with: productData, ProductID: productData?.ID, GroupID: productData?.getGroupID(with: optionValue ?? ""), Quantity: amountCountingView.getAmount(), Note: noteView.noteTextField.text ?? "")
        
        handleUpdateItemCartIcon()
        
        CommonPopup.showAlertWith(titleOk: "Đặt hàng", titleCancel: "Tiếp tục mua sắm", "Đã thêm sản phẩm vào giỏ hàng") {
            DispatchQueue.main.async {
                self.navigationController?.pushViewController(CartViewController(), animated: true)
            }
        } cancelCompletion: {
            print("CartManager: \(CartManager.shared.getDataCart())")
        }
    }
}

// MARK: - HomeDetailView - Presenter
extension HomeDetailViewController: HomeDetailView {
    func onReloadProductData(with product: ProductData) {
        self.hideLoading()
        productData = product
        optionValue = product.OptionGroups?.first?.OptionDetails?.first?.OptionValue
        
        labelTitle.text = self.productData?.Name
        labelDes.setHTMLFromString(htmlText: product.Description?.stringByDecodingHTMLEntities.htmlDecoded ?? "")
        
        
        if (product.OptionGroups?.count ?? 0) == 0 {
            productTypeView.isHidden = true
            labelPrice.text = self.productData?.price().formatMoney
            let totalMoney = (self.productData?.price() ?? 0) * Double(self.amountCountingView.getAmount())
            labelTotalMoney.text = totalMoney.formatMoney
        } else {
            productTypeView.isHidden = false
            productTypeView.setup(with: product.OptionGroups ?? [])
            
            labelPrice.text = self.productData?.price(with: optionValue ?? "").formatMoney
            let totalMoney = (self.productData?.price(with: optionValue ?? "") ?? 0) * Double(self.amountCountingView.getAmount())
            labelTotalMoney.text = totalMoney.formatMoney
        }
        
        if let urlImage = self.productData?.Thumbnail {
            productImage.loadImage(urlString: urlImage, UIImage().getImage(with: "img_empty", and: Bundle(for: HomeDetailViewController.self))!)
        } else {
            productImage.image = UIImage().getImage(with: "img_empty", and: Bundle(for: HomeDetailViewController.self))!
        }
    }
    
    func onCheckRequestProDuctDetailFailed() {
        
    }
}

extension HomeDetailViewController {
    
    // MARK: - Setup Keyboard
    @objc private func didTapView(gesture: UITapGestureRecognizer) {
        view.endEditing(true)
    }
    
    func addObsevers() {
        let gesture = UITapGestureRecognizer(target: self, action: #selector(didTapView(gesture:)))
        self.view.addGestureRecognizer(gesture)
        NotificationCenter.default.addObserver(forName: UIResponder.keyboardWillShowNotification, object: nil, queue: nil) {
            [weak self] notification in
            guard let self = self else { return }
            self.keybordwillshow(notification: notification)
        }
        NotificationCenter.default.addObserver(forName: UIResponder.keyboardWillHideNotification, object: nil, queue: nil) {
            [weak self] notification in
            guard let self = self else { return }
            self.keybordwillhide(notification: notification)
        }
    }
    
    private func removeObservers() {
        NotificationCenter.default.removeObserver(self)
    }
    
    private func keybordwillshow(notification: Notification) {
        guard let userInfo = notification.userInfo,
              let frame = (userInfo[UIResponder.keyboardFrameEndUserInfoKey]as? NSValue)?.cgRectValue else{
            return
        }
        let contentInset = UIEdgeInsets(top: 0, left: 0, bottom: frame.height + 20, right: 0)
        scrollView.contentInset = contentInset
    }
    
    private func keybordwillhide(notification: Notification) {
        scrollView.contentInset = UIEdgeInsets.zero
    }
}
