//
//  HomeSearchViewController.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 09/08/2022.
//

import UIKit

class HomeSearchViewController: AppNavigationVC {
    
    // MARK: - UI
    
    lazy var contentView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        return view
    }()
    
    lazy var collectionView: UICollectionView = {
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 10.heightRatio, left: 0, bottom: 0, right: 0)
        layout.estimatedItemSize = CGSize(width: 375.widthRatio, height: 85.heightRatio)
        
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.backgroundColor = .clear
        
        return collectionView
    }()
    
    // MARK: - Presenter
    var presenter: HomeSearchPresenter?
    
    // MARK: - Properties
    private var productProvider: DataProvider<ProductData> = DataProvider(data: [])
    private var productDataSource: CollectionViewDataSource<ProductCell, ProductData>!
    
    private var page: Int = 0
    private var workItem: DispatchWorkItem?
    
    // MARK: - Flags
    private var isUsingTopSale = false
    
    // MARK: - Life Cycle
    
    convenience init(isTopSale: Bool) {
        self.init()
        self.isUsingTopSale = isTopSale
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter = HomeSearchPresenter(self)
        presenter?.requestSearch(with: "", and: 0)
        
        setupUI()
        handleActionHeader()
        configCollectionView()
        handleSearchTextField()
    }
    
    deinit {
        presenter = nil
    }
    
    // MARK: - Setup
    private func setupUI() {
        self.isUsingSearchHeader = true
        self.view.addSubview(contentView)
        
        self.contentView.addSubviews(collectionView)
        contentView.snp.makeConstraints { make in
            make.top.equalTo(headerView.snp.bottom)
            make.bottom.leading.trailing.equalToSuperview()
        }
        
        collectionView.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview()
        }
        
        if isUsingTopSale {
            self.searchHeaderView.searchTextField.text = "Sản phẩm bán chạy"
            self.searchHeaderView.searchTextField.isUserInteractionEnabled = false
        }
    }
    
    private func configCollectionView() {
        collectionView.delegate = self
        collectionView.alwaysBounceVertical = true
        collectionView.register(cellClass: ProductCell.self)
        
        productDataSource = CollectionViewDataSource(dataProvider: productProvider)
        
        productDataSource.configureCell = { [weak self] cell, model, index in
            guard let self = self else { return }
            cell.bindDataProduct(with: model)
            cell.tapAddToCartAction = { [weak self] in
                guard let self = self else { return }
                
            }
        }
        
        productDataSource.loadMore = { [weak self] in
            guard let self = self else { return }
            self.page += 1
            self.performSearch(with: self.page)
        }
        
        collectionView.dataSource = productDataSource
        collectionView.reloadData()
    }
    
    // MARK: - Handle
    
    private func handleSearchTextField() {
        searchHeaderView.textFieldEditingChanged = { [weak self] in
            guard let self = self else { return }
            self.handleRequestProductByCategory(with: self.page)
        }

        searchHeaderView.textFieldDidBeginEdit = { [weak self] in
            guard let _ = self else { return }
            
        }
        
        searchHeaderView.textFieldDidEndEdit = { [weak self] in
            guard let self = self, let text = self.searchHeaderView.searchTextField.text else { return }
            if text == "" {
                self.presenter?.requestSearch(with: "", and: 0)
            }
        }
    }
    
    // MARK: - Presenter Request
    private func handleRequestProductByCategory(with page: Int) {
        guard let query = self.searchHeaderView.searchTextField.text else { return }
        
        // Cancel any outstanding search
        self.workItem?.cancel()
        
        guard query.count >= 1 else {
            return
        }
        
        // Set up a DispatchWorkItem to perform the search
        let workItem = DispatchWorkItem { [weak self] in
            self?.performSearch(with: page)
        }
        
        // Run this block after 0.5 seconds
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5, execute: workItem)
        
        // Keep a reference to it so it can be cancelled
        self.workItem = workItem
    }
    
    func performSearch(with page: Int) {
        guard let query = self.searchHeaderView.searchTextField.text else { return }
        showLoading()
        presenter?.requestSearch(with: query, and: page)
    }
    
    // MARK: - Action
    // Việc sử dụng closure để gọi qua bên Tab Bar VC để push được view controller
    private func handleActionHeader() {
        self.searchHeaderView.iconCart.isHidden = true
        self.searchHeaderView.tapLeft = { [weak self] in
            guard let self = self else { return }
            self.navigationController?.popViewController(animated: true)
        }
    }
}

extension HomeSearchViewController: UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        if isUsingTopSale {
            return
        }
        productDataSource.loadMoreIfNeeded(at: indexPath.row)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        Logger.log(message: "Search Collection View Tapped", event: .debug)
        let productData = productProvider.data[indexPath.item]
        self.navigationController?.pushViewController(HomeDetailViewController(productID: productData.ID, productData: productData), animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 375.widthRatio, height: 85.widthRatio)
    }
}

extension HomeSearchViewController: HomeSearchView {
    func onReloadProduct(with productsData: [ProductData], and totals: Int) {
        DispatchQueue.main.async {
            self.hideLoading()
            
            if self.page == 0 {
                self.productProvider.data = productsData
            } else {
                self.productProvider.data.append(contentsOf: productsData)
            }

            self.productDataSource.isFetching = false
            let isReachedLastItem = (totals == self.productProvider.data.count)
            self.productDataSource.isReachedLastItem = isReachedLastItem
            self.collectionView.reloadData()
        }
    }
}
