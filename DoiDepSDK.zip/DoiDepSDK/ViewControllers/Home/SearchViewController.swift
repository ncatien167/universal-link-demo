//
//  SearchViewController.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 19/07/2022.
//

import UIKit

class SearchViewController: AppNavigationVC {
    
    // MARK: - UI
    
    lazy var contentView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        return view
    }()
    
    lazy var collectionView: UICollectionView = {
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 10.heightRatio, left: 0, bottom: 0, right: 0)
        layout.estimatedItemSize = CGSize(width: 375.widthRatio, height: 85.heightRatio)
        
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.backgroundColor = .clear
        
        return collectionView
    }()
    
    // MARK: - Presenter
    var presenter: HomePresenter?
    
    // MARK: - Properties
    private var productProvider: DataProvider<ProductData> = DataProvider(data: [])
    private var productDataSource: CollectionViewDataSource<ProductCell, ProductData>!
    
    private var searchTimer: Timer?
    private var workItem: DispatchWorkItem?
    
    // MARK: - Flags
    
    // MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter = HomePresenter(self)
        presenter?.requestAllCommonApi()
        
        setupUI()
        configCollectionView()
        handleSearchTextField()
    }
    
    deinit {
        presenter = nil
    }
    
    // MARK: - Setup
    private func setupUI() {
        self.view.addSubview(contentView)
        
        self.contentView.addSubviews(collectionView)
        contentView.snp.makeConstraints { make in
            make.top.equalTo(headerView.snp.bottom)
            make.bottom.leading.trailing.equalToSuperview()
        }
        
        collectionView.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview()
        }
    }
    
    private func configCollectionView() {
        collectionView.delegate = self
        collectionView.alwaysBounceVertical = true
        collectionView.register(cellClass: ProductCell.self)
        
        productDataSource = CollectionViewDataSource(dataProvider: productProvider)
        
        productDataSource.configureCell = { [weak self] cell, model, index in
            guard let self = self else { return }
            cell.bindDataProduct(with: model)
            cell.tapAddToCartAction = { [weak self] in
                guard let self = self else { return }
                
            }
        }
        
        collectionView.dataSource = productDataSource
        collectionView.reloadData()
    }
    
    // MARK: - Handle
    
    private func handleSearchTextField() {
        searchHeaderView.textFieldEditingChanged = { [weak self] in
            guard let self = self, let text = self.searchHeaderView.searchTextField.text else { return }
            self.handleRequestProductByCategory(with: text)
        }

        searchHeaderView.textFieldDidBeginEdit = { [weak self] in
            guard let self = self else { return }
            
        }
        
        searchHeaderView.textFieldDidEndEdit = { [weak self] in
            guard let self = self else { return }
            
        }
    }
    
    // MARK: - Presenter Request
    private func handleRequestProductByCategory(with query: String) {
        // Cancel any outstanding search
        self.workItem?.cancel()
        
        guard query.count >= 1 else {
            return
        }
        
        // Set up a DispatchWorkItem to perform the search
        let workItem = DispatchWorkItem { [weak self] in
            self?.performSearch(query)
        }
        
        // Run this block after 0.5 seconds
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: workItem)
        
        // Keep a reference to it so it can be cancelled
        self.workItem = workItem
    }
    
    func performSearch(_ text: String) {
        
    }
}

extension SearchViewController: UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        Logger.log(message: "Search Collection View Tapped", event: .debug)
        let productData = productProvider.data[indexPath.item]
        self.navigationController?.pushViewController(HomeDetailViewController(productID: productData.ID, productData: productData), animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 375.widthRatio, height: 85.widthRatio)
    }
}

extension SearchViewController: HomeView {
    
    func onReloadProduct(with productsData: [ProductData]) {
        DispatchQueue.main.async {
            self.productProvider.data = productsData
            self.collectionView.reloadData()
        }
    }
    
    func onCheckAllCommonApiSuccess(with statusToken: Bool) {
        
    }
}
