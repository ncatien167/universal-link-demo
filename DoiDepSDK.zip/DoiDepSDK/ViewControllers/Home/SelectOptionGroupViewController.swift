//
//  SelectOptionGroupViewController.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 18/07/2022.
//

import UIKit

class SelectOptionGroupViewController: BackNavigationVC {

    lazy var tableView: UITableView = {
        let tableView = UITableView()
        tableView.separatorColor = Colors.authenticateColor
        return tableView
    }()
    
    // MARK: - Properties
    private var optionDetailsProvider: DataProvider<Details> = DataProvider(data: [])
    private var optionDetailsDataSource: TableViewDataSource<UITableViewCell, Details>!
    
    private var optionGroup: OptionGroups?
    
    var didSelect: ((String?)->())?
    
    // MARK: - Flags
    
    // MARK: - Life Cycle
    
    convenience init(optionGroup: OptionGroups?) {
        self.init()
        self.optionGroup = optionGroup
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
        configTableview()
    }
    
    // MARK: - Setup
    private func setupUI() {
        self.view.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.top.equalTo(headerView.snp.bottom)
            make.bottom.leading.trailing.equalToSuperview()
        }
    }
    
    private func configTableview() {
        optionDetailsProvider.data = optionGroup?.OptionDetails ?? []
        tableView.delegate = self
        tableView.alwaysBounceVertical = true
        tableView.register(cellClass: UITableViewCell.self)
        
        optionDetailsDataSource = TableViewDataSource(dataProvider: optionDetailsProvider)
        
        optionDetailsDataSource.configureCell = { [weak self] cell, model, index in
            guard let _ = self else { return }
            cell.textLabel?.text = model.OptionValue
            cell.textLabel?.font = UIFont.systemFont(ofSize: 15, weight: .bold)
            cell.textLabel?.textColor = Colors.authenticateColor
            cell.separatorInset = UIEdgeInsets(top: 0, left: 15.widthRatio, bottom: 0, right: 15.widthRatio)
        }
        
        tableView.dataSource = optionDetailsDataSource
        tableView.reloadData()
    }

}

extension SelectOptionGroupViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        didSelect?(optionDetailsProvider.data[indexPath.row].OptionValue)
    }
}
