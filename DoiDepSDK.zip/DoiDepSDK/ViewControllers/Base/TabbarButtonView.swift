//
//  TabbarButtonView.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 19/07/2022.
//

import UIKit

class TabbarButtonView: UIView, UIGestureRecognizerDelegate {
    
    lazy var firstView: ImageTabbarButtonView = {
        let view = ImageTabbarButtonView()
        view.setup(with: UIImage().getImage(with: "ic_buy_item_focus", and: Bundle(for: TabbarButtonView.self))!, and: "Đặt hàng")
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isUserInteractionEnabled = true
        view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(didTapFirstView)))
        return view
    }()
    
    lazy var secondView: ImageTabbarButtonView = {
        let view = ImageTabbarButtonView()
        view.setup(with: UIImage().getImage(with: "ic_booking_home", and: Bundle(for: TabbarButtonView.self))!, and: "Đặt phòng")
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isUserInteractionEnabled = true
        view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(didTapSecondView)))
        return view
    }()
    
    lazy var thirdView: ImageTabbarButtonView = {
        let view = ImageTabbarButtonView()
        view.setup(with: UIImage().getImage(with: "ic_personal_forcus", and: Bundle(for: TabbarButtonView.self))!, and: "Cá nhân")
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isUserInteractionEnabled = true
        view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(didTapThirdView)))
        return view
    }()
    
    lazy var contentStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.distribution = .fillEqually
        stackView.alignment = .center
        stackView.axis = .horizontal
        stackView.spacing = 0
        return stackView
    }()
    
    lazy var imageBackground: UIImageView = {
        let imageView = UIImageView(image: UIImage().getImage(with: "bg_bottom_bar", and: Bundle(for: TabbarButtonView.self))!)
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    var didTapFirst: (()->())?
    var didTapSecond: (()->())?
    var didTapThird: (()->())?
    
    // MARK: - INIT
    override init(frame: CGRect) {
        super.init(frame: frame)
        initLayout()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    // MARK: - SETUP
    
    private func initLayout() {
        self.addSubviews(imageBackground, firstView, secondView, contentStackView)
        imageBackground.snp.makeConstraints { make in
            make.bottom.leading.trailing.equalToSuperview()
            make.height.equalTo(70.heightRatio)
        }
        didTapFirstView()
        
        // Setup Constraints
        contentStackView.snp.makeConstraints { make in
            make.top.leading.trailing.equalToSuperview()
            make.bottom.equalToSuperview().inset(20.heightRatio)
        }
        
        // Setup StackView Arrange SubView
        
        contentStackView.addArrangedSubview(firstView)
        contentStackView.addArrangedSubview(secondView)
        contentStackView.addArrangedSubview(thirdView)
        
    }
    
    @objc private func didTapFirstView() {
        firstView.settingSelect = true
        secondView.settingSelect = false
        thirdView.settingSelect = false
        didTapFirst?()
    }
    
    @objc private func didTapSecondView() {
        didTapSecond?()
    }
    
    @objc private func didTapThirdView() {
        firstView.settingSelect = false
        secondView.settingSelect = false
        thirdView.settingSelect = true
        
        didTapThird?()
    }
}

// MARK: Dựng UI button tabbar

class ImageTabbarButtonView: UIView {
    
    lazy var viewContainIcon: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.clear
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    lazy var viewCornor: UIView = {
        let view = UIView()
        layer.shadowColor = Colors.black.cgColor
        layer.shadowOffset = CGSize(width: 8, height: 8)
        layer.shadowOpacity = 0
        layer.shadowRadius = 10.0
        
        view.layer.cornerRadius = 22.widthRatioIphoneX
        view.layer.masksToBounds = true
        view.backgroundColor = UIColor.clear
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    lazy var iconImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.changeToColor(Colors.white)
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()
    
    lazy var iconImageSelectView: UIImageView = {
        let imageView = UIImageView()
        imageView.changeToColor(Colors.mainColor)
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()
    
    lazy var labelInfo: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.numberOfLines = 0
        label.textColor = Colors.white
        label.font = UIFont.systemFont(ofSize: 15, weight: .bold)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    lazy var contentStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.alignment = .fill
        stackView.distribution = .fill
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()
    
    var settingSelect: Bool = false {
        didSet {
            if settingSelect {
                layer.shadowOpacity = 0.25
                viewCornor.alpha = 0.4
                viewCornor.layer.borderWidth = 0.5
                viewCornor.backgroundColor = Colors.white
                viewCornor.layer.borderColor = Colors.colorSilverGround.cgColor
                
                iconImageView.isHidden = true
                iconImageSelectView.isHidden = false
                iconImageView.changeToColor(Colors.white)
                labelInfo.font = UIFont.systemFont(ofSize: 15, weight: .bold)
            } else {
                layer.shadowOpacity = 0
                viewCornor.layer.borderWidth = 0
                viewCornor.backgroundColor = UIColor.clear

                iconImageSelectView.isHidden = true
                iconImageView.isHidden = false
                iconImageView.changeToColor(Colors.white)
                
                labelInfo.font = UIFont.systemFont(ofSize: 15, weight: .bold)
            }
        }
    }
    
    private var imageItem: UIImage?
    
    // MARK: - INIT
    override init(frame: CGRect) {
        super.init(frame: frame)
        initLayout()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    // MARK: - SETUP
    
    private func initLayout() {
        self.addSubview(contentStackView)
        self.addSubview(iconImageView)
        self.addSubview(viewCornor)
        self.addSubview(iconImageSelectView)
        iconImageSelectView.isHidden = true
        
        contentStackView.addArrangedSubview(viewContainIcon)
        contentStackView.addArrangedSubview(labelInfo)
        
        // Setup Constraints
        
        NSLayoutConstraint.activate([
            viewContainIcon.widthAnchor.constraint(equalToConstant: 120.widthRatio),
            viewContainIcon.heightAnchor.constraint(equalToConstant: 50.widthRatio),
            
            viewCornor.widthAnchor.constraint(equalToConstant: 44.widthRatio),
            viewCornor.heightAnchor.constraint(equalToConstant: 44.widthRatio),
            viewCornor.topAnchor.constraint(equalTo: self.topAnchor),
            viewCornor.centerXAnchor.constraint(equalTo: self.centerXAnchor),
            
            iconImageView.widthAnchor.constraint(equalToConstant: 25.heightRatio),
            iconImageView.heightAnchor.constraint(equalToConstant: 25.heightRatio),
            iconImageView.centerXAnchor.constraint(equalTo: viewContainIcon.centerXAnchor, constant: 0),
            iconImageView.centerYAnchor.constraint(equalTo: viewContainIcon.centerYAnchor, constant: 0),
            
            iconImageSelectView.widthAnchor.constraint(equalToConstant: 25.heightRatio),
            iconImageSelectView.heightAnchor.constraint(equalToConstant: 25.heightRatio),
            iconImageSelectView.centerXAnchor.constraint(equalTo: viewCornor.centerXAnchor, constant: 0),
            iconImageSelectView.centerYAnchor.constraint(equalTo: viewCornor.centerYAnchor, constant: 0),
            
            contentStackView.topAnchor.constraint(equalTo: self.topAnchor, constant: 10.heightRatio),
            contentStackView.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: 0),
            contentStackView.centerXAnchor.constraint(equalTo: self.centerXAnchor),
        ])
    }
    
    // Setup Image and Text Info
    func setup(with image: UIImage, and textInfo: String) {
        imageItem = image
        iconImageView.image = image
        iconImageSelectView.image = image
//        iconImageSelectView.changeToColor(Colors.mainColor)
//        iconImageView.changeToColor(AppTheme.shared.colorWhiteOrBlueBg())
        labelInfo.text = textInfo
    }
    
}
