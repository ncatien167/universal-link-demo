//
//  BackNavigationVC.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 15/07/2022.
//

import UIKit

class BackNavigationVC: AppNavigationVC {
    
    override func setUpLeftBarButton() {
        let backButtonItem = UIBarButtonItem(image: UIImage().getImage(with: "ic_arrow_left", and: Bundle(for: BackNavigationVC.self))!, style: .plain, target: self, action: #selector(self.backAction))
        firstNavItem?.leftBarButtonItem = backButtonItem
        firstNavItem?.leftBarButtonItem?.tintColor = .white
    }
    
    //MARK: - ACTION
    
    @objc func backAction() {
        navigationController?.popViewController(animated: true)
    }

}

