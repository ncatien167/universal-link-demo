//
//  AppNavigationVC.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 15/07/2022.
//

import UIKit

class AppNavigationVC: UIViewController {
    
    lazy var backgroundImageView: UIImageView = {
        let imageView = UIImageView(image: UIImage().getImage(with: "bg_blue_color", and: Bundle(for: AppNavigationVC.self))!)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    //viewLockScreen
    let viewLockScreen = UIView()
    
    // Show/hide custom navigation bar
    var hiddenHeaderView = false
    
    var navTintColor: UIColor {
        return UIColor.white
    }
    var navFont: UIFont {
        return UIFont.systemFont(ofSize: 18)
    }
    
    var firstNavItem: UINavigationItem? {
        return headerView.navigationBar.items?.first
    }
    
    var allowSwipeBack: Bool {
        return true
    }
    
    let screenWidth = UIScreen.main.bounds.width
    let screenHeight = UIScreen.main.bounds.height
    
    // Init header view
    var topPadding: CGFloat = 0
    var headerBarHeight: CGFloat = NAV_BAR_HEIGHT + STATUS_BAR_HEIGHT
    
    lazy var headerView: HeaderView = {
        headerBarHeight = NAV_BAR_HEIGHT + STATUS_BAR_HEIGHT
        let screen: CGRect = UIScreen.main.bounds
        if #available(iOS 11.0, *) {
            if let window = UIApplication.shared.keyWindow {
                let safeAreaTopInset = window.safeAreaInsets.top
                if safeAreaTopInset > 0 {
                    headerBarHeight += (safeAreaTopInset - STATUS_BAR_HEIGHT)
                    self.topPadding = safeAreaTopInset
                }
            }
        }
        
        let headerBar = HeaderView(frame: CGRect(x: 0, y: 0, width: screen.size.width, height: headerBarHeight))
        headerBar.showBottomUnderline = false
        headerBar.backgroundColor = .clear
        headerBar.navigationBar.tintColor = navTintColor
        headerBar.navigationBar.titleTextAttributes = [NSAttributedString.Key.font: navFont, NSAttributedString.Key.foregroundColor: navTintColor]

        return headerBar
        
    }()
    
    lazy var searchHeaderView: SearchHeaderView = {
        headerBarHeight = NAV_BAR_HEIGHT + STATUS_BAR_HEIGHT
        let screen: CGRect = UIScreen.main.bounds
        if #available(iOS 11.0, *) {
            if let window = UIApplication.shared.keyWindow {
                let safeAreaTopInset = window.safeAreaInsets.top
                if safeAreaTopInset > 0 {
                    headerBarHeight += (safeAreaTopInset - STATUS_BAR_HEIGHT)
                    self.topPadding = safeAreaTopInset
                }
            }
        }
        
        let headerBar = SearchHeaderView(frame: CGRect(x: 0, y: 0, width: screen.size.width, height: headerBarHeight))
        headerBar.backgroundColor = .clear
        headerBar.isHidden = true
        return headerBar
    }()
    
    // MARK: - Flags
    var isUsingSearchHeader: Bool = false {
        didSet {
            if isUsingSearchHeader {
                self.headerView.isHidden = true
                self.searchHeaderView.isHidden = false
            } else {
                self.headerView.isHidden = false
                self.searchHeaderView.isHidden = true
            }
        }
    }
    
    //MARK: - LIFECYCLE
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        navigationController?.isNavigationBarHidden = true
        
        guard !hiddenHeaderView else { return }
        setupUIAppnNav()
        setUpLeftBarButton()
        setUpRightBarButton()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
        //Enable swipe back when hidden navigation bar
        navigationController?.interactivePopGestureRecognizer?.delegate = self
        
    }
    
    func setUpLeftBarButton() {}
    func setUpRightBarButton() {}

    private func setupUIAppnNav() {
        view.addSubviews(backgroundImageView, headerView, searchHeaderView)
        
        backgroundImageView.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview()
        }
    }
    
    func showLoading() {
        IHProgressHUD.show()
        lockScreen()
    }
    
    func hideLoading() {
        IHProgressHUD.dismiss()
        unlockScreen()
    }

    private func unlockScreen() {
         DispatchQueue.main.async {
              self.view.isUserInteractionEnabled = true
              self.view.isUserInteractionEnabled = true
              self.viewLockScreen.removeFromSuperview()
         }
    }
    
    private func lockScreen() {
         self.viewLockScreen.frame = CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight)
         viewLockScreen.backgroundColor = .clear
         viewLockScreen.isUserInteractionEnabled = false
         view.isUserInteractionEnabled = false
         self.view.addSubview(viewLockScreen)
    }
}

//MARK: - GESTURE DELEGATE

extension AppNavigationVC: UIGestureRecognizerDelegate{
    
    ///Prevent side effects, only allow swipe back when viewControllers stack > 1
    func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
        guard let navigationController = navigationController else { return false }
        return navigationController.viewControllers.count > 1 && allowSwipeBack
    }
    
}
