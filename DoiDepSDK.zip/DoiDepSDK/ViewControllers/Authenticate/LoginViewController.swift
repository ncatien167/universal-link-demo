//
//  LoginViewController.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 15/07/2022.
//

import UIKit

class LoginViewController: AppNavigationVC {

    // MARK: - UI INIT
    lazy var mainIconImageView: UIImageView = {
        let imageView = UIImageView(image: UIImage().getImage(with: "logo_white_notagline", and: Bundle(for: LoginViewController.self))!)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    lazy var contentLoginView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 10
        return view
    }()
    
    lazy var usernameTextfield: InputView = {
        let inputView = InputView()
        inputView.setup(placeholder: "SDT hoặc Email")
        inputView.textField.text = "0906687403"
        return inputView
    }()
    
    lazy var passwordTextfield: InputView = {
        let inputView = InputView()
        inputView.setup(placeholder: "Mật khẩu")
        inputView.textField.isSecureTextEntry = true
        inputView.textField.text = "Nab@123"
        return inputView
    }()
    
    lazy var labelError: UILabel = {
        let label = UILabel()
        label.isHidden = true
        label.textColor = .red
        label.numberOfLines = 0
        label.font = UIFont.systemFont(ofSize: 14, weight: .light)
        return label
    }()
    
    lazy var buttonLogin: CommonButton = {
        let button = CommonButton()
        button.setup(title: "Đăng nhập".uppercased(), 5)
        button.didTap = { [weak self] in
            guard let self = self else { return }
            self.didTapLoginButton()
        }
        return button
    }()
    
    lazy var buttonClose: UIButton = {
        let button = UIButton()
        button.addTarget(self, action: #selector(didTapClose), for: .touchUpInside)
        button.setImage(UIImage().getImage(with: "ic_close_white", and: Bundle(for: LoginViewController.self))!, for: .normal)
        return button
    }()
    
    lazy var buttonForgotPassword: UIButton = {
        let button = UIButton()
        button.setTitle("Quên mật khẩu?", for: .normal)
        button.setTitleColor(Colors.authenticateColor, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .light)
        button.addTarget(self, action: #selector(didTapForgotPassword), for: .touchUpInside)
        return button
    }()
    
    lazy var buttonSignUp: UIButton = {
        let button = UIButton()
        button.setTitle("Đăng ký", for: .normal)
        button.setTitleColor(Colors.authenticateColor, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .light)
        button.addTarget(self, action: #selector(didTapSignUp), for: .touchUpInside)
        return button
    }()
    
    // MARK: - Presenter
    
    var presenter: LoginPresenter?
    
    // MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        presenter = LoginPresenter(self)
        setupUI()
    }
    
    deinit {
        presenter = nil
    }
    
    private func setupUI() {
        self.headerView.title = ""
        self.view.addSubviews(mainIconImageView, contentLoginView, buttonClose)
        mainIconImageView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(headerView.snp.bottom)
            make.width.height.equalTo(120.widthRatio)
        }
        
        contentLoginView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.width.equalTo(300.widthRatio)
            make.top.equalTo(mainIconImageView.snp.bottom).offset(50.heightRatio)
        }
        
        buttonClose.snp.makeConstraints { make in
            make.top.equalToSuperview().inset(50.heightRatio)
            make.trailing.equalToSuperview().inset(25.widthRatio)
            make.width.height.equalTo(35.heightRatio)
        }
        
        let contentLoginStackView = UIStackView(arrangedSubviews: [usernameTextfield, passwordTextfield, labelError, buttonLogin, buttonSignUp])
        contentLoginStackView.alignment = .center
        contentLoginStackView.distribution = .equalSpacing
        contentLoginStackView.axis = .vertical
        contentLoginStackView.spacing = 10.heightRatio
        
        let stackButtons = UIStackView(arrangedSubviews: [buttonForgotPassword, buttonSignUp])
        stackButtons.axis = .horizontal
        stackButtons.alignment = .center
        stackButtons.distribution = .fillEqually
        stackButtons.spacing = 10
        
        contentLoginView.addSubviews(contentLoginStackView, stackButtons)
        
        contentLoginStackView.snp.makeConstraints { make in
            make.top.leading.equalToSuperview().offset(20.widthRatio)
            make.trailing.equalToSuperview().offset(-20.widthRatio)
        }
        
        stackButtons.snp.makeConstraints { make in
            make.top.equalTo(contentLoginStackView.snp.bottom).offset(10.heightRatio)
            make.leading.equalToSuperview().inset(10.widthRatio)
            make.trailing.equalToSuperview().inset(10.widthRatio)
            make.bottom.equalToSuperview().inset(10.heightRatio)
        }
        
        labelError.setConstraintWidth(constant: 250.widthRatio)
        usernameTextfield.setConstraintWidthAndHeight(widthConstant: 250.widthRatio, heightConstant: 40.heightRatio)
        passwordTextfield.setConstraintWidthAndHeight(widthConstant: 250.widthRatio, heightConstant: 40.heightRatio)
        buttonLogin.setConstraintWidthAndHeight(widthConstant: 150.widthRatio, heightConstant: 30.heightRatio)
        
        let labelNote = UILabel()
        labelNote.text = "* Quý khách chỉ cần đăng nhập lần đầu tiên, hệ thống sẽ tự động đăng nhập cho các lần tiếp theo.\n\n* Đây là dịch vụ hợp tác giữa Ngân hàng TMCP Nam Á (Nam A Bank) và Công ty CP Sandals (Đôi Dép). Thông tin dịch vụ được cung cấp bởi Đôi Dép. Mọi vấn đề liên quan đến hàng hóa, dịch vụ sẽ do Đôi Dép chịu trách nhiệm."
        labelNote.textColor = .white
        labelNote.textAlignment = .left
        labelNote.numberOfLines = 0
        labelNote.font = UIFont.italicSystemFont(ofSize: 14)
        self.view.addSubviews(labelNote)
        
        labelNote.snp.makeConstraints { make in
            make.top.equalTo(contentLoginView.snp.bottom).offset(30.heightRatio)
            make.centerX.equalToSuperview()
            make.width.equalTo(330.widthRatio)
        }
    }
    
    // MARK: - Action
    
    private func didTapLoginButton() {
        guard let username = usernameTextfield.textField.text, let password = passwordTextfield.textField.text else {
            return
        }
        
        if username.isEmpty || username == "" || username.count == 0 {
            self.labelError.text = "Vui lòng nhập Số điện thoại"
            self.labelError.isHidden = false
            return
        }
        
        if password.isEmpty || password == "" || password.count == 0 {
            self.labelError.text = "Vui lòng nhập mật khẩu"
            self.labelError.isHidden = false
            return
        }
        
        self.labelError.isHidden = true
        self.showLoading()
        presenter?.requestLogin(with: username, and: password)
    }
    
    @objc private func didTapClose() {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc private func didTapSignUp() {
        self.navigationController?.pushViewController(SignUpViewController(), animated: true)
    }
    
    @objc private func didTapForgotPassword() {
        self.navigationController?.pushViewController(ForgotPasswordViewController(), animated: true)
    }
}

// MARK: - Handle LoginView
extension LoginViewController: LoginView {
    func onCheckLoginSuccess() {
        self.hideLoading()
        self.labelError.isHidden = true
//        DoiDep.shared.delegate?.onLogin(with: UserService.shared.getDataUser().convertObjectToDictionary)
        self.navigationController?.pushViewController(TabBarViewController(), animated: true)
        self.removeFromParent()
    }
    
    func onCheckLoginFailed(with message: String) {
        self.hideLoading()
        self.labelError.text = message
        self.labelError.isHidden = false
        Logger.log(message: message, event: .error)
    }
}
