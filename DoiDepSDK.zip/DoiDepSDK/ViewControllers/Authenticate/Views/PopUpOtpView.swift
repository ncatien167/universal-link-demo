//
//  PopUpOtpView.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 16/08/2022.
//

import UIKit

class PopUpOtpView: AppNavigationVC {
    private lazy var labelTitle: PaddingLabel = {
        let label = PaddingLabel()
        label.text = "Nhập mã OTP của bạn"
        label.textAlignment = .center
        label.textColor = Colors.normalTextColor
        label.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        return label
    }()
    
    private lazy var cancelButton: UIButton = {
        let btn = UIButton()
        btn.setImage(UIImage().getImage(with: "ic_close", and: Bundle(for: PopupStore.self))!, for: .normal)
        btn.addTarget(self, action: #selector(didCancel(_:)), for: .touchUpInside)
        return btn
    }()
    
    lazy var contentAlertView: UIView = {
        let view = UIView()
        view.backgroundColor = Colors.white
        view.layer.cornerRadius = 15
        view.layer.masksToBounds = true
        return view
    }()
    
    private lazy var dimmedBackgroundView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = UIColor.black.withAlphaComponent(0.3)
        return view
    }()
    
    lazy var labelOTP_1: UILabel = {
        let lbl = UILabel()
        lbl.textColor = Colors.authenticateColor
        lbl.textAlignment = .center
        lbl.backgroundColor = Colors.white
        lbl.layer.addBorder(edge: .bottom, color: Colors.mainColor, thickness: 0.5)
        return lbl
    }()
    lazy var labelOTP_2: UILabel = {
        let lbl = UILabel()
        lbl.textColor = Colors.authenticateColor
        lbl.textAlignment = .center
        lbl.backgroundColor = Colors.white
        lbl.layer.addBorder(edge: .bottom, color: Colors.mainColor, thickness: 0.5)
        return lbl
    }()
    lazy var labelOTP_3: UILabel = {
        let lbl = UILabel()
        lbl.textColor = Colors.authenticateColor
        lbl.textAlignment = .center
        lbl.backgroundColor = Colors.white
        lbl.layer.addBorder(edge: .bottom, color: Colors.mainColor, thickness: 0.5)
        return lbl
    }()
    lazy var labelOTP_4: UILabel = {
        let lbl = UILabel()
        lbl.textColor = Colors.authenticateColor
        lbl.textAlignment = .center
        lbl.backgroundColor = Colors.white
        lbl.layer.addBorder(edge: .bottom, color: Colors.mainColor, thickness: 0.5)
        return lbl
    }()
    lazy var labelOTP_5: UILabel = {
        let lbl = UILabel()
        lbl.textColor = Colors.authenticateColor
        lbl.textAlignment = .center
        lbl.backgroundColor = Colors.white
        lbl.layer.addBorder(edge: .bottom, color: Colors.mainColor, thickness: 0.5)
        return lbl
    }()
    lazy var labelOTP_6: UILabel = {
        let lbl = UILabel()
        lbl.textColor = Colors.authenticateColor
        lbl.textAlignment = .center
        lbl.backgroundColor = Colors.white
        lbl.layer.addBorder(edge: .bottom, color: Colors.mainColor, thickness: 0.5)
        return lbl
    }()
    
    lazy var OTPStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.distribution = .fillEqually
        stackView.alignment = .center
        stackView.axis = .horizontal
        stackView.spacing = 10
        return stackView
    }()
    
    lazy var textFieldOTPCode: UITextField = {
        let txt = UITextField()
        txt.backgroundColor = .clear
        txt.tintColor = .clear
        txt.textColor = .clear
        txt.keyboardType = .numberPad
        txt.addTarget(self, action: #selector(textFieldOtpEdittingChanged), for: .editingChanged)
        return txt
    }()
    
    lazy var orderButton: CommonButton = {
        let button = CommonButton()
        button.setup(title: "Tiếp tục", 10)
        button.didTap = { [weak self] in
            guard let self = self else { return }
            self.didTapNextButton()
        }
        return button
    }()
    
    // MARK: - Properties
    private var presenter: OTPPresenter?
    
    private var otpLength = 4
    private var otpData: ResponseOTP?
    
    typealias completionHandler = (Bool?) -> ()
    private var completion: completionHandler?
    
    internal required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private init(otpData: ResponseOTP?, completion: completionHandler? = nil) {
        super.init(nibName: nil, bundle: nil)
        self.otpData = otpData
        self.completion = completion
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter = OTPPresenter(self)
        self.backgroundImageView.isHidden = true
        let gesture = UITapGestureRecognizer(target: self, action: #selector(didTapView(gesture:)))
        self.dimmedBackgroundView.addGestureRecognizer(gesture)
        initLayout()
    }
    
    deinit {
        presenter = nil
    }
    
    func initLayout() {
        self.view.addSubview(dimmedBackgroundView)
        self.view.addSubview(contentAlertView)
        self.contentAlertView.addSubviews(cancelButton, labelTitle, OTPStackView, textFieldOTPCode)
        
        dimmedBackgroundView.snp.makeConstraints { (make) in
            make.trailing.leading.top.bottom.equalToSuperview()
        }
        
        contentAlertView.snp.makeConstraints { (make) in
            make.height.equalTo(500.heightRatio)
            make.bottom.leading.trailing.equalToSuperview()
        }
        
        labelTitle.snp.makeConstraints { make in
            make.height.equalTo(25.heightRatio)
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().inset(10.heightRatio)
        }
        
        OTPStackView.snp.makeConstraints { (make) in
            make.top.equalTo(labelTitle.snp.bottom).offset(50.heightRatio)
            make.centerX.equalToSuperview()
            make.height.equalTo(55)
        }
        textFieldOTPCode.snp.makeConstraints { (make) in
            make.top.leading.trailing.bottom.equalTo(OTPStackView)
        }
        OTPStackView.addArrangedSubview(labelOTP_1)
        OTPStackView.addArrangedSubview(labelOTP_2)
        OTPStackView.addArrangedSubview(labelOTP_3)
        OTPStackView.addArrangedSubview(labelOTP_4)
        labelOTP_1.snp.makeConstraints { (make) in
            make.top.bottom.equalToSuperview()
            make.width.equalTo(45)
        }
        labelOTP_2.snp.makeConstraints { (make) in
            make.top.bottom.equalToSuperview()
        }
        labelOTP_3.snp.makeConstraints { (make) in
            make.top.bottom.equalToSuperview()
        }
        labelOTP_4.snp.makeConstraints { (make) in
            make.top.bottom.equalToSuperview()
        }
        if self.otpLength > 4 {
            OTPStackView.addArrangedSubview(labelOTP_5)
            OTPStackView.addArrangedSubview(labelOTP_6)
            labelOTP_5.snp.makeConstraints { (make) in
                make.top.bottom.equalToSuperview()
            }
            labelOTP_6.snp.makeConstraints { (make) in
                make.top.bottom.equalToSuperview()
            }
        }
        
    }
    
    // MARK: show alert
    
    static func showPopup(with OTPData: ResponseOTP?, completion: completionHandler? = nil) {
        let alert = PopUpOtpView(otpData: OTPData, completion: completion)
        DispatchQueue.main.async(execute: {
            guard let viewController = UIViewController.topMostViewController() else { return }
            presentPopover(alert, viewController: viewController)
        })
    }
    
    @objc func didCancel(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    private static func presentPopover(_ alert: UIViewController, viewController: UIViewController) {
        alert.modalPresentationStyle = .overCurrentContext
        alert.modalTransitionStyle = .crossDissolve
        alert.definesPresentationContext = true
        viewController.present(alert, animated: true, completion: nil)
    }
    
    // MARK: - Action
    private func didTapNextButton() {
        
    }
    
    @objc func textFieldOtpEdittingChanged() {
        let strOTP = textFieldOTPCode.text ?? ""
        print(strOTP as Any)
        
        if textFieldOTPCode.text == "" {
            labelOTP_1.text = ""
            
        }
        
        let charactersArray = strOTP.charactersArray
        
        switch strOTP.count {
        case 1:
            labelOTP_1.text = String(charactersArray[0])
            labelOTP_2.text = ""
            labelOTP_3.text = ""
            labelOTP_4.text = ""
            labelOTP_5.text = ""
            labelOTP_6.text = ""
            break
        case 2:
            labelOTP_2.text = String(charactersArray[1])
            labelOTP_3.text = ""
            labelOTP_4.text = ""
            labelOTP_5.text = ""
            labelOTP_6.text = ""
            break
        case 3:
            labelOTP_3.text = String(charactersArray[2])
            labelOTP_4.text = ""
            labelOTP_5.text = ""
            labelOTP_6.text = ""
            break
        case 4:
            labelOTP_4.text = String(charactersArray[3])
            labelOTP_5.text = ""
            labelOTP_6.text = ""
            if otpLength == 4 {
                self.showLoading()
                self.presenter?.requestVerify(with: strOTP, OTPData: self.otpData)
            }
            break
        case 5:
            labelOTP_5.text = String(charactersArray[4])
            labelOTP_6.text = ""
            break
        case 6:
            labelOTP_6.text = String(charactersArray[5])
            break
        default:
            break
        }
    }
    
    @objc private func didTapView(gesture: UITapGestureRecognizer) {
        view.endEditing(true)
        self.dismiss(animated: true, completion: nil)
    }
}

extension PopUpOtpView: OTPView {
    func onVerifyOTPSuccess() {
        self.hideLoading()
        dismiss(animated: true) {
            self.completion?(true)
        }
    }
    
    func onVerifyOTPFailed(with message: String) {
        self.hideLoading()
        CommonPopup.showAlertOnlyOk(message)
    }
}
