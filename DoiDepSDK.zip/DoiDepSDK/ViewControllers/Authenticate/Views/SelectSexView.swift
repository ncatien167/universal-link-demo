//
//  SelectSexView.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 16/08/2022.
//

import UIKit

enum SexType: Int {
    case unknow = 0
    case male = 1
    case female = 2
}
class SelectSexView: UIView {
    
    lazy var buttonNone: UIButton = {
        let button = UIButton()
        button.setTitle("Chưa xác định", for: .normal)
        button.setTitleColor(Colors.black, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        button.setImage(UIImage().getImage(with: "ic_selected", and: Bundle(for: OrderInfoView.self))!, for: .normal)
        button.imageEdgeInsets = UIEdgeInsets(top: 5, left: -10.widthRatio, bottom: 5, right: 0)
        button.addTarget(self, action: #selector(didTapNoneButton), for: .touchUpInside)
        button.imageView?.contentMode = .scaleAspectFit
        return button
    }()
    
    lazy var buttonMale: UIButton = {
        let button = UIButton()
        button.setTitle("Nam", for: .normal)
        button.setTitleColor(Colors.black, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        button.setImage(UIImage().getImage(with: "ic_non_select", and: Bundle(for: OrderInfoView.self))!, for: .normal)
        button.imageEdgeInsets = UIEdgeInsets(top: 5, left: -5.widthRatio, bottom: 5, right: 0)
        button.addTarget(self, action: #selector(didTapMaleButton), for: .touchUpInside)
        button.imageView?.contentMode = .scaleAspectFit
        return button
    }()
    
    lazy var buttonFemale: UIButton = {
        let button = UIButton()
        button.setTitle("Nữ", for: .normal)
        button.setTitleColor(Colors.black, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        button.setImage(UIImage().getImage(with: "ic_non_select", and: Bundle(for: OrderInfoView.self))!, for: .normal)
        button.imageEdgeInsets = UIEdgeInsets(top: 5, left: -5.widthRatio, bottom: 5, right: 0)
        button.addTarget(self, action: #selector(didTapFemaleButton), for: .touchUpInside)
        button.imageView?.contentMode = .scaleAspectFit
        return button
    }()
    
    var sexDidChange: ((SexType?)->())?
    
    private var sexType: SexType = .unknow {
        didSet {
            switch sexType {
            case .unknow:
                buttonNone.setImage(UIImage().getImage(with: "ic_selected", and: Bundle(for: SelectSexView.self))!, for: .normal)
                buttonMale.setImage(UIImage().getImage(with: "ic_non_select", and: Bundle(for: SelectSexView.self))!, for: .normal)
                buttonFemale.setImage(UIImage().getImage(with: "ic_non_select", and: Bundle(for: SelectSexView.self))!, for: .normal)
            case .male:
                buttonNone.setImage(UIImage().getImage(with: "ic_non_select", and: Bundle(for: SelectSexView.self))!, for: .normal)
                buttonMale.setImage(UIImage().getImage(with: "ic_selected", and: Bundle(for: SelectSexView.self))!, for: .normal)
                buttonFemale.setImage(UIImage().getImage(with: "ic_non_select", and: Bundle(for: SelectSexView.self))!, for: .normal)
            case .female:
                buttonNone.setImage(UIImage().getImage(with: "ic_non_select", and: Bundle(for: SelectSexView.self))!, for: .normal)
                buttonMale.setImage(UIImage().getImage(with: "ic_non_select", and: Bundle(for: SelectSexView.self))!, for: .normal)
                buttonFemale.setImage(UIImage().getImage(with: "ic_selected", and: Bundle(for: SelectSexView.self))!, for: .normal)
            }
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        let label = UILabel()
        label.text = "Giới tính"
        
        let stackButtons = UIStackView(arrangedSubviews: [buttonNone, buttonMale, buttonFemale])
        stackButtons.spacing = 5
        stackButtons.axis = .horizontal
        stackButtons.alignment = .fill
        stackButtons.distribution = .equalSpacing
        
        self.addSubviews(label, stackButtons)
        label.snp.makeConstraints { make in
            make.top.leading.equalToSuperview().inset(5.heightRatio)
        }
        
        stackButtons.snp.makeConstraints { make in
            make.height.equalTo(30.heightRatio)
            make.top.equalTo(label.snp.bottom).offset(5.heightRatio)
            make.bottom.leading.trailing.equalToSuperview().inset(5.heightRatio)
        }
    }
    
    @objc private func didTapNoneButton() {
        self.sexType = .unknow
        sexDidChange?(.unknow)
    }
    
    @objc private func didTapMaleButton() {
        self.sexType = .male
        sexDidChange?(.male)
    }
    
    @objc private func didTapFemaleButton() {
        self.sexType = .female
        sexDidChange?(.female)
    }
}
