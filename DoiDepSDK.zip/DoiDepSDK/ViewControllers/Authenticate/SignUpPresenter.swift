//
//  SignUpPresenter.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 16/08/2022.
//

import Foundation

protocol SignUpView {
    func onShowOtp(with OTPData: ResponseOTP?)
    func onCheckSignUpFailed(with message: String)
}

protocol SignUpViewPresenter {
    init(_ view: SignUpView)
    
    func requestSignUp(with data: SignUpParam)
}

class SignUpPresenter: SignUpViewPresenter {
    
    var view: SignUpView?
    
    required init(_ view: SignUpView) {
        self.view = view
    }
    
    func requestSignUp(with data: SignUpParam) {
        LoginService.requestSignUp(with: data) { status, dataOTP in
            guard let status = status else {
                self.view?.onCheckSignUpFailed(with: dataOTP?.Message ?? "Đăng ký thất bại. Quý khách vui lòng kiểm tra lại")
                return
            }
            
            if status {
                self.view?.onShowOtp(with: dataOTP)
            } else {
                self.view?.onCheckSignUpFailed(with: dataOTP?.Message ?? "Đăng ký thất bại. Quý khách vui lòng kiểm tra lại")
            }
        }
    }
}
