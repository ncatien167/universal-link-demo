//
//  SignUpViewController.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 15/08/2022.
//

import UIKit

class SignUpViewController: AppNavigationVC, UIScrollViewDelegate {
    
    // MARK: - UI INIT
    lazy var contentView: UIView = {
        let view = UIView()
        return view
    }()
    
    lazy var scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.isScrollEnabled = true
        scrollView.delegate = self
        scrollView.bounces = true
        return scrollView
    }()
    
    lazy var contentStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.alignment = .center
        stackView.distribution = .fill
        stackView.spacing = 20.heightRatio
        return stackView
    }()
    
    lazy var mainIconImageView: UIImageView = {
        let imageView = UIImageView(image: UIImage().getImage(with: "logo_white_notagline", and: Bundle(for: LoginViewController.self))!)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    lazy var contentSignUpView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 10
        return view
    }()
    
    lazy var phoneTextfield: InputView = {
        let inputView = InputView()
        inputView.setPlaceholder = "Số điện thoại*"
        inputView.textField.keyboardType = .numberPad
        return inputView
    }()
    
    lazy var firstNameTextfield: InputView = {
        let inputView = InputView()
        inputView.setPlaceholder = "Họ*"
        inputView.isHidden = true
        return inputView
    }()
    
    lazy var lastNameTextfield: InputView = {
        let inputView = InputView()
        inputView.setPlaceholder = "Tên*"
        inputView.isHidden = true
        return inputView
    }()
    
    lazy var passwordTextfield: InputView = {
        let inputView = InputView()
        inputView.setPlaceholder = "Mật khẩu*"
        inputView.textField.isSecureTextEntry = true
        return inputView
    }()
    
    lazy var dobTextfield: InputView = {
        let inputView = InputView()
        inputView.setPlaceholder = "Ngày sinh"
        inputView.textField.inputView = datePicker
        inputView.isHidden = true
        return inputView
    }()
    
    lazy var datePicker: UIDatePicker = {
        let datePicker = UIDatePicker()
        datePicker.datePickerMode = .date
        datePicker.setValue(Colors.authenticateColor, forKeyPath: "textColor")
        if #available(iOS 13.4, *) {
            datePicker.preferredDatePickerStyle = .wheels
        }
        datePicker.addTarget(self, action: #selector(didValueChangeDate), for: .valueChanged)
        datePicker.isHidden = true
        return datePicker
    }()
    
    lazy var emailTextfield: InputView = {
        let inputView = InputView()
        inputView.setPlaceholder = "Email"
        inputView.textField.keyboardType = .emailAddress
        return inputView
    }()
    
    lazy var addressTextfield: InputView = {
        let inputView = InputView()
        inputView.setPlaceholder = "Địa chỉ*"
        inputView.isHidden = true
        return inputView
    }()
    
    lazy var sexView: SelectSexView = {
        let view = SelectSexView()
        view.isHidden = true
        return view
    }()
    
    lazy var labelError: UILabel = {
        let label = UILabel()
        label.isHidden = true
        label.textColor = .red
        label.numberOfLines = 0
        label.font = UIFont.systemFont(ofSize: 14, weight: .light)
        return label
    }()
    
    lazy var buttonSignUp: CommonButton = {
        let button = CommonButton()
        button.setup(title: "ĐĂNG KÝ".uppercased(), 5)
        button.backgroundColor = .white
        button.backgroundButton.image = nil
        button.button.setTitleColor(Colors.mainColor, for: .normal)
        button.button.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .light)
        button.didTap = { [weak self] in
            guard let self = self else { return }
            self.didTapSignUpButton()
        }
        return button
    }()
    
    lazy var buttonLoginNow: UIButton = {
        let button = UIButton()
        button.setTitle("Đã có tài khoản?     Đăng nhập ngay", for: .normal)
        button.setTitleColor(Colors.white, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .light)
        button.addTarget(self, action: #selector(didTapLoginNow), for: .touchUpInside)
        return button
    }()

    // VAT UI
    lazy var buttonUsingVAT: UIButton = {
        let button = UIButton()
        button.isHidden = true
        button.setTitle("Nhận VAT", for: .normal)
        button.setTitleColor(Colors.black, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        button.setImage(UIImage().getImage(with: "ic_non_select", and: Bundle(for: OrderInfoView.self))!, for: .normal)
        button.imageEdgeInsets = UIEdgeInsets(top: 5, left: -5.widthRatio, bottom: 5, right: 0)
        button.addTarget(self, action: #selector(didTapVat), for: .touchUpInside)
        button.imageView?.contentMode = .scaleAspectFit
        return button
    }()
    
    lazy var companyNameTextfield: InputView = {
        let inputView = InputView()
        inputView.isHidden = true
        inputView.setPlaceholder = "Tên công ty"
        return inputView
    }()
    
    lazy var taxTextfield: InputView = {
        let inputView = InputView()
        inputView.isHidden = true
        inputView.setPlaceholder = "Mã số thuế"
        return inputView
    }()
    
    lazy var emailTaxTextfield: InputView = {
        let inputView = InputView()
        inputView.isHidden = true
        inputView.setPlaceholder = "Email nhận hoá đơn VAT"
        inputView.textField.keyboardType = .emailAddress
        return inputView
    }()
    
    lazy var companyAddressTextfield: InputView = {
        let inputView = InputView()
        inputView.isHidden = true
        inputView.setPlaceholder = "Địa chỉ công ty"
        return inputView
    }()
    
    // MARK: - Presenter
    
    var presenter: SignUpPresenter?
    
    // MARK: - Properties
    private var signUpParam: SignUpParam = SignUpParam()
    private var gender: SexType = .unknow
    
    // MARK: - Flags
    private var isUsingVat: Bool = false {
        didSet {
            companyNameTextfield.isHidden = !isUsingVat
            taxTextfield.isHidden = !isUsingVat
            emailTaxTextfield.isHidden = !isUsingVat
            companyAddressTextfield.isHidden = !isUsingVat
            if isUsingVat {
                buttonUsingVAT.setImage(UIImage().getImage(with: "ic_selected", and: Bundle(for: SelectSexView.self))!, for: .normal)
            } else {
                buttonUsingVAT.setImage(UIImage().getImage(with: "ic_non_select", and: Bundle(for: SelectSexView.self))!, for: .normal)
            }
        }
    }
    
    // MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        presenter = SignUpPresenter(self)
        addObsevers()
        setupUI()
        handleSexView()
        handleInputField()
    }
    
    deinit {
        presenter = nil
        removeObservers()
    }
    
    // MARK: - Setup
    private func setupUI() {
        self.headerView.title = ""
        self.headerView.isHidden = true
        let labelSignUp = UILabel()
        labelSignUp.text = "ĐĂNG KÝ"
        labelSignUp.font = UIFont.systemFont(ofSize: 17, weight: .bold)
        labelSignUp.textColor = .white
        labelSignUp.textAlignment = .center
        
        let labelDes = UILabel()
        labelDes.text = "Vui lòng điền thông tin\nđể trở thành thành viên của Doi Dep"
        labelDes.font = UIFont.italicSystemFont(ofSize: 15)
        labelDes.textColor = .white
        labelDes.textAlignment = .center
        labelDes.numberOfLines = 0
        
        self.view.addSubview(contentView)
        self.contentView.addSubview(scrollView)
        self.scrollView.addSubview(contentStackView)
        
        contentView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(NAV_BAR_HEIGHT)
            make.bottom.leading.trailing.equalToSuperview()
        }

        scrollView.snp.makeConstraints { make in
            make.top.bottom.leading.trailing.equalToSuperview()
        }
        
        contentStackView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(15.heightRatio)
            make.leading.trailing.equalToSuperview()
            make.width.equalTo(375.widthRatio)
            make.bottom.equalToSuperview().offset(-30.heightRatio)
       }
        
        contentStackView.addArrangedSubview(mainIconImageView)
        contentStackView.addArrangedSubview(labelSignUp)
        contentStackView.addArrangedSubview(labelDes)
        contentStackView.addArrangedSubview(contentSignUpView)
        contentStackView.addArrangedSubview(buttonSignUp)
        contentStackView.addArrangedSubview(buttonLoginNow)
        contentStackView.addArrangedSubview(labelError)
        
        mainIconImageView.snp.makeConstraints { make in
            make.width.height.equalTo(120.widthRatio)
        }
        
        labelSignUp.snp.makeConstraints { make in
            make.height.equalTo(40.heightRatio)
            make.width.equalTo(300.widthRatio)
        }
        
        labelDes.snp.makeConstraints { make in
            make.height.equalTo(50.heightRatio)
            make.width.equalTo(340.widthRatio)
        }
        
        contentSignUpView.snp.makeConstraints { make in
            make.width.equalTo(300.widthRatio)
        }
        
        let viewVAT = UIView()
        viewVAT.isHidden = true
        viewVAT.addSubview(buttonUsingVAT)
        
        let contentSignUpStackView = UIStackView(arrangedSubviews: [phoneTextfield, firstNameTextfield, lastNameTextfield, passwordTextfield, dobTextfield, emailTextfield, addressTextfield, viewVAT, companyNameTextfield, taxTextfield, emailTaxTextfield, companyAddressTextfield, sexView, labelError])
        contentSignUpStackView.axis = .vertical
        contentSignUpStackView.alignment = .center
        contentSignUpStackView.distribution = .equalSpacing
        contentSignUpStackView.spacing = 10.heightRatio
        contentSignUpView.addSubview(contentSignUpStackView)
        
        contentSignUpStackView.snp.makeConstraints { make in
            make.top.leading.equalToSuperview().offset(20.widthRatio)
            make.trailing.equalToSuperview().offset(-20.widthRatio)
            make.bottom.equalToSuperview().inset(20.heightRatio)
        }
        
        buttonSignUp.snp.makeConstraints { make in
            make.width.equalTo(200.widthRatio)
        }
        
        buttonLoginNow.snp.makeConstraints { make in
            make.width.equalTo(345.widthRatio)
        }
        
        buttonUsingVAT.snp.makeConstraints { make in
            make.top.bottom.leading.equalToSuperview()
        }
        sexView.setConstraintWidth(constant: 250.widthRatio)
        labelError.setConstraintWidth(constant: 250.widthRatio)
        viewVAT.setConstraintWidthAndHeight(widthConstant: 250.widthRatio, heightConstant: 30.heightRatio)
        dobTextfield.setConstraintWidthAndHeight(widthConstant: 250.widthRatio, heightConstant: 40.heightRatio)
        phoneTextfield.setConstraintWidthAndHeight(widthConstant: 250.widthRatio, heightConstant: 40.heightRatio)
        emailTextfield.setConstraintWidthAndHeight(widthConstant: 250.widthRatio, heightConstant: 40.heightRatio)
        addressTextfield.setConstraintWidthAndHeight(widthConstant: 250.widthRatio, heightConstant: 40.heightRatio)
        lastNameTextfield.setConstraintWidthAndHeight(widthConstant: 250.widthRatio, heightConstant: 40.heightRatio)
        passwordTextfield.setConstraintWidthAndHeight(widthConstant: 250.widthRatio, heightConstant: 40.heightRatio)
        firstNameTextfield.setConstraintWidthAndHeight(widthConstant: 250.widthRatio, heightConstant: 40.heightRatio)
        
        taxTextfield.setConstraintWidthAndHeight(widthConstant: 250.widthRatio, heightConstant: 40.heightRatio)
        emailTaxTextfield.setConstraintWidthAndHeight(widthConstant: 250.widthRatio, heightConstant: 40.heightRatio)
        companyNameTextfield.setConstraintWidthAndHeight(widthConstant: 250.widthRatio, heightConstant: 40.heightRatio)
        companyAddressTextfield.setConstraintWidthAndHeight(widthConstant: 250.widthRatio, heightConstant: 40.heightRatio)
    }
    
    // MARK: - Handle
    private func handleSexView() {
        sexView.sexDidChange = { [weak self] type in
            guard let self = self, let type = type else {
                return
            }
            
            self.gender = type
        }
    }
    
    private func handleInputField() {
        emailTextfield.didEditingChanged = { [weak self] in
            guard let self = self else {
                return
            }
        }
        addressTextfield.didBeginEditText = { [weak self] in
            guard let self = self else {
                return
            }
            DispatchQueue.main.async {
                self.view.endEditing(true)
                self.didGoToSelectAddress()
            }
        }
        phoneTextfield.didBeginEditText = { [weak self] in
             guard let _ = self else { return }
             
        }
        phoneTextfield.didEditingChanged = { [weak self] in
             guard let self = self else { return }
             if let numb = self.phoneTextfield.textField.text {
                  if numb.count > 10 {
                       self.phoneTextfield.textField.text = String(numb.dropLast())
                  }
             }
        }
    }
    // MARK: - Action
    
    private func didTapSignUpButton() {
        guard let phone = phoneTextfield.textField.text, let firstName = firstNameTextfield.textField.text, let lastName = lastNameTextfield.textField.text, let password = passwordTextfield.textField.text, let address = addressTextfield.textField.text else {
            return
        }

        if phone.isEmpty || phone == "" || phone.count == 0 {
            self.labelError.text = "Vui lòng nhập Số điện thoại"
            self.labelError.isHidden = false
            return
        }
        if !phone.checkPhoneNumber() {
            self.labelError.text = "Vui lòng nhập đúng định dạng Số điện thoại"
            self.labelError.isHidden = false
            return
        }
//        if firstName.isEmpty || firstName == "" || firstName.count == 0 {
//            self.labelError.text = "Vui lòng nhập họ"
//            self.labelError.isHidden = false
//            return
//        }
//        if lastName.isEmpty || lastName == "" || lastName.count == 0 {
//            self.labelError.text = "Vui lòng nhập tên"
//            self.labelError.isHidden = false
//            return
//        }
        if password.isEmpty || password == "" || password.count == 0 {
            self.labelError.text = "Vui lòng nhập mật khẩu"
            self.labelError.isHidden = false
            return
        }
//        if address.isEmpty || address == "" || address.count == 0 {
//            self.labelError.text = "Vui lòng nhập địa chỉ"
//            self.labelError.isHidden = false
//            return
//        }
        
        var emailString: String? = ""
        if let email = emailTextfield.textField.text {
            if email != "" && !email.checkValidationEmail() {
                self.labelError.text = "Vui lòng nhập đúng định dạng email"
                self.labelError.isHidden = false
                return
            }
            emailString = email
        }
        
//        if signUpParam.Province == nil || signUpParam.District == nil || signUpParam.Ward == nil {
//            self.labelError.text = "Vui lòng nhập địa chỉ"
//            self.labelError.isHidden = false
//            return
//        }
        
        self.labelError.isHidden = true
        self.showLoading()
        
        let fullName = lastName + " " + firstName
        signUpParam.Phone = phone
        signUpParam.Password = password
        signUpParam.FirstName = ""
        signUpParam.LastName = ""
        signUpParam.FullName = ""
        signUpParam.Email = ""
        signUpParam.BirdthDay = "01/01/1970"
        signUpParam.Gender = 0
        signUpParam.Province = 0
        signUpParam.District = 0
        signUpParam.Ward = 0
        signUpParam.isVAT = isUsingVat
        signUpParam.VATCompanyName = ""
        signUpParam.VATTaxCode = ""
        signUpParam.VATEmail = ""
        signUpParam.VATAddress = ""
        
        if isUsingVat {
            guard let companyName = companyNameTextfield.textField.text, let taxCode = taxTextfield.textField.text, let emailTax = emailTaxTextfield.textField.text, let companyAddress = companyAddressTextfield.textField.text else { return }
            
            if companyName.isEmpty || companyName == "" || companyName.count == 0 {
                self.labelError.text = "Vui lòng nhập tên công ty"
                self.labelError.isHidden = false
                return
            }
            if taxCode.isEmpty || taxCode == "" || taxCode.count == 0 {
                self.labelError.text = "Vui lòng nhập mã số thuế"
                self.labelError.isHidden = false
                return
            }
            if emailTax.isEmpty || emailTax == "" || emailTax.count == 0 {
                self.labelError.text = "Vui lòng nhập email"
                self.labelError.isHidden = false
                return
            }
            if !emailTax.checkValidationEmail() {
                self.labelError.text = "Vui lòng nhập đúng định dạnh email nhận VAT"
                self.labelError.isHidden = false
                return
            }
            if companyAddress.isEmpty || companyAddress == "" || companyAddress.count == 0 {
                self.labelError.text = "Vui lòng nhập địa chỉ công ty"
                self.labelError.isHidden = false
                return
            }
            
            signUpParam.isVAT = isUsingVat
            signUpParam.VATCompanyName = ""
            signUpParam.VATTaxCode = ""
            signUpParam.VATEmail = ""
            signUpParam.VATAddress = ""
        }
        
        
        presenter?.requestSignUp(with: signUpParam)
    }
    
    @objc private func didTapLoginNow() {
        self.navigationController?.popViewController(animated: true)
    }
    
    private func didGoToSelectAddress() {
        let vc = SelectAddressViewController()
        vc.didDone = { [weak self] wardDistrictData, address in
            guard let self = self else { return }
            self.signUpParam.Province = wardDistrictData?.ProvinceID
            self.signUpParam.District = wardDistrictData?.DistrictID
            self.signUpParam.Ward = wardDistrictData?.ID
            self.signUpParam.Address = address
            let addressString = "\(address ?? ""), \(wardDistrictData?.WardName ?? ""), \(wardDistrictData?.DistrictName ?? ""), \(CommonService.shared.getProvinceData(with: wardDistrictData?.ProvinceID ?? -1)?.Name ?? "")"
            self.addressTextfield.textField.text = addressString
        }
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc private func didTapVat() {
        isUsingVat = !isUsingVat
    }
    
    @objc func didValueChangeDate() {
        let dateFormatter = DateFormatter().dateformatter("dd/MM/yyyy")
        dobTextfield.textField.text = dateFormatter.string(from: datePicker.date)
    }
}

extension SignUpViewController {
    
    // MARK: - Setup Keyboard
    @objc private func didTapView(gesture: UITapGestureRecognizer) {
        view.endEditing(true)
    }
    
    func addObsevers() {
        let gesture = UITapGestureRecognizer(target: self, action: #selector(didTapView(gesture:)))
        self.view.addGestureRecognizer(gesture)
        NotificationCenter.default.addObserver(forName: UIResponder.keyboardWillShowNotification, object: nil, queue: nil) {
            [weak self] notification in
            guard let self = self else { return }
            self.keybordwillshow(notification: notification)
        }
        NotificationCenter.default.addObserver(forName: UIResponder.keyboardWillHideNotification, object: nil, queue: nil) {
            [weak self] notification in
            guard let self = self else { return }
            self.keybordwillhide(notification: notification)
        }
    }
    
    private func removeObservers() {
        NotificationCenter.default.removeObserver(self)
    }
    
    private func keybordwillshow(notification: Notification) {
        guard let userInfo = notification.userInfo,
              let frame = (userInfo[UIResponder.keyboardFrameEndUserInfoKey]as? NSValue)?.cgRectValue else{
            return
        }
        let contentInset = UIEdgeInsets(top: 0, left: 0, bottom: frame.height + 20, right: 0)
        scrollView.contentInset = contentInset
    }
    
    private func keybordwillhide(notification: Notification) {
        scrollView.contentInset = UIEdgeInsets.zero
    }
}

// MARK: - Handle SignUpView
extension SignUpViewController: SignUpView {
    func onShowOtp(with OTPData: ResponseOTP?) {
        self.hideLoading()
        PopUpOtpView.showPopup(with: OTPData) { [weak self] status in
            guard let self = self, let status = status else { return }
            if status {
                CommonPopup.showAlertOnlyOk("Chúc mừng bạn đã đăng ký thành công tài khoản Đôi Dép", title: nil) {
                    DispatchQueue.main.async {
                        self.navigationController?.popViewController(animated: true)
                    }
                }
            }
        }
    }
    
    func onCheckSignUpFailed(with message: String) {
        self.hideLoading()
        self.labelError.text = message
        self.labelError.isHidden = false
        Logger.log(message: message, event: .error)
    }
}

struct SignUpParam: Codable {
    var Phone: String?
    var Password: String?
    var FirstName: String?
    var LastName: String?
    var FullName: String?
    var Email: String?
    var Province: Int?
    var District: Int?
    var Ward: Int?
    var Address: String?
    var BirdthDay: String?
    var Gender: Int?
    var isVAT: Bool?
    var VATCompanyName: String?
    var VATTaxCode: String?
    var VATEmail: String?
    var VATAddress: String?
}
