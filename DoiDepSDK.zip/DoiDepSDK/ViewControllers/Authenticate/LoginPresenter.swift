//
//  LoginPresenter.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 15/07/2022.
//

import Foundation

protocol LoginView {
    func onCheckLoginSuccess()
    func onCheckLoginFailed(with message: String)
}

protocol LoginViewPresenter {
    init(_ view: LoginView)
    
    func requestLogin(with username: String, and password: String)
}

class LoginPresenter: LoginViewPresenter {
    
    var view: LoginView?
    
    required init(_ view: LoginView) {
        self.view = view
        requestProvinceData()
    }
    
    func requestProvinceData() {
        CommonAPIService.getProvinceData { _ in
            
        }
    }
    
    func requestLogin(with username: String, and password: String) {
        LoginService.requestLogin(with: username, and: password) { status, message in
            guard let status = status else {
                self.view?.onCheckLoginFailed(with: "Tên đăng nhập hoặc mật khẩu không đúng")
                return
            }
            
            if status {
                self.view?.onCheckLoginSuccess()
            } else {
                self.view?.onCheckLoginFailed(with: message ?? "Tên đăng nhập hoặc mật khẩu không đúng")
            }
        }
    }
}
