//
//  TabBarViewController.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 19/07/2022.
//

import UIKit

enum TabbarCategory {
    case home
    case booking
    case personal
    
    var index: Int {
        switch self {
        case .home: return 0
        case .booking: return 1
        case .personal: return 2
        }
    }
}

class TabBarViewController: UIViewController {
    
    lazy var tabbarButtonView: TabbarButtonView = {
        let view = TabbarButtonView()
        return view
    }()
    
    fileprivate lazy var viewBody: [UIView] = []
    
    // MARK: - Properties
    private var homeViewController = HomeViewController()
    private var personalViewController = PersonalViewController()
    
    private var tabSelected = TabbarCategory.home
    
    // MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupUI()
        tabBarAction()
        handleHomeClouser()
        handlePersonalClouser()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Cập nhật lại số item trong giỏ hàng
        self.homeViewController.searchHeaderView.badgeNumber = CartManager.shared.totalQuantity()
    }
    
    // MARK: - Setup
    private func setupUI() {
        viewBody.append(homeViewController.view)
        viewBody.append(personalViewController.view)
        
        for index in 0..<viewBody.count {
            self.view.addSubviews(viewBody[index])
            viewBody[index].tag = index
            viewBody[index].snp.makeConstraints { (make) in
                make.top.equalToSuperview()
                make.trailing.leading.equalToSuperview()
                make.bottom.equalToSuperview().inset(70.heightRatio)
            }
        }
        self.selectedTab(.home)
        
        self.view.addSubview(tabbarButtonView)
        tabbarButtonView.bringSubviewToFront(self.view)
        tabbarButtonView.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
            make.height.equalTo(90.heightRatio)
        }
    }
    
    // MARK: - Action
    
    private func unselected() {
        viewBody.forEach { view in
            view.isHidden = true
        }
    }
    
    private func selectedTab(_ tab: TabbarCategory) {
        tabSelected = tab
        unselected()
        if let view = viewBody.first(where: { tab.index == $0.tag }) {
            view.isHidden = false
        }
        view.endEditing(true)
    }
    
    private func tabBarAction() {
        tabbarButtonView.didTapFirst = { [weak self] in
            guard let self = self else { return }
            self.selectedTab(.home)
        }
        
        tabbarButtonView.didTapSecond = { [weak self] in
            guard let self = self else { return }
            let storyboard = UIStoryboard(name: "Booking", bundle: nil)
            guard let vc = storyboard.instantiateViewController(
                    withIdentifier: "HomeBookingViewController") as? HomeBookingViewController else {
                return
            }

            self.navigationController?.pushViewController(vc, animated: true)
        }
        
        tabbarButtonView.didTapThird = { [weak self] in
            guard let self = self else { return }
            self.selectedTab(.personal)
            self.personalViewController.setupData()
        }
    }
}

// MARK: - Handle Closure Child View
extension TabBarViewController {
    
    private func handleHomeClouser() {
        homeViewController.didGoToHomeDetail = { [weak self] productData in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.navigationController?.pushViewController(HomeDetailViewController(productID: productData.ID, productData: productData), animated: true)
            }
        }
        
        homeViewController.didGoToCart = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.navigationController?.pushViewController(CartViewController(), animated: true)
            }
        }
        
        homeViewController.didPopView = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.navigationController?.popViewController(animated: true)
            }
        }
        
        homeViewController.didGoToHomeSearch = { [weak self] status in
            guard let self = self, let status = status else { return }
            
            DispatchQueue.main.async {
                self.view.endEditing(true)
                self.navigationController?.pushViewController(HomeSearchViewController(isTopSale: status), animated: true)
            }
        }
        
        homeViewController.didGoToWebView = { [weak self] link in
            guard let self = self, let link = link else { return }
            DispatchQueue.main.async {
                self.navigationController?.pushViewController(WebViewController(requestUrl: link), animated: true)
            }
        }
        
        homeViewController.didGotoLogin = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.navigationController?.pushViewController(LoginViewController(), animated: true)
                self.removeFromParent()
            }
        }
    }
    
    private func handlePersonalClouser() {
        personalViewController.didGoToMyOrder = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.navigationController?.pushViewController(MyOrderViewController(), animated: true)
            }
        }
        personalViewController.didGoToAddress = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.navigationController?.pushViewController(AddressViewController(), animated: true)
            }
        }
        personalViewController.didTapBack = { [weak self] in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
}
