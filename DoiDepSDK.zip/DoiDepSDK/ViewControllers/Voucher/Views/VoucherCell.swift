//
//  VoucherCell.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 25/07/2022.
//

import UIKit

class VoucherCell: UITableViewCell {
    
    lazy var imageType: UIImageView = {
        let imageView = UIImageView(image: UIImage().getImage(with: "ic_shipping1", and: Bundle(for: VoucherCell.self))!)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    lazy var labelTitle: UILabel = {
        let label = UILabel()
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 15, weight: .light)
        return label
    }()
    
    lazy var labelCodeCoupon: UILabel = {
        let label = UILabel()
        label.textAlignment = .right
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 15, weight: .light)
        return label
    }()
    
    lazy var labelExpriedDay: UILabel = {
        let label = UILabel()
        label.textColor = Colors.normalTextColor
        label.font = UIFont.systemFont(ofSize: 13, weight: .light)
        return label
    }()
    
    lazy var labelAmount: UILabel = {
        let label = UILabel()
        label.textColor = Colors.authenticateColor
        label.font = UIFont.systemFont(ofSize: 14, weight: .light)
        return label
    }()
    
    lazy var buttonUseNow: UIButton = {
        let button = UIButton()
        button.setTitle("Dùng ngay", for: .normal)
        button.setTitleColor(Colors.white, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14, weight: .light)
        button.setBackgroundImage(UIImage().getImage(with: "bg_button_authenticate", and: Bundle(for: VoucherCell.self))!, for: .normal)
        button.addTarget(self, action: #selector(didTapUseNowButton), for: .touchUpInside)
        return button
    }()
    
    var didTapUseNow: (()->())?
    var didTapUseLater: (()->())?
    
    private var isUsingLater = false
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.setupUI()
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.awakeFromNib()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.awakeFromNib()
    }
    
    private func setupUI() {
        let stackView = UIStackView(arrangedSubviews: [labelTitle, labelCodeCoupon, labelExpriedDay])
        stackView.spacing = 0
        stackView.axis = .vertical
        stackView.alignment = .leading
        stackView.distribution = .fillEqually
        
        let stackUserNow = UIStackView(arrangedSubviews: [buttonUseNow, labelAmount])
        stackUserNow.spacing = 10
        stackUserNow.axis = .vertical
        stackUserNow.alignment = .trailing
        stackUserNow.distribution = .fill
        
        let contentStackView = UIStackView(arrangedSubviews: [imageType, stackView, stackUserNow])
        contentStackView.spacing = 10
        contentStackView.axis = .horizontal
        contentStackView.alignment = .center
        contentStackView.distribution = .fill
        
        self.contentView.addSubview(contentStackView)
        contentStackView.layer.cornerRadius = 5
        contentStackView.layer.borderWidth = 0.5
        contentStackView.layer.borderColor = Colors.mainColor.cgColor
        
        contentStackView.snp.makeConstraints { make in
            make.top.bottom.equalToSuperview().inset(5.heightRatio)
            make.leading.trailing.equalToSuperview().inset(15.heightRatio)
        }
        
        stackUserNow.setConstraintWidth(constant: 80.widthRatio)
        buttonUseNow.setConstraintHeight(constant: 25.heightRatio)
        imageType.setConstraintWidthAndHeight(widthConstant: 40.heightRatio, heightConstant: 40.heightRatio)
        
        contentStackView.layoutMargins = UIEdgeInsets(top: 5.heightRatio, left: 5.widthRatio, bottom: 5.heightRatio, right: 0)
        contentStackView.isLayoutMarginsRelativeArrangement = true
    }
//    2021-11-30T09:17:13.063
    // MARK: - Bind Data
    func bindData(with data: Voucher) {
        imageType.image = data.Type == 1 ? UIImage().getImage(with: "ic_gift", and: Bundle(for: VoucherCell.self))! : UIImage().getImage(with: "ic_shipping1", and: Bundle(for: VoucherCell.self))!
        labelTitle.text = data.Name
        if let expiredDay = data.ExpireDate?.split(separator: "T").first {
            labelExpriedDay.text = "Hạn sử dụng: \(expiredDay)"
        }
        labelAmount.text = "x\(Int(data.Available ?? 0))   "
        labelCodeCoupon.text = "Mã coupon: \(data.Code ?? "0")"
        
        if let voucherInCart = CartManager.shared.voucherData() {
            if voucherInCart.Code == data.Code {
                buttonUseNow.setTitle("Dùng sau", for: .normal)
                isUsingLater = true
            } else {
                buttonUseNow.setTitle("Dùng ngay", for: .normal)
                isUsingLater = false
            }
        }
    }
    
    @objc private func didTapUseNowButton() {
        if isUsingLater {
            didTapUseLater?()
            return
        }
        didTapUseNow?()
    }
}
