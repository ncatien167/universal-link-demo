//
//  ListHotelCell.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 19/4/25.
//

import UIKit

class ListHotelCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // tùy chỉnh thêm nếu cần
    }
}
