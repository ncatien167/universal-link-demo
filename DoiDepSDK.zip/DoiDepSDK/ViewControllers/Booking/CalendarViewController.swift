//
//  CalendarViewController.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 13/4/25.
//

import UIKit

class CalendarViewController: UIViewController, FSCalendarDelegate, FSCalendarDataSource {

    @IBOutlet weak var calendar: FSCalendar!

    var onDateSelected: ((Date) -> Void)? // callback
    var date: Date = Date()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        updateWeekdayLabels()
    }
    
    private func setupUI() {
        calendar.locale = Locale(identifier: "vi_VN")
        calendar.appearance.caseOptions = [.weekdayUsesSingleUpperCase]
        calendar.appearance.headerDateFormat = "'Tháng' MM yyyy"
    }

    private func updateWeekdayLabels() {
        let vietnameseWeekdays = ["CN", "T2", "T3", "T4", "T5", "T6", "T7"]
        for (index, label) in calendar.calendarWeekdayView.weekdayLabels.enumerated() {
            label.text = vietnameseWeekdays[index]
        }
    }

    @IBAction func dismissTapped(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func doneTapped(_ sender: Any) {
        
        self.dismiss(animated: true) {
            self.onDateSelected?(self.date)
        }
    }
    
    func calendar(_ calendar: FSCalendar, shouldSelect date: Date, at monthPosition: FSCalendarMonthPosition) -> Bool {
        return date >= Date().removeTime()
    }
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        self.date = date
    }
}
