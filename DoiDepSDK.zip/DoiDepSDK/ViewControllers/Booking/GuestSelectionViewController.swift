//
//  GuestSelectionViewController.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 13/4/25.
//

import UIKit

struct GuestSelection {
    var rooms: Int = 1
    var adults: Int = 1
    var children: Int = 0
    
    static let maxRooms = 8
    static let maxAdults = 16
    static let maxChildren = 6
}

class GuestSelectionViewController: UIViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var roomLabel: UILabel!
    @IBOutlet weak var adultLabel: UILabel!
    @IBOutlet weak var childLabel: UILabel!
    
    @IBOutlet weak var decreaseRoomButton: UIButton!
    @IBOutlet weak var increaseRoomButton: UIButton!
    
    @IBOutlet weak var increaseAdultButton: UIButton!
    @IBOutlet weak var decreaseAdultButton: UIButton!
    
    @IBOutlet weak var decreaseChildButton: UIButton!
    @IBOutlet weak var increaseChildButton: UIButton!
    // MARK: - Data
    var guestSelection = GuestSelection()
    
    // Callback về màn hình trước
    var onDone: ((GuestSelection) -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
    }
//    ic_minus_booking_blue
    // MARK: - Update UI
    func updateUI() {
        roomLabel.text = "\(guestSelection.rooms)"
        adultLabel.text = "\(guestSelection.adults)"
        childLabel.text = "\(guestSelection.children)"
        
        decreaseRoomButton.setImage(UIImage().getImage(with: guestSelection.rooms == 1 ? "ic_minus_booking" : "ic_minus_booking_blue", and: Bundle(for: GuestSelectionViewController.self)), for: .normal)
        decreaseAdultButton.setImage(UIImage().getImage(with: guestSelection.adults == 1 ? "ic_minus_booking" : "ic_minus_booking_blue", and: Bundle(for: GuestSelectionViewController.self)), for: .normal)
        decreaseChildButton.setImage(UIImage().getImage(with: guestSelection.children == 0 ? "ic_minus_booking" : "ic_minus_booking_blue", and: Bundle(for: GuestSelectionViewController.self)), for: .normal)
        
        increaseRoomButton.setImage(UIImage().getImage(with: guestSelection.rooms != 8 ? "ic_plus_booking_blue" : "ic_plus_booking", and: Bundle(for: GuestSelectionViewController.self)), for: .normal)
        increaseAdultButton.setImage(UIImage().getImage(with: guestSelection.adults != 16 ? "ic_plus_booking_blue" : "ic_plus_booking", and: Bundle(for: GuestSelectionViewController.self)), for: .normal)
        increaseChildButton.setImage(UIImage().getImage(with: guestSelection.children != 6 ? "ic_plus_booking_blue" : "ic_plus_booking", and: Bundle(for: GuestSelectionViewController.self)), for: .normal)

    }
    
    // MARK: - Room
    @IBAction func increaseRoom(_ sender: UIButton) {
        if guestSelection.rooms < GuestSelection.maxRooms {
                guestSelection.rooms += 1

                // Nếu người lớn đang quá ít cho số phòng hiện tại ⇒ tăng lên (nếu hợp lệ)
                let minAdults = guestSelection.rooms // mỗi phòng ít nhất 1 người lớn
                if guestSelection.adults < minAdults {
                    guestSelection.adults = min(minAdults, GuestSelection.maxAdults)
                }

                updateUI()
            }
    }
    
    @IBAction func decreaseRoom(_ sender: UIButton) {
        if guestSelection.rooms > 1 {
                guestSelection.rooms -= 1

                // Nếu số người lớn vượt quá số chỗ chứa ⇒ giảm xuống
                let maxAdultsAllowed = guestSelection.rooms * 2
                if guestSelection.adults > maxAdultsAllowed {
                    guestSelection.adults = maxAdultsAllowed
                }

                updateUI()
            }
    }
    
    // MARK: - Adults
    @IBAction func increaseAdult(_ sender: UIButton) {
        if guestSelection.adults < GuestSelection.maxAdults {
                guestSelection.adults += 1

                // Mỗi phòng chứa tối đa 2 người lớn
                let requiredRooms = Int(ceil(Double(guestSelection.adults) / 2.0))
                if guestSelection.rooms < requiredRooms {
                    guestSelection.rooms = min(requiredRooms, GuestSelection.maxRooms)
                }

                updateUI()
            }
    }
    
    @IBAction func decreaseAdult(_ sender: UIButton) {
        if guestSelection.adults > 1 {
                guestSelection.adults -= 1

                // Cập nhật lại số phòng nếu phòng dư
//                let requiredRooms = Int(ceil(Double(guestSelection.adults) / 2.0))
                if guestSelection.adults < guestSelection.rooms {
                    guestSelection.rooms -= 1
                }

                updateUI()
            }
    }
    
    // MARK: - Children
    @IBAction func increaseChild(_ sender: UIButton) {
        if guestSelection.children < GuestSelection.maxChildren {
            guestSelection.children += 1
            updateUI()
        }
    }
    
    @IBAction func decreaseChild(_ sender: UIButton) {
        if guestSelection.children > 0 {
            guestSelection.children -= 1
            updateUI()
        }
    }
    
    // MARK: - Done
    @IBAction func doneButtonTapped(_ sender: UIButton) {
        onDone?(guestSelection)
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func closeTapped(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
}

