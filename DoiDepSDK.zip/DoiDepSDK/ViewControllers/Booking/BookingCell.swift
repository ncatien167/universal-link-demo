//
//  BookingCell.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 15/4/25.
//
import UIKit

class BookingCell: UITableViewCell {

    @IBOutlet weak var titleLabel: PaddingLabel!
    @IBOutlet weak var subtitleLabel: UILabel!
    @IBOutlet weak var bookingIdLabel: UILabel!
    @IBOutlet weak var imageRoom: UIImageView!
    
    @IBOutlet weak var deleteBookingLabel: PaddingLabel!
    
    var didDelete: (()->())?
    override func awakeFromNib() {
        super.awakeFromNib()
        // tùy chỉnh thêm nếu cần
        deleteBookingLabel.backgroundColor = Colors.tomato
        deleteBookingLabel.edgeInset = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
        
        titleLabel.edgeInset = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
        let destinationTap = UITapGestureRecognizer(target: self, action: #selector(didTapDelete))
        deleteBookingLabel.addGestureRecognizer(destinationTap)
    }
    
    @objc func didTapDelete() {
        didDelete?()
    }
}
