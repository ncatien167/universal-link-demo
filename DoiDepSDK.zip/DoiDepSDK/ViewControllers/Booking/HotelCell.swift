//
//  HotelCell.swift
//  DoiDepSDK
//
//  Created by Thuyngo on 4/15/25.
//

import UIKit
struct HotelModel {
    var title: String?
    var adultNumber: Int?
    var childrenNumber: Int?
    var type: String?
    var convenientList: [String]?
    var price: Double?
    
}

class HotelCell: UITableViewCell {
    var room: Room?
    
    @IBOutlet weak var lblTotalPerson: UILabel!
    @IBOutlet weak var lblHeader: UILabel!
    
    @IBOutlet weak var lblType: UILabel!
    
    @IBOutlet weak var buttBookingHotel: UIButton!
    @IBOutlet weak var txtDescription: UITextView!
    
    @IBOutlet weak var imgHeader: UIImageView!
    @IBOutlet weak var lblTotalAmount: UILabel!
    
    @IBAction func BookingHotel(_ sender: Any) {
        didTapBook?()
    }
    
    var didTapBook: (() -> Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        configView()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    private func configView() {
        
    }
    
    public func update(_ roomModel : Room?, _ bookingInfo: BookingInfo) {
        room = roomModel
        let urlImage = (bookingInfo.bookingHotel?.ImageHost ?? "") + (room?.image?.first ?? "")
        imgHeader.loadImage(urlString: urlImage, UIImage().getImage(with: "img_empty.png", and: Bundle(for: HotelCell.self))!)
        lblHeader.text = roomModel?.roomType ?? "_"
        lblTotalPerson.text = "\(bookingInfo.guest?.adults ?? 1) người lớn, \(bookingInfo.guest?.children ?? 1) trẻ em"
        lblType.text = roomModel?.roomKind
        txtDescription.text = roomModel?.roomConvinient
        lblTotalAmount.text = room?.price?.formatMoneyBooking
        
    }
    override func prepareForReuse() {
        super.prepareForReuse()
        room = nil
        lblHeader.text = ""
        lblTotalPerson.text = ""
        lblType.text = ""
        txtDescription.text = ""
        lblTotalAmount.text = ""
        buttBookingHotel.titleLabel?.text = ""
    }
}
