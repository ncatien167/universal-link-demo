//
//  HistoryBookingViewController.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 14/4/25.
//

import UIKit

// MARK: - ViewController
final class HistoryBookingViewController: AppNavigationVC {
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var headerHeightConstraint: NSLayoutConstraint!
    private var bookings: [Booking] = []
    
    // MARK: Life‑cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        fetchHistoryData()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        // Chiều cao chuẩn: topInset + chiều cao content (ví dụ 44)
        let topInset = view.safeAreaInsets.top
        headerHeightConstraint.constant = topInset + 44
    }

    
    private func setupUI() {
        self.headerView.isHidden = true
        self.backgroundImageView.isHidden = true
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UINib(nibName: "BookingCell", bundle: nil), forCellReuseIdentifier: "BookingCell")
    }
    
    @IBAction func didTapBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}

extension HistoryBookingViewController: UITableViewDataSource, UITableViewDelegate {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return bookings.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellBooking", for: indexPath) as! BookingCell
        let booking = bookings[indexPath.row]
        let PartnerBookingStatus = booking.PartnerBookingStatus ?? ""
        cell.titleLabel.text = PartnerBookingStatus == "2" ? "Đã huỷ" : "Đặt thành công"
        cell.titleLabel.backgroundColor = PartnerBookingStatus == "2" ? Colors.tomato : Colors.colorD7FAE0
        cell.titleLabel.textColor = PartnerBookingStatus == "2" ? Colors.white : Colors.color00AB56
        cell.subtitleLabel.text = booking.BookingName
        cell.bookingIdLabel.text = "Mã đặt phòng: \(booking.PartnerBookingID ?? 0)"
        cell.deleteBookingLabel.isHidden = PartnerBookingStatus != "2" ? false : true
        cell.didDelete = { [weak self] in
            guard let self = self, let PartnerBookingID = booking.PartnerBookingID else { return }
            self.fetchDeleteData(id: PartnerBookingID)
        }
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}

// MARK: - API
extension HistoryBookingViewController {
    private func fetchHistoryData() {
        DispatchQueue.main.async {
            self.showLoading()
        }
        
        BookingService.requestHistoryHotels { bookings in
            self.bookings = bookings ?? []
            DispatchQueue.main.async {
                self.hideLoading()
                self.tableView.reloadData()
            }
        }
    }
    
    private func fetchDeleteData(id: Int) {
        DispatchQueue.main.async {
            self.showLoading()
        }
        let param: [String: Any] = ["BookingId": id,
                                    "Reason": "Huỷ đặt phòng"]
        BookingService.requestDeleteBooking(params: param) { data in
            self.fetchHistoryData()
        }
    }
}
