//
//  HomeBookingViewController.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 7/4/25.
//

import UIKit

// MARK: - ViewController
final class HomeBookingViewController: AppNavigationVC {
    
    // MARK: UI Components
    
    @IBOutlet weak var destinationValueLabel: UILabel!
    @IBOutlet weak var checkInDateLabel: UILabel!
    @IBOutlet weak var checkOutTitleLabel: UILabel!
    @IBOutlet weak var nightsCountLabel: UILabel!
    @IBOutlet weak var roomGuestSummaryLabel: UILabel!
    @IBOutlet weak var destinationStackView: UIStackView!
    @IBOutlet weak var dateSelectionStackView: UIStackView!
    @IBOutlet weak var guestSelectionStackView: UIStackView!
    @IBOutlet weak var promotionsView: AdsView!
    @IBOutlet weak var popularDestinationsView: AdsView!
    
    private var hotels: [BookingHotel] = []
    private var bookingHotel: BookingHotel?
    private var hotel: Hotel?
    private var numberOfNights = 1
    private var checkInDate = Date()
    private var checkOutDate = Calendar.current.date(byAdding: .day, value: 1, to: Date()) ?? Date()
    private var guest: GuestSelection = GuestSelection(rooms: 1, adults: 1, children: 0)
    
    // MARK: Life‑cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupDataAdsView()
        setupStackViewAction()
        getHotels()
        updateDateInOut()
    }
    
    private func setupUI() {
        self.headerView.isHidden = true
        self.backgroundImageView.isHidden = true
    }

    private func setupDataAdsView() {
        promotionsView.setupUIForBooking(with: CommonService.shared.getBanners(), title: "Ưu đãi")
        popularDestinationsView.setupUIForBooking(with: CommonService.shared.getBanners7(), title: "Điểm đến phổ biến")
    }
    
    private func setupStackViewAction() {
        let destinationTap = UITapGestureRecognizer(target: self, action: #selector(didTapDestination))
        destinationStackView.addGestureRecognizer(destinationTap)

        let dateTap = UITapGestureRecognizer(target: self, action: #selector(didTapDateSelection))
        dateSelectionStackView.addGestureRecognizer(dateTap)

        let guestTap = UITapGestureRecognizer(target: self, action: #selector(didTapGuestSelection))
        guestSelectionStackView.addGestureRecognizer(guestTap)
    }
    
    // MARK: - Update UI
    private func updateGuestUI(with guest: GuestSelection) {
        roomGuestSummaryLabel.text = "\(guest.rooms) phòng, \(guest.adults) người lớn, \(guest.children) trẻ em"
    }
    
    private func updateDateInOut() {
        checkInDateLabel.text = checkInDate.toString(dateFormat: "EEEE, dd/MM/yyyy")
        checkOutTitleLabel.text = checkOutDate.toString(dateFormat: "EEEE, dd/MM/yyyy")
        nightsCountLabel.text = "\(numberOfNights) đêm"
    }
    
    // MARK: - Action
    @IBAction func backAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func bookingHistoryAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Booking", bundle: nil)
        if let vc = storyboard.instantiateViewController(withIdentifier: "BookingPaymentViewController") as? BookingPaymentViewController {
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @IBAction func searchAction(_ sender: Any) {
        showLoading()
        searchHotel()
    }
    
    @objc func didTapDestination() {
        let storyboard = UIStoryboard(name: "Booking", bundle: nil)
        if let vc = storyboard.instantiateViewController(withIdentifier: "SelectHotelViewController") as? SelectHotelViewController {
            vc.modalPresentationStyle = .overFullScreen
            vc.modalTransitionStyle = .coverVertical
            vc.hotels = hotels
            vc.onDone = { [weak self] bookingHotel in
                self?.bookingHotel = bookingHotel
                self?.destinationValueLabel.text = bookingHotel.Name
            }
            self.present(vc, animated: true, completion: nil)
        }
    }

    @objc func didTapDateSelection() {
        let storyboard = UIStoryboard(name: "Booking", bundle: nil)
        if let vc = storyboard.instantiateViewController(withIdentifier: "CalendarViewController") as? CalendarViewController {
            vc.modalPresentationStyle = .overFullScreen
            vc.modalTransitionStyle = .coverVertical
            vc.onDateSelected = { [weak self] date in
                self?.checkInDate = date
                self?.didTapStayDurationSelection()
            }
            self.present(vc, animated: true, completion: nil)
        }
    }
    
    func didTapStayDurationSelection() {
        let storyboard = UIStoryboard(name: "Booking", bundle: nil)
        if let vc = storyboard.instantiateViewController(withIdentifier: "StayDurationViewController") as? StayDurationViewController {
            vc.modalPresentationStyle = .overFullScreen
            vc.modalTransitionStyle = .coverVertical
            vc.checkInDate = checkInDate
            vc.onDone = { [weak self] night, date in
                self?.checkOutDate = date
                self?.numberOfNights = night
                self?.updateDateInOut()
            }
            self.present(vc, animated: true, completion: nil)
        }
    }

    @objc func didTapGuestSelection() {
        let storyboard = UIStoryboard(name: "Booking", bundle: nil)
        if let vc = storyboard.instantiateViewController(withIdentifier: "GuestSelectionViewController") as? GuestSelectionViewController {
            vc.modalPresentationStyle = .overFullScreen
            vc.modalTransitionStyle = .coverVertical
            vc.guestSelection = self.guest
            vc.onDone = { [weak self] guest in
                self?.guest = guest
                self?.updateGuestUI(with: guest)
            }
            self.present(vc, animated: true, completion: nil)
        }
    }
    
    private func pushToListHotel(bookingInfo: BookingInfo) {
        let storyboard = UIStoryboard(name: "Booking", bundle: nil)
        if let vc = storyboard.instantiateViewController(withIdentifier: "ListRoomlViewController") as? ListRoomlViewController {
            vc.hotel = self.hotel
            vc.bookingInfo = bookingInfo
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @IBAction func historyBookingTapped(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Booking", bundle: nil)
        if let vc = storyboard.instantiateViewController(withIdentifier: "HistoryBookingViewController") as? HistoryBookingViewController {
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
}

// MARK: - API
extension HomeBookingViewController {
    private func getHotels() {
        showLoading()
        BookingService.requestGetHotels { hotels in
            DispatchQueue.main.async {
                self.hideLoading()
                self.hotels = hotels ?? []
                self.destinationValueLabel.text = hotels?.first?.Name
                self.bookingHotel = hotels?.first
            }
        }
    }
    
    private func searchHotel() {
        let dayInt = checkInDate.toString(dateFormat: "yyyy-MM-dd")
        let dayOut = checkOutDate.toString(dateFormat: "yyyy-MM-dd")
        let hotelCoded = bookingHotel?.Code ?? ""
        let countGuest = guest.adults
        let countRoom = guest.rooms
        let params: [String : Any] = ["hotelCode": hotelCoded,
                      "dayIn": dayInt,
                      "dayOut": dayOut,
                      "countGuest": countGuest,
                      "countRoom": countRoom]
        BookingService.requestSearchHotels(params: params) { hotel in
            DispatchQueue.main.async {
                self.hideLoading()
                self.hotel = hotel
                let bookingInfo = BookingInfo(checkInDate: self.checkInDate, checkOutDate: self.checkOutDate, bookingHotel: self.bookingHotel, guest:  self.guest, hotel: hotel, numberOfNight: self.numberOfNights)
                self.pushToListHotel(bookingInfo: bookingInfo)
            }
        }
    }
}

struct BookingInfo {
    var checkInDate: Date?
    var checkOutDate: Date?
    var bookingHotel: BookingHotel?
    var guest: GuestSelection?
    var hotel: Hotel?
    var numberOfNight: Int
}
