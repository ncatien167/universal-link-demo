//
//  StayOptionCell.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 13/4/25.
//

import UIKit

class StayOptionCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var subtitleLabel: UILabel!
    @IBOutlet weak var radioImageView: UIImageView! // icon chọn tròn
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // tùy chỉnh thêm nếu cần
    }
}

