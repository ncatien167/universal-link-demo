//
//  ListHotelViewController.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 17/4/25.
//

import UIKit

class ListRoomlViewController: UIViewController {
    
    @IBOutlet weak var lblHeader: UILabel!
    
    @IBOutlet weak var lblcalender: UILabel!
    @IBOutlet weak var hotelTable: UITableView!
    @IBOutlet weak var lblNight: UILabel!
    @IBOutlet weak var lblRoom: UILabel!
    @IBOutlet weak var lblPerson: UILabel!
    
    @IBOutlet weak var numberOfNightLabel: UILabel!
    @IBOutlet weak var numberOfRoomLabel: UILabel!
    @IBOutlet weak var numberAdultLabel: UILabel!

    @IBOutlet weak var headerHeightConstraint: NSLayoutConstraint!
    
    var rooms: [Room] = []
    var hotel: Hotel?
    var room: Room?
    var bookingInfo: BookingInfo?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configLayout()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        // Chiều cao chuẩn: topInset + chiều cao content (ví dụ 44)
        let topInset = view.safeAreaInsets.top
        headerHeightConstraint.constant = topInset + 44
    }
    
    private func configLayout() {
        lblHeader.text = bookingInfo?.bookingHotel?.Name?.uppercased()
        numberOfNightLabel.text = "\(bookingInfo?.numberOfNight ?? 1)"
        numberOfRoomLabel.text = "\(bookingInfo?.guest?.rooms ?? 1)"
        numberAdultLabel.text = "\(bookingInfo?.guest?.adults ?? 1)"
        
        rooms = hotel?.availableRoom ?? []
        hotelTable.delegate = self
        hotelTable.dataSource = self
        hotelTable.separatorStyle = .none
        hotelTable.tableFooterView = UIView(frame: CGRect(x: 0,y: 0,width: 0,height: 1))

        let nib = UINib(nibName: "HotelCell", bundle: nil)
        hotelTable.register(nib, forCellReuseIdentifier: "HotelCell")
        hotelTable.reloadData()
    }
    
    @IBAction func didTapBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func homeBookingBackAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    private func pushToPaymentBooking() {
        let storyboard = UIStoryboard(name: "Booking", bundle: nil)
        if let vc = storyboard.instantiateViewController(withIdentifier: "BookingPaymentViewController") as? BookingPaymentViewController {
            vc.room = self.room
            vc.bookingInfo = self.bookingInfo
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    private func presentRoomDetail() {
        let storyboard = UIStoryboard(name: "Booking", bundle: nil)
        if let vc = storyboard.instantiateViewController(withIdentifier: "RoomInfoViewController") as? RoomInfoViewController {
            vc.modalPresentationStyle = .overFullScreen
            vc.modalTransitionStyle = .coverVertical
            vc.room = self.room
            vc.bookingInfo = self.bookingInfo
            vc.onDone = { [weak self] in
                self?.pushToPaymentBooking()
            }
            self.present(vc, animated: true, completion: nil)
        }
    }
}


extension ListRoomlViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return rooms.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "HotelCell", for: indexPath) as? HotelCell, let bookingInfo = bookingInfo else {
            return UITableViewCell()
        }
        cell.update(rooms[indexPath.row], bookingInfo)
        cell.didTapBook = { [weak self] in
            self?.room = self?.rooms[indexPath.row]
            self?.presentRoomDetail()
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let uiview = UIView()
        
        let lblHeader : UILabel = {
            let lbl = UILabel()
            lbl.text = bookingInfo?.bookingHotel?.Name
            lbl.font = UIFont.boldSystemFont(ofSize: lbl.font.pointSize)
            lbl.translatesAutoresizingMaskIntoConstraints = false
            return lbl
        }()
        uiview.addSubview(lblHeader)
        lblHeader.topAnchor.constraint(equalTo: uiview.topAnchor, constant: 10).isActive = true
        lblHeader.bottomAnchor.constraint(equalTo: uiview.bottomAnchor, constant: -10).isActive = true
        lblHeader.leadingAnchor.constraint(equalTo: uiview.leadingAnchor, constant: 10).isActive = true
        lblHeader.trailingAnchor.constraint(equalTo: uiview.trailingAnchor, constant: -10).isActive = true
        return uiview
    }
}
