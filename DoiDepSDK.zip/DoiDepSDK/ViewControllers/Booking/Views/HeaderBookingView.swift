//
//  HeaderBookingView.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 7/4/25.
//

import UIKit

/// Header ở màn Booking – có logo bên trái, 3 nút bên phải trên nền ảnh.
final class HeaderBookingView: UIView {

    // MARK: - Action enum
    enum Action {
        case invoice     // nút “tờ hoá đơn”
        case more        // nút “⋯”
        case close       // nút “x”
    }
    /// Callback khi người dùng chạm vào 1 trong 3 nút
    var onAction: ((Action) -> Void)?

    // MARK: - Sub‑views
    private let backgroundImageView: UIImageView = {
        let iv = UIImageView(image: UIImage(named: "bg_booking_header"))
        iv.contentMode = .scaleAspectFill
        iv.clipsToBounds = true
        return iv
    }()

    private let logoImageView: UIImageView = {
        let iv = UIImageView(image: UIImage(named: "logo_doi_dep_booking")) // asset logo đã có
        iv.contentMode = .scaleAspectFit
        return iv
    }()

    private lazy var invoiceButton = makeCircleButton(systemName: "ic_wapper_booking", action: #selector(didTapInvoice))
    private lazy var moreButton    = makeButton(systemName: "ic_more_booking",                action: #selector(didTapMore))
    private lazy var closeButton   = makeButton(systemName: "ic_exit_booking",                   action: #selector(didTapClose))

    // MARK: - Init
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
        setupConstraints()
    }
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupViews()
        setupConstraints()
    }
}

// MARK: - Private helpers
private extension HeaderBookingView {

    func setupViews() {
        addSubview(backgroundImageView)
        addSubview(logoImageView)

        // nhóm 3 nút trong 1 UIStackView cho gọn
        let viewLine = UIView()
        let stackExit = UIStackView(arrangedSubviews: [moreButton, viewLine, closeButton])
        stackExit.axis = .horizontal
        stackExit.spacing = 8
        viewLine.snp.makeConstraints { make in
            make.width.equalTo(0.5)
        }
        
        let stack = UIStackView(arrangedSubviews: [invoiceButton, stackExit])
        stack.axis = .horizontal
        stack.spacing = 8
        addSubview(stack)
        stack.snp.makeConstraints { make in
            make.right.equalToSuperview().inset(16)
            make.centerY.equalTo(logoImageView)
        }
    }

    func setupConstraints() {
        backgroundImageView.snp.makeConstraints { $0.edges.equalToSuperview() }

        logoImageView.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(16)
            make.top.equalTo(safeAreaLayoutGuide).offset(4)
            make.bottom.equalToSuperview().inset(8)
            make.height.equalTo(32)          // tuỳ chỉnh theo logo
            make.width.lessThanOrEqualTo(120)
        }
    }

    // tạo nút tròn blur
    func makeCircleButton(systemName: String, action: Selector) -> UIButton {
        let button = UIButton(type: .system)
        button.setImage(UIImage(systemName: systemName), for: .normal)
        button.tintColor = .white
        button.backgroundColor = Colors.blackAlpha20
        button.layer.cornerRadius = 18
        button.clipsToBounds = true
        button.addTarget(self, action: action, for: .touchUpInside)
        button.snp.makeConstraints { $0.size.equalTo(CGSize(width: 36, height: 36)) }
        return button
    }
    func makeButton(systemName: String, action: Selector) -> UIButton {
        let button = UIButton(type: .system)
        button.setImage(UIImage(systemName: systemName), for: .normal)
        button.imageEdgeInsets = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
        button.tintColor = .white
        button.clipsToBounds = true
        button.addTarget(self, action: action, for: .touchUpInside)
        button.snp.makeConstraints { $0.size.equalTo(CGSize(width: 36, height: 36)) }
        return button
    }
    // MARK: - Actions
    @objc func didTapInvoice() { onAction?(.invoice) }
    @objc func didTapMore()    { onAction?(.more)    }
    @objc func didTapClose()   { onAction?(.close)   }
}
