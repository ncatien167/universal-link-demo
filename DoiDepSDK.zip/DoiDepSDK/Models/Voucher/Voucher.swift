//
//  Voucher.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 24/07/2022.
//

import Foundation

class VoucherService {
    static let shared = VoucherService()
    private init() { }
    
    var vouchers: [Voucher] = []
    
    func setDataVouchers(with datas: [Voucher]) {
        self.vouchers = datas.filter({
            return ($0.UseFor?.uppercased() == "ALL" || $0.UseFor == "NAB")
        })
    }
    
    func getVouchers() -> [Voucher] {
        return self.vouchers
    }
    
}
struct Voucher: Codable {
    var ID: Int?
    var Name: String?
    var Code: String?
    var Description: String?
    var BeginDate: String?
    var ExpireDate: String?
    var Amount: Double?
    var `Type`: Int?
    var Android: Bool?
    var IOS: Bool?
    var Web: Bool?
    var ProductAmoutMin: Double?
    var ProductAmoutMax: Double?
    var ProductCategoryList: String?
    var Available: Int?
    var Terms: String?
    var Status: Int?
    var CreatedAt: String?
    var CreatedBy: Int?
    var ModifiedAt: String?
    var ModifiedBy: Int?
    var Percent: Int?
    var UseType: Int?
    var UseFor: String?
}

enum VoucherUseType: Int {
    case amount = 1
    case precent = 2
}
