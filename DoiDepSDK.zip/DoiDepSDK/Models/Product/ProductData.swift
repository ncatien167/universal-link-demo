//
//  ProductData.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 16/07/2022.
//

import Foundation

struct ProductData: Codable {
    var ID: Int?
    var CategoryID: Int?
    var CategoryName: String?
    var SKU: String?
    var Name: String?
    var Alias: String?
    var Thumbnail: String?
    var InStock: Int?
    var PriceStatus: Int?
    var Price: Double?
    var Status: Int?
    var IsLove: Bool?
    
    // More for Detail
    var Note: String?
    var Summary: String?
    var Description: String?
    var OptionGroups: [OptionGroups]?
    var Prices: [Prices]?
    
    func getGroupID(with OptionValue: String) -> Int? {
        guard let prices = self.Prices else {
            return nil
        }
        
        if OptionGroups?.count == 0 {
            return prices.first?.GroupID
        }
        
        for price in prices {
            for detail in (price.Details ?? []) {
                if detail.Value == OptionValue {
                    return price.GroupID
                }
            }
        }
        
        return nil
    }
    
    func price(with OptionValue: String) -> Double {
        guard let Prices = Prices else {
            return 0
        }
        var priceProduct: Double = 0
        for price in Prices {
            if price.GroupID == self.getGroupID(with: OptionValue) {
                priceProduct = price.Price ?? 0
                break
            }
        }
        return priceProduct
    }
    
    func price() -> Double {
        guard let Prices = Prices else {
            return 0
        }
        var priceProduct: Double = 0
        priceProduct = Prices.first?.Price ?? 0
        return priceProduct
    }
}

struct OptionGroups: Codable {
    var ID: Int?
    var GroupName: String?
    var OptionDetails: [Details]?
}

struct Prices: Codable {
    var GroupID: Int?
    var Price: Double?
    var Details: [Details]?
}

struct Details: Codable {
    var OptionValue: String?
    var Value: String?
}
