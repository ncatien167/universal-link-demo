//
//  ProductService.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 16/07/2022.
//

import Foundation

struct ProductService {
    static func requestProductForYou(completion: (([ProductData]?) -> Void)? = nil) {
        APIController.request([ProductData].self, .forYou, params: nil) { error, data in
            if let _ = error {
                completion?([])
                return
            }
            
            completion?(data)
        }
    }
    
    static func requestProductByCategory(with category: Int, completion: (([ProductData]?) -> Void)? = nil) {
        APIController.request([ProductData].self, .byCategory(category), params: nil) { error, data in
            if let _ = error {
                completion?([])
                return
            }
            
            completion?(data)
        }
    }
    
    static func requestProductDetail(with ID: Int, completion: ((ProductData?) -> Void)? = nil) {
        APIController.request(ProductData.self, .productDetail(ID), params: nil) { error, data in
            if let error = error {
                completion?(nil)
                Logger.log(message: error, event: .error)
                return
            }
            
            completion?(data)
        }
    }
    
    static func requestSearchProduct(with query: String, and page: Int, completion: ((ResponseSearchProduct<ProductData>?) -> Void)? = nil) {
        APIController.request(ResponseSearchProduct<ProductData>.self, .searchProduce(String(query.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed) ?? ""), "\(page)"), params: nil) { error, data in
            if let error = error {
                Logger.log(message: error, event: .error)
                completion?(nil)
                return
            }
            
            completion?(data)
        }
    }
}
