//
//  VATData.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 18/07/2022.
//

import Foundation
