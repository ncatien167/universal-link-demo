//
//  OrderManager.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 18/07/2022.
//

import UIKit

class OrderManager {
    static let shared = OrderManager()
    private var orderData: OrderData?
    private var orderDetails: [OrderDetail]? = []
    private init() { }
    
    func addNewOrderDetails(with orderDetail: OrderDetail) {
        orderDetails?.append(orderDetail)
        orderData?.OrderDetails = orderDetails
    }
    
    func setOrderData(with data: OrderData) {
        self.orderData = data
    }
    
    func removeOrderManagerData() {
        orderData = nil
        orderDetails = []
    }
}

struct OrderService {
    static func requestOrder(with orderData: OrderData, completion: ((Bool?, OrderResponse?) -> Void)? = nil) {
        let param = orderData.convertObjectToDictionary
        Logger.log(message: "requestOrder with param: \(param)", event: .debug)
        APIController.request(OrderResponse.self, .order, params: param) { error, data in
            if let error = error {
                Logger.log(message: "requestOrder Fail with Error: \(error)", event: .error)
                completion?(false, data)
                return
            }
            Logger.log(message: "requestOrder Data: \(data ?? OrderResponse())", event: .debug)
            completion?(true, data)
        }
    }
    
    static func requestGetYourOrder(with ID: Int, completion: ((Bool?, [OrderData]?) -> Void)? = nil) {
        APIController.request([OrderData].self, .yourOrdered(ID), params: nil) { error, data in
            if let error = error {
                Logger.log(message: "requestGetYourOrder Fail with Error: \(error)", event: .error)
                completion?(false, [])
                return
            }
            Logger.log(message: "requestGetYourOrder Data: \(data ?? [])", event: .debug)
            completion?(true, data)
        }
    }
    
    static func requestDeleteYourOrder(with code: String, completion: ((Bool?, String?) -> Void)? = nil) {
        APIController.request(String.self, .deleteOrder(code), params: nil) { error, data in
            if let error = error {
                Logger.log(message: "requestDeleteYourOrder Fail with Error: \(error)", event: .error)
                completion?(false, "")
                return
            }
            Logger.log(message: "requestDeleteYourOrder Data: \(data ?? "")", event: .debug)
            completion?(true, data)
        }
    }
}

struct OrderData: Codable {
    var ID: Int?
    var Code: String?
    var UserID: Int?
    var Price: Double?
    var Province: Int?
    var ProvinceName: String?
    var District: Int?
    var DistrictName: String?
    var Ward: Int?
    var WardName: String?
    var ShipName: String?
    var ShipAddress: String?
    var Phone: String?
    var StoreID: Int?
    var PaymentMethod: Int?
    var VoucherCode: String?
    var Discount: Double?
    var OrderDetails: [OrderDetail]?
    var IsVAT: Bool?
    var Status: Int?
    var VATCompanyName: String?
    var VATTaxCode: String?
    var VATEmail: String?
    var VATAddress: String?
    var Message: String?
    var VATInfor: VatInfor?
    var CreatedAt: String?
    var Voucher: Voucher?
    
    func totalQuantity() -> Int {
        guard let OrderDetails = OrderDetails else {
            return 0
        }
        var quantity = 0
        for OrderDetail in OrderDetails {
            quantity = quantity + (OrderDetail.Quantity ?? 0)
        }
        
        return quantity
    }
    
    func totalPrice() -> String {
        guard let OrderDetails = OrderDetails else {
            return "0đ"
        }
        
        var price: Double = 0
        for OrderDetail in OrderDetails {
            price = price + (Double(OrderDetail.Quantity ?? 0) * (OrderDetail.Price ?? 0))
        }
        
        return price.formatMoney
    }
    
    func totalPriceDouble() -> Double {
        guard let OrderDetails = OrderDetails else {
            return 0
        }
        
        var price: Double = 0
        for OrderDetail in OrderDetails {
            price = price + (Double(OrderDetail.Quantity ?? 0) * (OrderDetail.Price ?? 0))
        }
        
        return price
    }
}

struct OrderResponse: Codable {
    var OrderCode: String?
    var Url: String?
    var OrderDetails: [OrderDetail]?
    var UserName: String?
    var Phone: String?
    var Message: String?
    var Voucher: Voucher?
}

struct OrderDetail: Codable {
    var ProductID: Int?
    var GroupID: Int?
    var SKU: String?
    var Quantity: Int?
    var Note: String?
    var Thumbnail: String?
    var Price: Double?
    var ProductName: String?
}
