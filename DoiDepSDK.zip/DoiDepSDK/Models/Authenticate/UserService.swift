//
//  UserService.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 15/07/2022.
//

import Foundation

class UserService {
    
    static let shared = UserService()
    
    var isLoggedIn: Bool = false
    private var userData: UserData?
    
    private init() { }
    
    func setDataUser(with data: UserData) {
        self.userData = data
        self.isLoggedIn = true
    }
    
    func getDataUser() -> UserData {
        guard let userData = self.userData else {
            return UserData()
        }

        return userData
    }

    func removeDataUserService() {
        userData = nil
        isLoggedIn = false
    }
    
    func isMissingInfo() -> Bool {
        guard let userData = userData else {
            return true
        }

        guard let firstName = userData.FirstName, let lastName = userData.LastName, let fullName = userData.FullName else {
            return true
        }
        
        if firstName == "" {
            return true
        }
        
        if lastName == "" {
            return true
        }
        
        if fullName == "" {
            return true
        }
        
        return false
    }
}
