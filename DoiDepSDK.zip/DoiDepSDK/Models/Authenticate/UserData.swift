//
//  UserData.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 15/07/2022.
//

import Foundation

struct UserData: Codable {
    var ID: Int?
    var Phone: String?
    var Email: String?
    var Avatar: String?
    var FirstName: String?
    var LastName: String?
    var FullName: String?
    var Province: Int?
    var ProvinceName: String?
    var District: Int?
    var DistrictName: String?
    var Ward: Int?
    var WardName: String?
    var Address: String?
    var BirdthDay: String?
    var Gender: Int?
    var EmailVerified: Bool?
    var PhoneVerified: Bool?
    var Token: String?
    var IsVAT: Bool?
    var VatInfor: VatInfor?
    var Message: String? // Dùng để bắt báo lỗi
    
    func isRequestErrorWith() -> Bool {
        guard let _ = self.Message else {
            return false
        }
        
        return true
    }
    
    func getMessage() -> String {
        guard let Message = self.Message else {
            return ""
        }
        
        return Message
    }
    
    func getPhone() -> String {
        guard let phone = Phone else {
            return ""
        }
        
        return phone
    }
    
    func getEmail() -> String {
        guard let email = Email else {
            return ""
        }
        
        return email
    }
    
    func getToken() -> String {
        guard let Token = Token else {
            return ""
        }
        
        return Token
    }
}

struct VatInfor: Codable {
    var ID: Int?
    var OrderCode: String?
    var UserID: Int?
    var CompanyName: String?
    var TaxCode: String?
    var Email: String?
    var Address: String?
    var CreatedAt: String?
    
    static func requestEditVat(with companyName: String, taxNumber: String, email: String, address: String, completion: ((Bool?, String?) -> Void)? = nil) {
        let param: [String:Any] = ["isVAT":true, "VATCompanyName":companyName, "VATTaxCode":taxNumber, "VATEmail":email, "VATAddress":address]
        APIController.request(String.self, .editVAT, params: param) { error, data in
            if let error = error {
                Logger.log(message: "requestEditVar Fail with: \(error)", event: .error)
                completion?(false, "Tên đăng nhập hoặc mật khẩu không đúng")
                return
            }
            
            if let data = data {
                var userData = UserService.shared.getDataUser()
                userData.IsVAT = true
                userData.VatInfor = VatInfor(ID: nil, UserID: userData.ID, CompanyName: companyName, TaxCode: taxNumber, Email: email, Address: address, CreatedAt: nil)
                UserService.shared.setDataUser(with: userData)
                Logger.log(message: "requestEditVar Succes with: \(data)", event: .debug)
                completion?(true, data)
                return
            }
        }
    }
}
