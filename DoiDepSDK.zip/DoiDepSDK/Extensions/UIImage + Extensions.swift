//
//  UIImage + Extensions.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 01/08/2022.
//

import UIKit

extension UIImage {
    func getImage(with name: String, and bundle: Bundle?) -> UIImage? {
        return UIImage(named: name, in: bundle, compatibleWith: nil)
    }
}
