//
//  UILabel + Extensions.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 21/07/2022.
//

import UIKit

class PaddingLabel: UILabel {

    var edgeInset: UIEdgeInsets = .zero

    override func drawText(in rect: CGRect) {
        let insets = UIEdgeInsets.init(top: edgeInset.top, left: edgeInset.left, bottom: edgeInset.bottom, right: edgeInset.right)
        super.drawText(in: rect.inset(by: insets))
    }

    override var intrinsicContentSize: CGSize {
        let size = super.intrinsicContentSize
        return CGSize(width: size.width + edgeInset.left + edgeInset.right, height: size.height + edgeInset.top + edgeInset.bottom)
    }
}

extension UILabel {
     func setHTMLFromString(htmlText: String) {
          let content = htmlText.replacingOccurrences(of: "\n", with: "")
          let modifiedFont = String(format:"<span style=\"font-family: 'OpenSans'; font-size: \(UIScreen.main.bounds.width/28.84)\">%@</span>", content)
          
          
          //process collection values
          let attrStr = try? NSAttributedString(
               data: modifiedFont.data(using: .unicode, allowLossyConversion: true)!,
               options: convertToNSAttributedStringDocumentReadingOptionKeyDictionary([convertFromNSAttributedStringDocumentAttributeKey(NSAttributedString.DocumentAttributeKey.documentType): convertFromNSAttributedStringDocumentType(NSAttributedString.DocumentType.html), convertFromNSAttributedStringDocumentAttributeKey(NSAttributedString.DocumentAttributeKey.characterEncoding): String.Encoding.utf8.rawValue]),
               documentAttributes: nil)

          self.attributedText = attrStr
     }
     
     func configSizeToFit() {
          self.numberOfLines = 0
          self.lineBreakMode = .byWordWrapping
          self.sizeToFit()
     }
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertToNSAttributedStringDocumentReadingOptionKeyDictionary(_ input: [String: Any]) -> [NSAttributedString.DocumentReadingOptionKey: Any] {
    return Dictionary(uniqueKeysWithValues: input.map { key, value in (NSAttributedString.DocumentReadingOptionKey(rawValue: key), value)})
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertFromNSAttributedStringDocumentAttributeKey(_ input: NSAttributedString.DocumentAttributeKey) -> String {
    return input.rawValue
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertFromNSAttributedStringDocumentType(_ input: NSAttributedString.DocumentType) -> String {
    return input.rawValue
}
