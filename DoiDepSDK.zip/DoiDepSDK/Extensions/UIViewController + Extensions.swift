//
//  UIViewController + Extensions.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 18/07/2022.
//

import UIKit

extension UIViewController {
     ///topMostViewController return top view controller
     static func topMostViewController() -> UIViewController? {
          if #available(iOS 13.0, *) {
               let keyWindow = UIApplication.shared.windows.filter {$0.isKeyWindow}.first
               return keyWindow?.rootViewController?.topMostViewController()
          } else {
               return UIApplication.shared.keyWindow?.rootViewController?.topMostViewController()
               
          }
     }
     
     ///topMostViewController return top view controller
     func topMostViewController() -> UIViewController? {
          if let navigationController = self as? UINavigationController {
               return navigationController.topViewController?.topMostViewController()
          }
          else if let tabBarController = self as? UITabBarController {
               if let selectedViewController = tabBarController.selectedViewController {
                    return selectedViewController.topMostViewController()
               }
               return tabBarController.topMostViewController()
          }
          else if let presentedViewController = self.presentedViewController {
               return presentedViewController.topMostViewController()
          }
          else {
               return self
          }
     }
     
//     func showToast(message : String) {
//          DispatchQueue.main.async {
//               let toastLabel = UILabel(frame: CGRect(x: 0, y: self.view.frame.size.height-100, width: self.view.frame.size.width*2/3, height: 35))
//               toastLabel.center.x = self.view.center.x
//               toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.6)
//               toastLabel.textColor = UIColor.white
//               toastLabel.textAlignment = .center;
//               toastLabel.font = .appRegular(size: 16)
//               toastLabel.adjustsFontSizeToFitWidth = true
//               toastLabel.text = message
//               toastLabel.alpha = 1.0
//               toastLabel.layer.cornerRadius = 10;
//               toastLabel.clipsToBounds  =  true
//               self.view.addSubview(toastLabel)
//               UIView.animate(withDuration: 4.0, delay: 0.1, options: .curveEaseOut, animations: {
//                    toastLabel.alpha = 0.0
//               }, completion: {(isCompleted) in
//                    toastLabel.removeFromSuperview()
//               })
//          }
//     }
}
