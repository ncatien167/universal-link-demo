//
//  Encodable + Extensions.swift
//  DoiDepSDK
//
//  Created by PTVH Mac Mini 2 on 22/07/2022.
//

import Foundation

struct JSONs {
     static let encoder = JSONEncoder()
}

extension Encodable {
     subscript(key: String) -> Any? {
          return convertObjectToDictionary[key]
     }
     var convertObjectToDictionary: [String: Any] {
          return (try? JSONSerialization.jsonObject(with: JSONs.encoder.encode(self))) as? [String: Any] ?? [:]
     }
     
     func toDictData() -> [String: Any]? {
         do {
             let jsonData = try JSONEncoder().encode(self)
             if let jsonString = String(data: jsonData, encoding: .utf8), let data = (jsonString.convertToDictionary()) {
                 return data
             } else {
                 return nil
             }
         } catch {
             Logger.log(message: "\(error)", event: .error)
             return nil
         }
     }
}

extension String {
    func convertToDictionary() -> [String: Any]? {
         if let data = self.data(using: .utf8) {
              do {
                   return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
              } catch {
                   print(error.localizedDescription)
              }
         }
         return nil
    }
}
