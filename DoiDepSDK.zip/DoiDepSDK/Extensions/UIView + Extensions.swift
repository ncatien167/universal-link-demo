//
//  UIView + Extesions.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 15/07/2022.
//

import Foundation
import UIKit

// MARK: - Support Constraint SnapKit
extension UIView {
    func setConstraintWidth(constant: CGFloat = 375.widthRatio) {
        self.snp.makeConstraints { (make) in
            make.width.equalTo(constant)
        }
    }
    
    func updateConstraintWidth(constant: CGFloat = 375.widthRatio) {
        self.snp.updateConstraints { (make) in
            make.width.equalTo(constant)
        }
    }
    
    func setConstraintHeight(constant: CGFloat = 50.heightRatio) {
        self.snp.makeConstraints { (make) in
            make.height.equalTo(constant)
        }
    }
    
    func updateConstraintHeight(constant: CGFloat = 50.heightRatio) {
        self.snp.updateConstraints { (make) in
            make.height.equalTo(constant)
        }
    }
    
    func setConstraintWidthAndHeight( widthConstant: CGFloat = 375.widthRatio,  heightConstant: CGFloat = 50.heightRatio) {
        self.snp.makeConstraints { (make) in
            make.width.equalTo(widthConstant)
            make.height.equalTo(heightConstant)
        }
    }
    
    func updateConstraintWidthAndHeight( widthConstant: CGFloat = 375.widthRatio,  heightConstant: CGFloat = 50.heightRatio) {
        self.snp.updateConstraints { (make) in
            make.width.equalTo(widthConstant)
            make.height.equalTo(heightConstant)
        }
    }
    
    func setConstraintLeading(_ constant: CGFloat = 16.widthRatio) {
        self.snp.makeConstraints { (make) in
            make.leading.equalTo(constant)
        }
    }
    
    func updateConstraintLeading(_ constant: CGFloat = 16.widthRatio) {
        self.snp.updateConstraints { (make) in
            make.leading.equalTo(constant)
        }
    }
    
    func setConstraintTrailing(_ constant: CGFloat = 16.widthRatio) {
        self.snp.makeConstraints { (make) in
            make.trailing.equalTo(constant)
        }
    }
    
    func updateConstraintTrailing(_ constant: CGFloat = 16.widthRatio) {
        self.snp.updateConstraints { (make) in
            make.trailing.equalTo(constant)
        }
    }
    
    func setConstraintTop(_ constant: CGFloat = 16.heightRatio) {
        self.snp.makeConstraints { (make) in
            make.top.equalTo(constant)
        }
    }
    
    func updateConstraintTop(_ constant: CGFloat = 16.heightRatio) {
        self.snp.updateConstraints { (make) in
            make.top.equalTo(constant)
        }
    }
    
    func setConstraintBottom(_ constant: CGFloat = 16.heightRatio) {
        self.snp.makeConstraints { (make) in
            make.bottom.equalTo(constant)
        }
    }
    
    func updateConstraintBottom(_ constant: CGFloat = 16.heightRatio) {
        self.snp.updateConstraints { (make) in
            make.bottom.equalTo(constant)
        }
    }
    
    func setConstraintLeadingAndTrailing( leadingConstant: CGFloat = 375.widthRatio,  trailingConstant: CGFloat = 50.heightRatio) {
        self.snp.makeConstraints { (make) in
            make.leading.equalTo(leadingConstant)
            make.trailing.equalTo(trailingConstant)
        }
    }
    
    func updateConstraintLeadingAndTrailing( leadingConstant: CGFloat = 375.widthRatio,  trailingConstant: CGFloat = 50.heightRatio) {
        self.snp.updateConstraints { (make) in
            make.leading.equalTo(leadingConstant)
            make.trailing.equalTo(trailingConstant)
        }
    }
    
    func setConstraintTopAndBottom( topConstant: CGFloat = 375.widthRatio,  bottomConstant: CGFloat = 50.heightRatio) {
        self.snp.makeConstraints { (make) in
            make.top.equalTo(topConstant)
            make.bottom.equalTo(bottomConstant)
        }
    }
    
    func updateConstraintTopAndBottom( topConstant: CGFloat = 375.widthRatio,  bottomConstant: CGFloat = 50.heightRatio) {
        self.snp.updateConstraints { (make) in
            make.top.equalTo(topConstant)
            make.bottom.equalTo(bottomConstant)
        }
    }
}

// MARK: - Another Extension
extension UIView {
    func addSubviews(_ views: UIView...) {
        views.forEach{ addSubview($0) }
    }
    
    var safeAreaBottom: CGFloat {
        if #available(iOS 11, *) {
            if let window = UIApplication.shared.keyWindowInConnectedScenes {
                return window.safeAreaInsets.bottom
            }
        }
        return 0
    }
    
    var safeAreaTop: CGFloat {
        if #available(iOS 11, *) {
            if let window = UIApplication.shared.keyWindowInConnectedScenes {
                return window.safeAreaInsets.top
            }
        }
        return 20
    }
    
    func roundCorners(_ corners:UIRectCorner, radius: CGFloat) {
         let path = UIBezierPath(roundedRect: self.bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
         let mask = CAShapeLayer()
         mask.path = path.cgPath
         self.layer.mask = mask
    }
    
}

extension UIApplication {
    var keyWindowInConnectedScenes: UIWindow? {
        return windows.first(where: { $0.isKeyWindow })
    }
}

extension UIView {
    
    @IBInspectable var cornerRadiusForView: CGFloat {
        get {
            return layer.cornerRadius
        }
        set {
            layer.cornerRadius = newValue
            layer.masksToBounds = newValue > 0
        }
    }
    @IBInspectable var topCornerRadius: CGFloat {
        get { layer.cornerRadius }
        set {
            layer.cornerRadius = newValue
            layer.masksToBounds = true

            if #available(iOS 11.0, *) {
                layer.maskedCorners = [.layerMinXMinYCorner,
                                       .layerMaxXMinYCorner]
            }
        }
    }
    
    @IBInspectable var borderWidth: CGFloat {
        get {
            return layer.borderWidth
        }
        set {
            layer.borderWidth = newValue
        }
    }
    
    @IBInspectable var borderColor: UIColor? {
        get {
            return UIColor(cgColor: layer.borderColor!)
        }
        set {
            layer.borderColor = newValue?.cgColor
        }
    }
    
    @IBInspectable
    var shadowRadius: CGFloat {
        get {
            return layer.shadowRadius
        }
        set {
            layer.shadowRadius = newValue
        }
    }
    
    @IBInspectable
    var shadowOpacity: Float {
        get {
            return layer.shadowOpacity
        }
        set {
            layer.shadowOpacity = newValue
        }
    }
    
    @IBInspectable
    var shadowOffset: CGSize {
        get {
            return layer.shadowOffset
        }
        set {
            layer.shadowOffset = newValue
        }
    }
    
    @IBInspectable
    var shadowColor: UIColor? {
        get {
            if let color = layer.shadowColor {
                return UIColor(cgColor: color)
            }
            return nil
        }
        set {
            if let color = newValue {
                layer.shadowColor = color.cgColor
            } else {
                layer.shadowColor = nil
            }
        }
    }
}
