//
//  UIViewController + Reusable.swift
//
//  Copyright © 2018. All rights reserved.
//

import UIKit

extension UIViewController: Reusable {
	
	static func fromNib<T: UIViewController>(bundle: Bundle? = nil) -> T {
		return T(nibName: String(describing: self), bundle: bundle)
	}
    
}
