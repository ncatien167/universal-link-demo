//
//  Constants.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 15/07/2022.
//

import UIKit

struct Constants {
    
    struct Order {
        static let ORDER_DETAIL = "ORDER_DETAIL"
        
        static let datasType: [PaymentTypeData] = [
            PaymentTypeData(title: "Thanh toán qua Open Banking", icon: UIImage(named: "ic_open_banking", in: Bundle().appBundle(), compatibleWith: nil), paymentMethod: 3, isSelected: false, type: .billNamA),
            
            PaymentTypeData(title: "Thanh toán qua ngân hàng Nam Á", icon: UIImage(named: "nab_logo_payment2", in: Bundle().appBundle(), compatibleWith: nil), paymentMethod: 2, isSelected: true, type: .gateWayNamA),
            
            PaymentTypeData(title: "Thanh toán khi nhận hàng", icon: UIImage(named: "ic_payment_cod", in: Bundle().appBundle(), compatibleWith: nil), paymentMethod: 1, isSelected: false, type: .pickup)
        ]
        
        func getBundle() -> Bundle? {
            var bundle: Bundle?
            if let urlString = Bundle.main.path(forResource: "YOUR_FRAMEWORK_BUNDLE_NAME", ofType: "framework", inDirectory: "Frameworks") {
                bundle = (Bundle(url: URL(fileURLWithPath: urlString)))
            }
                return bundle
        }
        
        static let orderHeaderType: [OrderHeaderData] = [
            OrderHeaderData(Name: "Đang xử lý", isSelected: true, orderType: .processing([])),
            OrderHeaderData(Name: "Đã thanh toán", isSelected: false, orderType: .paid([])),
            OrderHeaderData(Name: "Đang vận chuyển", isSelected: false, orderType: .beingTranspoter([])),
            OrderHeaderData(Name: "Thành công", isSelected: false, orderType: .successed([])),
            OrderHeaderData(Name: "Đã hủy", isSelected: false, orderType: .canceled([])),
        ]
    }
}

extension Bundle {
    func appBundle() -> Bundle? {
        var bundle: Bundle?
        if let urlString = Bundle.main.path(forResource: "YOUR_FRAMEWORK_BUNDLE_NAME", ofType: "framework", inDirectory: "Frameworks") {
            bundle = (Bundle(url: URL(fileURLWithPath: urlString)))
        }
        return bundle
    }
}
