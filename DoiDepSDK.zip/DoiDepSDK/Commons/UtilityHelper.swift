//
//  UtilityHelper.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 15/07/2022.
//

import UIKit

struct UtilityHelper {
    

    
}

