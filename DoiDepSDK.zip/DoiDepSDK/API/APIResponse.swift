//
//  APIResponse.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 15/07/2022.
//

import Foundation

struct ResponseLogin<T: Decodable>: Decodable {
    var Message: String?
    var results: T?
}

struct ResponseMessage: Decodable {
    var Message: String?
}

struct ResponseSearchProduct<T: Decodable>: Decodable {
    var Message: String?
    var Items: [T]?
    var Count: Int?
}

struct ResponseOTP: Decodable {
    var Message: String?
    var RefKey: String?
    var OTPLength: Int?
}
