//
//  APIController.swift
//  DoiDepSDK
//
//  Created by Tien Cong on 15/07/2022.
//

import Foundation

typealias ResponseClosure<T: Decodable> = (_ error: String?,_ data: T?) -> Void

struct APIController {
    
    static func request<T: Decodable>(_ responseType: T.Type, _ url: String, method: HTTPMethod, completion: @escaping ResponseClosure<T>) {
        
        AF.request(url, method: method).responseData { responseData in
            switch responseData.result {
            case .success(let data):
                if let dataResult = try? JSONDecoder().decode(responseType, from: data) {
                    completion(nil, dataResult)
                    return
                }
                
                completion("Không có dữ liệu", nil)
            case .failure(let error):
                completion(error.localizedDescription, nil)
                return
            }
        }
    }
    
    static func request<T: Decodable>(_ responseType: T.Type, _ manager: APIManager, params: Parameters? = nil, completion: @escaping ResponseClosure<T>) {
        Logger.log(message: "URL REQUEST: \(manager.url)", event: .debug)
        AF.request(manager.url, method: manager.method, parameters: params, encoding: manager.encoding, headers: manager.header).cURLDescription { (cURL) in
            Logger.log(message: "cURL \(cURL)", event: .debug)
        }.responseData { responseData in
            Logger.log(message: "request Status Code \(responseData.response?.statusCode ?? -1)", event: .debug)
            let statusCode = responseData.response?.statusCode ?? -1
            
            switch responseData.result {
            case .success(let data):
                if let jsonString = String(data: data, encoding: .utf8) {
                    Logger.log(message: "request Data \(jsonString)", event: .debug)
                } else {
                    print("Không thể convert Data thành String.")
                }
                if statusCode == 400 {
                    JSONDecoder.decode(responseType, from: data, completion: { (error, response) in
                        completion("Lỗi", response)
                    })
                    return
                } else if statusCode == 401 {
                    completion("Token Invalid", nil)
                    return
                }
                JSONDecoder.decode(responseType, from: data, completion: { (error, response) in
                    completion(error, response)
                })
            case .failure(let error):
                completion(error.localizedDescription, nil)
                return
            }
        }
//        AF.request(manager.url, method: manager.method, parameters: params, encoding: manager.encoding, headers: manager.header).responseData { responseData in
//            Logger.log(message: "request Status Code \(responseData.response?.statusCode ?? -1)", event: .debug)
//            let statusCode = responseData.response?.statusCode ?? -1
//            
//            switch responseData.result {
//            case .success(let data):
//                if statusCode == 400 {
//                    JSONDecoder.decode(responseType, from: data, completion: { (error, response) in
//                        completion("Lỗi", response)
//                    })
//                    return
//                } else if statusCode == 401 {
//                    completion("Token Invalid", nil)
//                    return
//                }
//                JSONDecoder.decode(responseType, from: data, completion: { (error, response) in
//                    completion(error, response)
//                })
//            case .failure(let error):
//                completion(error.localizedDescription, nil)
//                return
//            }
//        }
    }
}
